"""Read-only fixture checks. Run: python -m unittest discover -s . -p 'test_prime_tables.py'."""
import csv
import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

try:
    from .prime_tables import _annotations, _panel_from_features, audit_tables
except ImportError:
    from prime_tables import _annotations, _panel_from_features, audit_tables


class TableTests(unittest.TestCase):
    def setUp(self):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.base = Path(tmp.name)

    def labels(self, rows, header=("cell_id","group")):
        p = self.base/"labels.csv"
        with p.open("w", encoding="utf-8-sig",newline="") as f:
            w=csv.writer(f); w.writerow(header); w.writerows(rows)
        return p

    def test_unannotated_reference_retained(self):
        a,problems=_annotations(self.labels([("001-1","A"),("002-1","B")]), {"001-1","002-1","003-1"})
        self.assertEqual(problems, [])
        self.assertEqual(a["exact_id_matches"],2)
        self.assertEqual(a["reference_cells_without_unambiguous_nonblank_label"],1)
        self.assertAlmostEqual(a["reference_label_coverage"],2/3)

    def test_ambiguous_and_nonmatching_labels_not_fixed_or_dropped(self):
        a,problems=_annotations(self.labels([("001-1","A"),("001-1","B"),("002-1-old","A")]),{"001-1","002-1"})
        self.assertTrue(problems)
        self.assertEqual(a["conflicting_label_ids"],1)
        self.assertEqual(a["source_ids_absent_from_reference"],1)
        self.assertEqual(a["unique_reference_cells_with_unambiguous_nonblank_label"],0)

    def test_require_explicit_column_when_multiple_label_columns(self):
        p=self.labels([("001-1","B","1")],("cell_id","group","cluster"))
        with self.assertRaises(ValueError): _annotations(p,{"001-1"})
        a,issues=_annotations(p,{"001-1"},label_col="group")
        self.assertFalse(issues)
        self.assertEqual(a["label_row_counts"],{"B":1})

    def test_control_filter_and_duplicate_guard(self):
        r={}
        _panel_from_features([b"CD3D",b"CXCL8",b"NC"],[b"Gene Expression",b"Gene Expression",b"Negative Control Probe"],[b"A",b"B",b"C"],r)
        self.assertEqual(r["gene_expression_names"],["CD3D","CXCL8"])
        self.assertEqual(r["all_features"],3)
        with self.assertRaises(ValueError):
            _panel_from_features(["GENE","GENE"],["Gene Expression"]*2,["id1","id2"],{})
        with self.assertRaises(ValueError):
            _panel_from_features(["NegControlProbe_1"],["Gene Expression"],["id1"],{})

    def test_unavailable_input_surfaces_blockers(self):
        r=audit_tables(self.base, self.base/"missing.csv")
        self.assertFalse(r["raw_tables_ok"])
        self.assertFalse(r["annotation_join_ok"]);self.assertTrue(r["blockers"])
        json.dumps(r,allow_nan=False)

    @unittest.skipUnless(all(importlib.util.find_spec(k) for k in ["h5py","pyarrow"]), "requires h5py and pyarrow")
    def test_native_footers_and_metadata(self):
        import h5py
        import pyarrow as pa
        import pyarrow.parquet as pq
        def save(name,columns): pq.write_table(pa.table(columns),self.base/(name+".parquet"))
        save("transcripts",dict(x_location=[1.,2.],y_location=[2.,2.],feature_name=[b"G",b"NegControlProbe_1"],cell_id=["001-1","UNASSIGNED"],qv=[40.,30.]))
        save("cells",dict(cell_id=["001-1","002-1"]))
        for kind in ["cell","nucleus"]:
            save(kind+"_boundaries",dict(cell_id=["001-1"],vertex_x=[1.],vertex_y=[2.]))
        with h5py.File(self.base/"cell_feature_matrix.h5", "w") as f:
            g=f.create_group("matrix/features");g["name"]=[b"G",b"NegControlProbe_1"]
            g["id"]=[b"ID1",b"ID2"];g["feature_type"]=[b"Gene Expression",b"Negative Control Probe"]
        label=self.labels([("001-1","A")])
        r=audit_tables(self.base,label)
        self.assertTrue(r["raw_tables_ok"],r["blockers"])
        self.assertTrue(r["annotation_join_ok"]);self.assertEqual(r["transcripts"]["n_rows"],2)
        self.assertEqual(r["panel"]["gene_expression_names"],["G"])
        self.assertEqual(r["annotations"]["reference_label_coverage"],0.5)
        json.dumps(r,allow_nan=False)
        save("cells",dict(cell_id=["001-1","001-1"]))
        r=audit_tables(self.base,label)
        self.assertFalse(r["raw_tables_ok"]);self.assertFalse(r["annotation_join_ok"])


if __name__=="__main__":
    unittest.main()
