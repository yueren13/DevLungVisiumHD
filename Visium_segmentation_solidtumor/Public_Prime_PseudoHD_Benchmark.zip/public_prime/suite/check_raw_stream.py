"""Optional local smoke test on real Arrow Parquet; does not open study files or run a method."""
from pathlib import Path
from tempfile import TemporaryDirectory
import numpy as np
import pandas as pd
from p06212_benchmark.patches import core_bounds, iter_transcript_regions, UNKNOWN_REFERENCE


def main():
    import pyarrow as pa
    import pyarrow.parquet as pq
    # Multiple batches are required from a single large row group. Extraneous data are deliberately present.
    n=250_003
    coords=np.full(n, 12.0);coords[[0,250_000,250_001,250_002]]=1.0
    cell=np.full(n,'known',dtype=object);cell[250_000]='UNASSIGNED'
    gene=np.full(n,'A',dtype=object);gene[250_001]='CTRL'
    qv=np.full(n,30.);qv[250_002]=10.
    batch=pa.table({'x_location':coords,'y_location':coords,'feature_name':gene,'cell_id':cell,
                    'qv':qv,'unused_column':np.zeros(n,dtype=np.int8)})
    with TemporaryDirectory() as d:
        parquet=Path(d)/'tiny.parquet';pq.write_table(batch,parquet,row_group_size=n)
        co=core_bounds(2,2,core_size_um=4,halo_um=0);co['core_id']='field'
        chunks=list(iter_transcript_regions(parquet,[co],transform_to_um=np.eye(3),genes=['A'],reference_ids=['known'],
                    columns={'x':'x_location','y':'y_location'},emit_empty=True))
        kept=pd.concat([fr for _,fr,_ in chunks],ignore_index=True)
        assert [x[2]['input_rows'] for x in chunks]==[250_000,3], 'Expected bounded record batches'
        assert kept.reference_cell_id.tolist()==['known',UNKNOWN_REFERENCE], 'QC/panel/unknown semantics changed'
        assert kept.gene.tolist()==['A','A']
    print('PASS: one large Parquet row group produced two bounded batches; control and low-QV calls excluded; eligible unassigned count retained.')

if __name__=="__main__":
    main()
