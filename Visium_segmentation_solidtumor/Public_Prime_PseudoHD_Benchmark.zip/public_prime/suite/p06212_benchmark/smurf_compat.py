"""Narrow SMURF-lite compatibility repair for full rectangular bin grids.

The supported upstream allocator indexes tissue-filtered coordinate lists with
indices into the full expression matrix.  This module changes only those two
coordinate-list expressions.  It does not modify the installed SMURF package,
its allocation formulas, the input tissue flags, or the input counts.
"""
from __future__ import annotations

import ast
from collections.abc import Mapping
import functools
import hashlib
import importlib.metadata
import inspect
import textwrap
from types import SimpleNamespace


def _sha256(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _expression(text):
    return ast.parse(text, mode="eval").body


def _same_ast(left, right):
    return ast.dump(left, include_attributes=False) == ast.dump(right, include_attributes=False)


def _validate_bin_coordinate_lookup(adata, so):
    """Validate the expression-row lookup in linear time and bounded extra RAM."""
    import numpy as np

    required = ("array_row", "array_col")
    if any(name not in adata.obs.columns for name in required):
        raise ValueError("SMURF-lite input needs array_row and array_col in adata.obs.")
    coordinates = adata.obs.loc[:, list(required)].to_numpy(copy=False)
    if coordinates.shape != (adata.n_obs, 2) or adata.n_obs < 1:
        raise ValueError("SMURF-lite needs one coordinate pair for each input expression row.")
    if not (np.issubdtype(coordinates.dtype, np.integer)
            or np.issubdtype(coordinates.dtype, np.floating)):
        raise ValueError("SMURF-lite array coordinates must be numeric integers.")
    if (not np.isfinite(coordinates).all() or (coordinates < 0).any()
            or not np.equal(coordinates, np.rint(coordinates)).all()):
        raise ValueError("SMURF-lite array coordinates must be finite nonnegative integers.")
    lookup = getattr(so, "set_toindex_data", None)
    if not isinstance(lookup, Mapping) or len(lookup) != adata.n_obs:
        raise ValueError(
            "SMURF-lite set_toindex_data must cover every input expression row exactly once. "
            "Rebuild it from the same input bin order; do not drop or renumber bins."
        )
    # The keys are unique coordinates.  With exactly n_obs entries, checking
    # their in-range positions and equality to each row also proves one-to-one
    # coverage, without constructing another million-element tuple/set table.
    for coordinate, position in lookup.items():
        if (not isinstance(position, (int, np.integer))
                or isinstance(position, (bool, np.bool_))
                or position < 0 or position >= adata.n_obs):
            raise ValueError("SMURF-lite set_toindex_data contains an invalid expression-row index.")
        if (not isinstance(coordinate, tuple) or len(coordinate) != 2
                or coordinate[0] != coordinates[position, 0]
                or coordinate[1] != coordinates[position, 1]):
            raise ValueError(
                "SMURF-lite coordinate/index mismatch: set_toindex_data does not match "
                f"adata.obs at expression row {position}."
            )


def prepare_smurf_lite_allocator(su):
    """Return ``(allocator, audit)`` with only the known coordinate bug repaired.

    The allocator keeps the native call signature.  Source and signature checks
    happen before any expensive benchmark processing; unfamiliar implementations
    raise a clear error instead of receiving a speculative rewrite.
    """
    original = getattr(su, "get_finaldata_fast", None)
    if not inspect.isfunction(original) or original.__closure__:
        raise RuntimeError("Unsupported SMURF-lite allocator: expected a Python function without a closure.")
    signature = inspect.signature(original)
    positional = ["cells_final", "so", "adatas_final", "adata", "weight_to_celltype"]
    keywords = ["plot", "hi_scale", "low_scale"]
    if (list(signature.parameters) != positional + keywords
            or any(signature.parameters[name].kind != inspect.Parameter.POSITIONAL_OR_KEYWORD
                   for name in positional)
            or any(signature.parameters[name].default is not inspect.Parameter.empty for name in positional)
            or any(signature.parameters[name].kind != inspect.Parameter.KEYWORD_ONLY for name in keywords)
            or any(signature.parameters[name].default is inspect.Parameter.empty for name in keywords)):
        raise RuntimeError(f"Unsupported SMURF-lite allocator signature: {signature}")
    try:
        source = textwrap.dedent(inspect.getsource(original))
    except (OSError, TypeError) as exc:
        raise RuntimeError(
            "Cannot inspect the installed SMURF-lite allocator source. "
            "Use the source-backed supported installation before starting a long run."
        ) from exc
    tree = ast.parse(source)
    if len(tree.body) != 1 or not isinstance(tree.body[0], ast.FunctionDef):
        raise RuntimeError("Unsupported SMURF-lite source: expected exactly one function definition.")
    function = tree.body[0]
    if function.name != "get_finaldata_fast" or function.decorator_list:
        raise RuntimeError("Unsupported SMURF-lite source: unexpected name or decorators.")

    assignments = {}
    states = {}
    for target, column in (("rows", "array_row"), ("cols", "array_col")):
        matches = [node for node in ast.walk(function)
                   if isinstance(node, ast.Assign) and len(node.targets) == 1
                   and isinstance(node.targets[0], ast.Name) and node.targets[0].id == target]
        if len(matches) != 1:
            raise RuntimeError(f"Unsupported SMURF-lite source: expected one {target} coordinate assignment.")
        node = matches[0]
        legacy = _expression(f"list(so.df[so.df.in_tissue == 1].{column})")
        corrected = _expression(f"list(adata.obs[{column!r}])")
        if _same_ast(node.value, legacy):
            states[target] = "legacy"
        elif _same_ast(node.value, corrected):
            states[target] = "corrected"
        else:
            raise RuntimeError(
                f"Unsupported SMURF-lite {target} lookup. Inspect the installed source "
                "before using the benchmark compatibility repair."
            )
        assignments[target] = (node, corrected)
    if len(set(states.values())) != 1:
        raise RuntimeError("Unsupported partially modified SMURF-lite coordinate lookups.")
    for target in ("rows", "cols"):
        expected_use = _expression(f"{target}[to_ml[i][0]]")
        if not any(_same_ast(node, expected_use) for node in ast.walk(function)
                   if isinstance(node, ast.Subscript)):
            raise RuntimeError(f"Unsupported SMURF-lite source: expected expression-row indexing of {target}.")

    changed = states["rows"] == "legacy"
    if changed:
        for node, corrected in assignments.values():
            node.value = ast.copy_location(corrected, node.value)
        ast.fix_missing_locations(tree)
        # Use a private copy of the original function's global namespace.  All
        # native helper functions remain the same objects; package globals and
        # the installed get_finaldata_fast function are never monkeypatched.
        namespace = dict(original.__globals__)
        exec(compile(tree, "<p06212-smurf-lite-coordinate-compat>", "exec"), namespace)
        implementation = namespace[function.name]
    else:
        implementation = original
    transformed_source = ast.unparse(tree) + "\n"
    try:
        distribution_version = importlib.metadata.version("pysmurf")
    except importlib.metadata.PackageNotFoundError:
        distribution_version = None
    audit = {
        "rule": "expression-row-aligned coordinates for SMURF-lite shared-bin distances",
        "status": "patched_known_tissue_filtered_lookup" if changed else "already_row_aligned",
        "coordinate_assignments_changed": 2 if changed else 0,
        "module_version": str(getattr(su, "__version__", "unknown")),
        "distribution_version": distribution_version,
        "function_module": original.__module__,
        "original_source_sha256": _sha256(source),
        "allocator_ast_source_sha256": _sha256(transformed_source),
        "input_tissue_flags_modified": False,
        "installed_package_modified": False,
        "bin_count_and_row_order_modified": False,
        "native_allocation_formulas_and_rng_modified": False,
    }

    @functools.wraps(original)
    def allocator(cells_final, so, adatas_final, adata, weight_to_celltype,
                  *, plot=signature.parameters["plot"].default,
                  hi_scale=signature.parameters["hi_scale"].default,
                  low_scale=signature.parameters["low_scale"].default):
        _validate_bin_coordinate_lookup(adata, so)
        return implementation(cells_final, so, adatas_final, adata, weight_to_celltype,
                              plot=plot, hi_scale=hi_scale, low_scale=low_scale)

    allocator.__signature__ = signature
    return allocator, audit


def smurf_lite_preflight(su):
    """Exercise the installed native allocator on a tiny full-grid fixture.

    This checks the failing high-index path, complete gene/count and cell-ID
    preservation, unchanged tissue flags, and rejection of a mismatched lookup.
    It also compares to an all-tissue control where the original upstream
    coordinate lookup is valid.  No real benchmark input or result is touched.
    """
    import anndata as ad
    import numpy as np
    import pandas as pd
    from scipy.sparse import csr_matrix

    allocator, audit = prepare_smurf_lite_allocator(su)
    raw = np.zeros((10, 3), dtype=np.int64)
    raw[1] = [3, 2, 0]
    raw[8] = [0, 1, 4]
    raw[9] = [5, 6, 7]
    obs = pd.DataFrame({"array_row": np.zeros(10, dtype=np.int64),
                        "array_col": np.arange(10, dtype=np.int64),
                        "in_tissue": np.isin(np.arange(10), [1, 8, 9]).astype(np.int64)},
                       index=[f"s_002um_00000_{i:05d}-1" for i in range(10)])
    bins = ad.AnnData(X=csr_matrix(raw), obs=obs,
                     var=pd.DataFrame(index=["fixture_g1", "fixture_g2", "fixture_g3"]))
    clusters = ad.AnnData(X=csr_matrix((2, 3), dtype=np.int64),
                         obs=pd.DataFrame({"leiden": pd.Categorical(["0", "0"])},
                                          index=["101.0", "202.0"]),
                         var=bins.var.copy())
    mask = np.zeros((8, 40), dtype=np.uint32)
    mask[1:4, 5:8] = 101
    mask[1:4, 33:36] = 202
    image = np.full((8, 40, 3), 255, dtype=np.uint8)

    def spatial_object(all_tissue=False):
        df = obs.reset_index(names="barcode").copy()
        if all_tissue:
            df["in_tissue"] = 1
        return SimpleNamespace(
            df=df,
            index_toset={i: (0, i) for i in range(10)},
            set_toindex_data={(0, i): i for i in range(10)},
            cells_main={101: [1], 202: [8]},
            cell_centers={101: (0.0, 1.0), 202: (0.0, 8.0)},
            segmentation_final=mask.copy(),
            image_temp=lambda: image.copy(),
        )

    cells = {101: {(0, 1), (0, 9)}, 202: {(0, 8), (0, 9)}}
    weights = np.ones((1, 3), dtype=float) / np.sqrt(3.0)
    so = spatial_object()
    original_flags = so.df["in_tissue"].to_numpy().copy()
    random_state = np.random.get_state()
    try:
        result = allocator(cells, so, clusters, bins, weights,
                           plot=False, hi_scale=1.0, low_scale=1.0)
        control = su.get_finaldata_fast(cells, spatial_object(all_tissue=True), clusters,
                                        bins, weights, plot=False, hi_scale=1.0, low_scale=1.0)
        expected_genes = np.asarray(bins.X.sum(axis=0)).ravel()
        observed_genes = np.asarray(result.X.sum(axis=0)).ravel()
        if (list(result.obs_names) != list(clusters.obs_names)
                or list(result.var_names) != list(bins.var_names)
                or not np.array_equal(observed_genes, expected_genes)):
            raise RuntimeError("SMURF-lite preflight failed cell-ID, gene-axis, or count preservation.")
        if (list(result.obs_names) != list(control.obs_names)
                or list(result.var_names) != list(control.var_names)
                or (csr_matrix(result.X) != csr_matrix(control.X)).nnz):
            raise RuntimeError("SMURF-lite preflight differs from the valid native-control allocation.")
        if (not np.array_equal(so.df["in_tissue"].to_numpy(), original_flags)
                or not np.array_equal(bins.obs["in_tissue"].to_numpy(), obs["in_tissue"].to_numpy())):
            raise RuntimeError("SMURF-lite preflight unexpectedly changed input tissue flags.")
        invalid = spatial_object()
        invalid.set_toindex_data[(0, 9)] = 8
        try:
            allocator(cells, invalid, clusters, bins, weights, plot=False)
        except ValueError as exc:
            if "coordinate/index mismatch" not in str(exc):
                raise
        else:
            raise RuntimeError("SMURF-lite preflight did not reject an invalid coordinate lookup.")
    finally:
        np.random.set_state(random_state)
    return {
        "status": "passed",
        "fixture_bins": 10,
        "fixture_tissue_bins": 3,
        "fixture_shared_bin_expression_row": 9,
        "fixture_cells": 2,
        "fixture_genes": 3,
        "fixture_input_counts": int(raw.sum()),
        "checks": ["high-index shared-bin allocation", "per-gene integer count preservation",
                   "cell and gene identity preservation", "equivalence to valid native control",
                   "unchanged input tissue flags", "invalid coordinate-map rejection"],
        "allocator": audit,
    }
