"""Audit-only transfer of cell annotations to an original Xenium cell universe.

Expression matrices in integrated/annotated H5ADs are deliberately never used.
Identifiers are matched against the complete, sample-specific original ID set;
the trailing ``-1`` in a Xenium barcode is never stripped heuristically.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable, Mapping, Optional
import json
import re

import numpy as np
import pandas as pd


def _text(value) -> str:
    if isinstance(value, bytes):
        return value.decode("utf-8")
    return str(value)


def _normal_ids(values: Iterable, name: str) -> list[str]:
    values = list(values)
    if any(pd.isna(value) for value in values):
        raise ValueError(f"{name} contains missing identifiers.")
    result = [_text(value) for value in values]
    if any(not value or value != value.strip() for value in result):
        raise ValueError(f"{name} contains empty IDs or surrounding whitespace; resolve explicitly.")
    return result


def read_annotation_obs(path: str | Path, celltype_col: str = "Leiden_celltype") -> pd.DataFrame:
    """Read only obs/metadata through backed AnnData; close the input unchanged."""
    try:
        import anndata as ad
    except ImportError as exc:
        raise ImportError("Annotation inventory needs anndata in this notebook kernel.") from exc
    obj = ad.read_h5ad(Path(path), backed="r")
    try:
        if celltype_col not in obj.obs:
            raise KeyError(f"{path}: obs.{celltype_col} is absent; columns={list(obj.obs)}")
        return obj.obs.copy()
    finally:
        obj.file.close()


def candidate_ids(
    source_id: str,
    universe: set[str],
    lengths: Iterable[int],
    separators: str = "_:-.| /",
    explicit_regex: Optional[str] = None,
) -> tuple[list[str], str]:
    """Find only exact known original IDs, optionally surrounded by separators.

    An exact full ID always wins. Otherwise, a supplied regex must full-match
    and have a named ``barcode`` group or exactly one capturing group. The
    automatic mode considers known IDs bounded by the string edge or explicit
    separators. Multiple candidates are an ambiguity, never a nearest match.
    """
    if source_id in universe:
        return [source_id], "exact"
    if explicit_regex is not None:
        pattern = re.compile(explicit_regex)
        if "barcode" not in pattern.groupindex and pattern.groups != 1:
            raise ValueError("barcode_regex must contain named group 'barcode' or one capture group.")
        m = pattern.fullmatch(source_id)
        if m is None:
            return [], "regex_no_match"
        value = m.group("barcode") if "barcode" in pattern.groupindex else m.group(1)
        return ([value], "explicit_regex") if value in universe else ([], "regex_unknown_id")
    candidates = set()
    starts = [0] + [i + 1 for i, char in enumerate(source_id) if char in separators]
    for start in starts:
        for length in lengths:
            stop = start + length
            if stop > len(source_id):
                continue
            if stop != len(source_id) and source_id[stop] not in separators:
                continue
            value = source_id[start:stop]
            if value in universe:
                candidates.add(value)
    return sorted(candidates), "bounded_known_id"


@dataclass
class AnnotationMatchResult:
    reference_cells: pd.DataFrame
    mapping: pd.DataFrame
    source_audit: pd.DataFrame
    errors: list[str]

    def require_valid(self) -> "AnnotationMatchResult":
        if self.errors:
            error = ValueError("Annotation mapping is not valid:\n- " + "\n- ".join(self.errors))
            error.annotation_audit = self
            raise error
        return self

    def save(self, directory: str | Path) -> None:
        destination = Path(directory)
        destination.mkdir(parents=True, exist_ok=True)
        self.reference_cells.to_csv(destination / "reference_cells_with_annotations.csv", index=False)
        self.mapping.to_csv(destination / "annotation_barcode_mapping.csv", index=False)
        self.source_audit.to_csv(destination / "annotation_source_audit.csv", index=False)
        (destination / "annotation_validation.json").write_text(
            json.dumps({"valid": not self.errors, "errors": self.errors}, indent=2)
        )


def match_annotations(
    reference_cells: pd.DataFrame,
    annotation_sources: Iterable[Mapping],
    *,
    celltype_col: str = "Leiden_celltype",
    obs_loader: Callable = read_annotation_obs,
    separators: str = "_:-.| /",
    max_unmatched_annotation_fraction: float = 0.0,
    strict: bool = True,
    audit_dir: Optional[str | Path] = None,
) -> AnnotationMatchResult:
    """Map QC-passing annotations to originals, preserving every original cell.

    ``reference_cells`` requires ``sample_id`` and ``reference_cell_id``. Each
    source is a dict with ``sample_id``, ``component_id`` (explicit specimen grouping), and
    ``path``. Optional ``barcode_column`` uses an obs column instead of the
    index; optional ``barcode_regex`` gives a full-match extraction rule.

    Source cells absent from the original universe are unexpected and fail by
    default. Original cells absent from these QC-filtered sources are retained
    with ``annotation_status='not_in_annotation'``. Duplicate source cells,
    ambiguous recovery, and any two sources resolving to one original cell
    fail. Same-looking cell IDs in different original samples remain distinct.

    Set ``strict=False`` only to inspect/export the audit, then call
    ``result.require_valid()`` before using its joined table downstream.
    """
    if not 0 <= max_unmatched_annotation_fraction <= 1:
        raise ValueError("max_unmatched_annotation_fraction must be in [0, 1].")
    required = {"sample_id", "reference_cell_id"}
    if not required.issubset(reference_cells):
        raise ValueError(f"reference_cells must contain {sorted(required)}")
    ref = reference_cells.copy()
    ref["sample_id"] = _normal_ids(ref["sample_id"], "reference sample_id")
    ref["reference_cell_id"] = _normal_ids(ref["reference_cell_id"], "reference_cell_id")
    duplicate_ref = ref.duplicated(["sample_id", "reference_cell_id"], keep=False)
    if duplicate_ref.any():
        example = ref.loc[duplicate_ref, ["sample_id", "reference_cell_id"]].head(8).to_dict("records")
        raise ValueError(f"Original reference IDs are not unique within sample: {example}")
    reserved = {"annotation_component_id", "annotation_file", "annotation_obs_name", "annotation_status"}
    if reserved.intersection(ref.columns) or celltype_col in ref:
        raise ValueError("Reference table already has annotation output columns; pass the original table.")
    universes = {
        sample: set(frame["reference_cell_id"])
        for sample, frame in ref.groupby("sample_id", sort=False)
    }
    rows = []
    errors = []
    sources = list(annotation_sources)
    seen_sources = set()
    for source_number, source in enumerate(sources):
        sample = _text(source["sample_id"])
        component = _text(source["component_id"])
        path = str(source["path"])
        identity = (sample, component, path)
        if identity in seen_sources:
            raise ValueError(f"Annotation source is listed twice: {identity}")
        seen_sources.add(identity)
        if sample not in universes:
            raise ValueError(f"Annotation source {path} names unknown sample {sample}.")
        is_csv = source.get("format") == "csv" or str(path).lower().endswith((".csv",".csv.gz"))
        if is_csv:
            id_field = source.get("barcode_column")
            label_field = source.get("label_column", celltype_col)
            if not id_field or not label_field or id_field == label_field:
                raise ValueError("Annotation CSV requires distinct reviewed barcode_column and label_column.")
            obs = pd.read_csv(path, usecols=[id_field,label_field], dtype=str, keep_default_na=False)
            if label_field != celltype_col:
                obs = obs.rename(columns={label_field:celltype_col})
            obs[celltype_col] = obs[celltype_col].replace("", pd.NA)
        else:
            obs = obs_loader(path, source.get("label_column", celltype_col))
            if source.get("label_column", celltype_col) != celltype_col:
                obs = obs.rename(columns={source["label_column"]:celltype_col})
        if celltype_col not in obs:
            raise KeyError(f"{path}: annotation column {celltype_col} is absent.")
        if not len(obs):
            errors.append(f"{path}: annotation table is empty.")
            continue
        obs_names = _normal_ids(obs.index, f"{path} obs_names")
        barcode_column = source.get("barcode_column")
        if barcode_column is None:
            source_ids = obs_names
        else:
            if barcode_column not in obs:
                raise KeyError(f"{path}: barcode_column '{barcode_column}' is absent.")
            source_ids = _normal_ids(obs[barcode_column], f"{path} {barcode_column}")
        duplicate_obs = pd.Index(obs_names).duplicated(keep=False)
        duplicate_source = pd.Index(source_ids).duplicated(keep=False)
        universe = universes[sample]
        lengths = sorted({len(value) for value in universe})
        for row_number, (obs_name, source_id, label) in enumerate(zip(obs_names, source_ids, obs[celltype_col])):
            if is_csv:
                candidates, rule = ([source_id], "exact") if source_id in universe else ([], "exact_id_absent")
            else:
                candidates, rule = candidate_ids(
                source_id, universe, lengths, separators=separators,
                explicit_regex=source.get("barcode_regex"),
            )
            status = "matched" if len(candidates) == 1 else "unmatched" if not candidates else "ambiguous"
            if duplicate_obs[row_number] or duplicate_source[row_number]:
                status = "duplicate_source_id"
            rows.append({
                "source_number": source_number,
                "sample_id": sample,
                "source_component_id": component,
                "annotation_file": path,
                "annotation_obs_name": obs_name,
                "source_barcode": source_id,
                "source_row": row_number,
                "reference_cell_id": candidates[0] if len(candidates) == 1 else None,
                "candidate_reference_ids": json.dumps(candidates),
                "match_rule": rule,
                "match_status": status,
                celltype_col: None if pd.isna(label) else _text(label),
            })
    columns = [
        "source_number", "sample_id", "source_component_id", "annotation_file",
        "annotation_obs_name", "source_barcode", "source_row", "reference_cell_id",
        "candidate_reference_ids", "match_rule", "match_status", celltype_col,
    ]
    mapping = pd.DataFrame(rows, columns=columns)
    matched_mask = mapping["match_status"].eq("matched")
    duplicate_targets = mapping.loc[matched_mask].duplicated(["sample_id", "reference_cell_id"], keep=False)
    if duplicate_targets.any():
        idx = duplicate_targets.index[duplicate_targets]
        mapping.loc[idx, "match_status"] = "duplicate_target_id"
    for status in ("ambiguous", "duplicate_source_id", "duplicate_target_id"):
        n = int(mapping["match_status"].eq(status).sum())
        if n:
            errors.append(f"{n} annotation rows have status '{status}'; no automatic resolution was applied.")
    audit_rows = []
    for source_number, source in enumerate(sources):
        frame = mapping.loc[mapping["source_number"].eq(source_number)]
        n = len(frame)
        unmatched = int(frame["match_status"].eq("unmatched").sum())
        fraction = unmatched / n if n else float("nan")
        if n and fraction > max_unmatched_annotation_fraction:
            errors.append(
                f"{source['path']}: {unmatched}/{n} annotation IDs are absent from the original "
                f"sample ID universe (limit {max_unmatched_annotation_fraction:.1%})."
            )
        audit_rows.append({
            "sample_id": _text(source["sample_id"]),
            "component_id": _text(source["component_id"]),
            "annotation_file": str(source["path"]),
            "n_annotation_rows": n,
            "n_matched": int(frame["match_status"].eq("matched").sum()),
            "n_exact": int((frame["match_status"].eq("matched") & frame["match_rule"].eq("exact")).sum()),
            "n_unmatched": unmatched,
            "n_ambiguous": int(frame["match_status"].eq("ambiguous").sum()),
            "n_duplicate_source": int(frame["match_status"].eq("duplicate_source_id").sum()),
            "n_duplicate_target": int(frame["match_status"].eq("duplicate_target_id").sum()),
            "unmatched_fraction": fraction,
        })
    valid = mapping.loc[mapping["match_status"].eq("matched"), [
        "sample_id", "reference_cell_id", "source_component_id", "annotation_file",
        "annotation_obs_name", celltype_col,
    ]].rename(columns={"source_component_id": "annotation_component_id"})
    joined = ref.merge(valid, how="left", on=["sample_id", "reference_cell_id"], validate="one_to_one", sort=False)
    joined["annotation_status"] = np.where(
        joined["annotation_file"].isna(), "not_in_annotation",
        np.where(joined[celltype_col].isna(), "matched_label_missing", "annotated"),
    )
    result = AnnotationMatchResult(joined, mapping, pd.DataFrame(audit_rows), errors)
    if audit_dir is not None:
        result.save(audit_dir)
    if strict:
        result.require_valid()
    return result
