"""Small shared utilities; imports neither TensorFlow nor any segmentation tool."""
from __future__ import annotations
from pathlib import Path
import hashlib
import json
import platform
from importlib.metadata import version, PackageNotFoundError
import numpy as np


def jsonable(x):
    if isinstance(x, Path): return str(x)
    if isinstance(x, np.ndarray): return x.tolist()
    if isinstance(x, np.generic): return x.item()
    raise TypeError(type(x).__name__)


def write_json(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    def clean(value):
        if isinstance(value, dict): return {str(k):clean(v) for k,v in value.items()}
        if isinstance(value, (list,tuple)): return [clean(v) for v in value]
        if isinstance(value, np.ndarray): return clean(value.tolist())
        if isinstance(value, np.generic): return clean(value.item())
        if isinstance(value,float) and not np.isfinite(value): return None
        return value
    text = json.dumps(clean(data), indent=2, default=jsonable, allow_nan=False)
    temp = path.with_name(path.name + '.tmp')
    temp.write_text(text + '\n'); temp.replace(path)
    return path


def read_json(path):
    return json.loads(Path(path).read_text())


def file_sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(8 * 2**20), b''): h.update(chunk)
    return h.hexdigest()


def object_sha256(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=jsonable).encode()).hexdigest()


def versions():
    result = {'python': platform.python_version()}
    for name in ('numpy','pandas','scipy','anndata','spatialdata','spatialdata-io',
                 'zarr','dask','tifffile','imagecodecs','shapely','pyarrow',
                 'bin2cell','pysmurf','stardist','tensorflow','torch','scanpy'):
        try: result[name] = version(name)
        except PackageNotFoundError: result[name] = 'not installed'
    return result


def load_config(path='config.json'):
    config = read_json(path)
    config['_config_path'] = str(Path(path).resolve())
    return config


def output_root(config):
    root = Path(config['output_root']).expanduser().resolve()
    # An output path may never be one of the immutable source stores/files.
    inputs = [Path(config['he_path']).expanduser().resolve()]
    inputs += [Path(x['zarr_path']).expanduser().resolve() for x in config['samples'].values()]
    inputs += [Path(x['path']).expanduser().resolve() for x in config['annotation_sources']]
    for source in inputs:
        if root == source or source in root.parents:
            raise ValueError(f'Output directory is inside an original input: {source}')
    root.mkdir(parents=True, exist_ok=True)
    return root


def alignment_matrix(sample_id, config):
    """Read the selected 10x H&E-pixels -> native morphology-pixels 3x3 affine.
    A no-header numeric CSV only: do not guess direction, substitute identity,
    flatten an unfamiliar file, or apply an original transform to a prewarped H&E.
    """
    settings = config["samples"][str(sample_id)]
    source = settings.get("alignment_csv")
    if not source or not Path(source).expanduser().is_file():
        raise FileNotFoundError(f"Supply the H&E imagealignment.csv for {sample_id}.")
    try:
        matrix = np.loadtxt(Path(source).expanduser(), delimiter=",", encoding="utf-8-sig")
    except (ValueError, UnicodeError) as exc:
        raise ValueError(f"Expected a numeric headerless 3x3 affine at {source}; inspect export and its units.") from exc
    if (matrix.shape != (3,3) or not np.isfinite(matrix).all()
        or not np.allclose(matrix[2], [0,0,1], rtol=0, atol=1e-9)
        or abs(np.linalg.det(matrix[:2,:2])) < 1e-12):
        raise ValueError(f"Unsupported or singular H&E affine: {source}")
    return matrix


def nonempty_output(path):
    path = Path(path)
    if path.exists() and any(path.iterdir()):
        raise FileExistsError(f'{path} already has outputs. Use a new run directory to avoid mixing configurations.')
    path.mkdir(parents=True, exist_ok=True)
    return path
