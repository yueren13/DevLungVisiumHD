"""Build fixed pseudo-TMA inputs and a separate, hidden reference ledger."""
from __future__ import annotations
from pathlib import Path
import gzip
import math
import shutil
import numpy as np
import pandas as pd
from scipy import sparse
from scipy.io import mmwrite
from .common import write_json, read_json, file_sha256, nonempty_output


def write_native_hd(a, destination, metadata):
    """Write the native HD subset consumed by Proseg; never run Space Ranger.

    These files describe a synthetic grid, not an instrument-produced library.
    Matrix Market is features x barcodes, as required by 10x conventions.
    """
    root=Path(destination)/'binned_outputs'/'square_002um'
    matrix_dir=root/'raw_feature_bc_matrix'; spatial_dir=root/'spatial'
    matrix_dir.mkdir(parents=True,exist_ok=True);spatial_dir.mkdir(parents=True,exist_ok=True)
    with gzip.open(matrix_dir/'matrix.mtx.gz','wb') as f:
        mmwrite(f,sparse.coo_matrix(a.X.T),field='integer',symmetry='general')
    with gzip.open(matrix_dir/'barcodes.tsv.gz','wt') as f:
        f.write('\n'.join(map(str,a.obs_names))+'\n')
    with gzip.open(matrix_dir/'features.tsv.gz','wt') as f:
        for gene in a.var_names:
            if any(c in str(gene) for c in '\t\r\n'):raise ValueError('Invalid feature name for TSV.')
            f.write(f'{gene}\t{gene}\tGene Expression\n')
    positions=a.obs[['array_row','array_col','in_tissue']].copy()
    positions.insert(0,'barcode',a.obs_names.astype(str))
    positions['pxl_row_in_fullres']=a.obsm['spatial'][:,1]
    positions['pxl_col_in_fullres']=a.obsm['spatial'][:,0]
    positions.to_parquet(spatial_dir/'tissue_positions.parquet',index=False)
    write_json(spatial_dir/'scalefactors_json.json',{
        'microns_per_pixel':float(metadata['image_mpp']),
        'spot_diameter_fullres':float(metadata['bin_size_um'])/float(metadata['image_mpp']),
        'bin_size_um':float(metadata['bin_size_um']),
        'tissue_hires_scalef':1.0,'tissue_lowres_scalef':1.0})
    return root


def _integral(value,name):
    if not np.isclose(value,round(value),rtol=0,atol=1e-8):raise ValueError(f'{name} must map to an integer grid size.')
    return int(round(value))


def _uid(core_id,cell_id):
    return f'{core_id}::{cell_id}'


def build_bundle(core_rows, core_cache, input_dir, reference_dir, design):
    """Compose existing per-core arrays with immutable integer translations.

    core_cache/<core_id>/ needs he.tif, bins.h5ad, contributions.parquet,
    reference_cells.csv, reference_nuclei.npy, reference_nuclei_ids.csv and
    metadata.json. The caller has already reviewed identities and coordinates.
    Output input_dir contains no Xenium cell IDs, cell types, DAPI or reference
    nuclei; reference_dir is consumed only by the evaluator.
    """
    import anndata as ad
    import tifffile
    rows=core_rows.sort_values('tile_index').reset_index(drop=True)
    if rows.empty:raise ValueError('Bundle has no cores.')
    if rows.bundle_id.nunique()!=1:raise ValueError('One bundle ID per call required.')
    input_dir=nonempty_output(input_dir);reference_dir=nonempty_output(reference_dir)
    mpp=float(design['image_mpp']);bin_size=float(design['bin_size_um'])
    side=float(design['core_side_um']);halo=float(design['halo_um']);gutter=float(design['gutter_um'])
    extent=side+2*halo;ncolumns=min(int(design['bundle_columns']),len(rows));nrows=math.ceil(len(rows)/ncolumns)
    width_um=ncolumns*extent+(ncolumns+1)*gutter
    height_um=nrows*extent+(nrows+1)*gutter
    width_px=_integral(width_um/mpp,'canvas width');height_px=_integral(height_um/mpp,'canvas height')
    width_bins=_integral(width_um/bin_size,'bin width');height_bins=_integral(height_um/bin_size,'bin height')
    tile_px=_integral(extent/mpp,'tile extent');tile_bins=_integral(extent/bin_size,'tile bins')
    rgb=np.full((height_px,width_px,3),255,np.uint8)
    nuclei=np.zeros((height_px,width_px),np.uint32)
    in_tissue=np.zeros((height_bins,width_bins),np.uint8)
    scoring=np.zeros((height_bins,width_bins),bool)
    bin_core=np.full(height_bins*width_bins,'',dtype=object)
    matrices=[];row_indices=[];col_indices=[];values=[];truth_contributions=[]
    refs=[];nucleus_maps=[];placements=[];genes=None;next_reference_label=1
    for position,core in rows.iterrows():
        cid=str(core.core_id);source=Path(core_cache)/cid
        a=ad.read_h5ad(source/'bins.h5ad');a.X=sparse.csr_matrix(a.X)
        if genes is None:genes=a.var_names.astype(str).tolist()
        if genes!=a.var_names.astype(str).tolist():raise ValueError('All cores must have the same ordered panel gene universe.')
        meta=read_json(source/'metadata.json')
        if not np.isclose(meta['image_mpp'],mpp):raise ValueError('Inconsistent core image resolution.')
        tx=position%ncolumns;ty=position//ncolumns
        x_um=gutter+tx*(extent+gutter);y_um=gutter+ty*(extent+gutter)
        xpx=_integral(x_um/mpp,'tile x');ypx=_integral(y_um/mpp,'tile y')
        xb=_integral(x_um/bin_size,'bin x');yb=_integral(y_um/bin_size,'bin y')
        image=tifffile.imread(source/'he.tif')
        if image.shape!=(tile_px,tile_px,3):raise ValueError(f'{cid}: unexpected H&E patch shape {image.shape}')
        rgb[ypx:ypx+tile_px,xpx:xpx+tile_px]=image
        local=a.obs[['array_row','array_col']].to_numpy(int)
        local_to_global=(local[:,0]+yb)*width_bins+local[:,1]+xb
        bin_core[local_to_global]=cid
        in_tissue[yb:yb+tile_bins,xb:xb+tile_bins]=1
        hb=_integral(halo/bin_size,'halo bins');sb=_integral(side/bin_size,'score bins')
        scoring[yb+hb:yb+hb+sb,xb+hb:xb+hb+sb]=True
        coo=a.X.tocoo();row_indices.append(local_to_global[coo.row]);col_indices.append(coo.col);values.append(coo.data)
        contrib=pd.read_parquet(source/'contributions.parquet')
        # Resolve local barcode order explicitly before translating to mosaic bins.
        if 'barcode' not in contrib:raise KeyError('contributions.parquet requires barcode')
        local_idx=a.obs_names.get_indexer(contrib.barcode.astype(str))
        if (local_idx<0).any():raise ValueError('Reference contribution refers to an absent local bin.')
        contrib['bin_index']=local_to_global[local_idx]
        contrib=contrib.drop(columns='barcode')
        contrib['core_id']=cid
        contrib['original_reference_cell_id']=contrib.reference_cell_id.astype(str)
        known=contrib.reference_cell_id.ne('__unassigned__')
        contrib.loc[known,'reference_cell_id']=[_uid(cid,x) for x in contrib.loc[known,'reference_cell_id']]
        truth_contributions.append(contrib)
        reference=pd.read_csv(source/'reference_cells.csv',dtype={'reference_cell_id':str,'sample_id':str,'component_id':str})
        reference['original_reference_cell_id']=reference.reference_cell_id.astype(str)
        reference['reference_cell_id']=[_uid(cid,x) for x in reference.reference_cell_id]
        reference['core_id']=cid;reference['sample_id']=str(core.sample_id)
        if 'annotation_component_id' not in reference:
            reference['annotation_component_id']=reference.get('component_id','')
        for name in ('component_id','alignment_group','median_residual_um','p90_residual_um'):
            if name in core:reference[name]=core[name]
        bx0,by0,bx1,by1=meta['bounds_um']
        if 'x_um' in reference:
            reference['source_x_um']=reference['x_um'];reference['source_y_um']=reference['y_um']
            reference['mosaic_x_um']=reference['x_um']+x_um-bx0
            reference['mosaic_y_um']=reference['y_um']+y_um-by0
        refs.append(reference)
        local_labels=np.load(source/'reference_nuclei.npy',allow_pickle=False)
        id_map=pd.read_csv(source/'reference_nuclei_ids.csv',dtype={'reference_cell_id':str})
        # The renderer returns reference_label, one identity per reference cell.
        if not {'reference_label','reference_cell_id'}.issubset(id_map):raise ValueError('Reference nucleus ID map has an unsupported schema.')
        max_label=max(int(local_labels.max(initial=0)),int(id_map.reference_label.max()) if len(id_map) else 0)
        relabel=np.zeros(max_label+1,dtype=np.uint32)
        for item in id_map.itertuples():
            relabel[int(item.reference_label)]=next_reference_label
            nucleus_maps.append({'raster_label':next_reference_label,'reference_cell_id':_uid(cid,item.reference_cell_id),
                                 'original_reference_cell_id':item.reference_cell_id,'core_id':cid,'sample_id':str(core.sample_id),
                                 'ambiguous_reference_overlap':getattr(item,'ambiguous_reference_overlap',False),
                                 'n_geometry_parts':getattr(item,'n_geometry_parts',1)})
            next_reference_label+=1
        nuclei[ypx:ypx+tile_px,xpx:xpx+tile_px]=relabel[local_labels]
        bx0,by0,bx1,by1=meta['bounds_um']
        placements.append({'core_id':cid,'sample_id':str(core.sample_id),'tile_index':position,
             'x0_px':xpx,'y0_px':ypx,'width_px':tile_px,'height_px':tile_px,
             'mosaic_x0_um':x_um,'mosaic_y0_um':y_um,'source_bounds_um':[bx0,by0,bx1,by1],
             'source_um_to_mosaic_um':[[1,0,x_um-bx0],[0,1,y_um-by0],[0,0,1]]})
    counts=sparse.coo_matrix((np.concatenate(values),(np.concatenate(row_indices),np.concatenate(col_indices))),
                            shape=(height_bins*width_bins,len(genes))).tocsr().astype(np.int64)
    rr,cc=np.indices((height_bins,width_bins));rr=rr.ravel();cc=cc.ravel()
    barcodes=[f's_002um_{r:05d}_{c:05d}-1' for r,c in zip(rr,cc)]
    obs=pd.DataFrame({'array_row':rr,'array_col':cc,'in_tissue':in_tissue.ravel(),
                      'core_id':bin_core,'scoring_bin':scoring.ravel()},index=pd.Index(barcodes,name='barcode'))
    a=ad.AnnData(counts,obs=obs,var=pd.DataFrame(index=pd.Index(genes,name='gene')))
    a.obsm['spatial']=np.column_stack([(cc+.5)*bin_size/mpp,(rr+.5)*bin_size/mpp])
    metadata={'schema_version':1,'bundle_id':str(rows.bundle_id.iloc[0]),'image_mpp':mpp,'bin_size_um':bin_size,
        'nrows':height_bins,'ncols':width_bins,'image_shape':[height_px,width_px,3],
        'core_side_um':side,'halo_um':halo,'gutter_um':gutter,
        'mask_pixel_center_offset':0.5,'proseg_axis_order':'row_col',
        'image_filename':'image.tif','seed_filename':'seeds.npy','bins_filename':'bins.h5ad',
        'placements':placements,'synthetic_source':'Xenium molecules binned into 2um squares',
        'unknown_reference_molecules_retained':True,'shared_seed_state':'not_yet_generated',
        'n_input_molecules':int(counts.sum()),'n_nonempty_bins':int(np.count_nonzero(np.asarray(counts.sum(axis=1)).ravel()))}
    a.write_h5ad(input_dir/'bins.h5ad',compression='gzip')
    tifffile.imwrite(input_dir/'image.tif',rgb,photometric='rgb',compression='deflate')
    write_json(input_dir/'metadata.json',metadata)
    write_native_hd(a,input_dir,metadata)
    contributions=pd.concat(truth_contributions,ignore_index=True)
    if int(contributions['count'].sum())!=int(counts.sum()):raise AssertionError('Mosaic bin counts and hidden contributions do not conserve the same molecules.')
    contributions.to_parquet(reference_dir/'bin_gene_reference_contributions.parquet',index=False)
    reference=pd.concat(refs,ignore_index=True)
    if reference.reference_cell_id.duplicated().any():raise ValueError('Duplicate composite reference cell ID.')
    known=contributions.reference_cell_id.ne('__unassigned__')
    grouped=contributions.loc[known].groupby(['reference_cell_id','gene'],observed=True)['count'].sum().reset_index()
    ridx=pd.Index(reference.reference_cell_id).get_indexer(grouped.reference_cell_id)
    if (ridx<0).any():raise ValueError('Molecular reference IDs missing from full reference metadata.')
    gidx=pd.Index(genes).get_indexer(grouped.gene)
    truth=sparse.coo_matrix((grouped['count'],(ridx,gidx)),shape=(len(reference),len(genes))).tocsr().astype(np.int64)
    # Optional metadata strings are normalized only for H5AD serialization.
    for name in reference.columns:
        if reference[name].dtype==object or str(reference[name].dtype).startswith('string'):
            reference[name]=reference[name].fillna('').astype(str)
    reference.index=reference.reference_cell_id.astype(str)
    reference.index.name='reference_uid'
    t=ad.AnnData(truth,obs=reference,var=pd.DataFrame(index=pd.Index(genes,name='gene')))
    t.uns['reference_definition']='Original Xenium IDs, eligible molecules inside context crops; scored cells fully inside each 500um core.'
    t.write_h5ad(reference_dir/'counts.h5ad',compression='gzip')
    np.save(reference_dir/'nuclei.npy',nuclei,allow_pickle=False)
    pd.DataFrame(nucleus_maps).to_csv(reference_dir/'nuclei_ids.csv',index=False)
    reference.to_csv(reference_dir/'reference_cells.csv',index=False)
    write_json(reference_dir/'reference_summary.json',{'known_molecules':int(truth.sum()),
       'unassigned_molecules':int(contributions.loc[~known,'count'].sum()),'n_reference_cells':len(reference),
       'counts_sha256':file_sha256(reference_dir/'counts.h5ad'),
       'warning':'Do not make this directory or its labels available to a segmentation adapter.'})
    return metadata


def clone_inputs(source,destination):
    """Copy a frozen input tree. No symlinks back to mutable source arrays."""
    source=Path(source);destination=Path(destination)
    if destination.exists():raise FileExistsError(destination)
    shutil.copytree(source,destination)
    return destination
