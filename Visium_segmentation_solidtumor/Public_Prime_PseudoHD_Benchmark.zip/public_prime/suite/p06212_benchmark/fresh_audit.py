"""Strict fresh baseline preflight for public-cohort result comparisons."""
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import sparse
from .common import read_json, file_sha256


def _vector(path):
    """Return exact integer per-gene totals; bound rows per dense/native H5AD slice."""
    import anndata as ad
    obj=ad.read_h5ad(path,backed="r")
    try:
        names=pd.Index(obj.var_names.astype(str))
        if not names.is_unique: raise ValueError("Duplicate gene axis")
        totals=np.zeros(len(names),dtype=np.int64)
        # Target ~32 MiB worst-case dense read when genes number in the thousands.
        step=max(1,min(50_000,32*2**20//max(1,8*len(names))))
        for start in range(0,obj.n_obs,step):
            block=obj.X[start:start+step,:]
            values=block.data if sparse.issparse(block) else np.asarray(block)
            if not np.isfinite(values).all() or np.any(values<0) or np.any(values!=np.rint(values)):
                raise ValueError("Expected finite nonnegative integer counts")
            totals+=np.asarray(block.sum(axis=0,dtype=np.int64)).ravel()
        return names,totals
    finally:
        obj.file.close()


def audit_selected(root, lookup, bundle_ids, methods, repeat_ids):
    """Do not choose the best repeat, accept an incomplete job, or trim excess."""
    root=Path(root)
    if not repeat_ids or any(isinstance(i,bool) or not isinstance(i,int) or i<1 for i in repeat_ids):
        raise ValueError("Supply positive fresh repeat IDs.")
    if not all(len(set(x))==len(x) for x in (bundle_ids,methods,repeat_ids)): raise ValueError("Duplicate requested IDs")
    rows,output=[],[]
    for bundle in bundle_ids:
        meta_row=lookup.loc[(bundle,"baseline")]
        inp=Path(meta_row.input_dir); stored=read_json(inp/"metadata.json")
        public_seed=file_sha256(inp/stored.get("seed_filename","seeds.npy"))
        public_meta=file_sha256(inp/"metadata.json")
        genes,source=_vector(inp/stored.get("bins_filename","bins.h5ad"))
        if int(source.sum())!=int(stored["n_input_molecules"]):raise ValueError(f"{bundle}: public counts changed.")
        for method in methods:
            for repeat in repeat_ids:
                dest=root/"results"/bundle/"baseline"/method/f"repeat_{repeat:02d}"
                row={"bundle_id":bundle,"method":method,"repeat":repeat,"condition":"baseline","status":"unverified","reason":""}
                try:
                    summary=read_json(dest/"run_summary.json")
                    launcher=read_json(dest.with_name(dest.name+"_launcher.json"))
                    if (summary.get("method")!=method or summary.get("status")!="completed" or
                        launcher.get("returncode")!=0 or not np.isfinite(float(summary.get("total_runner_seconds"))) or
                        float(summary["total_runner_seconds"])<=0):
                        raise ValueError("Expected a completed fresh runner and successful launcher with positive measured time.")
                    if Path(summary["input_dir"]).resolve()!=inp.resolve() or summary.get("seed_sha256")!=public_seed or summary.get("metadata_sha256")!=public_meta:
                        raise ValueError("Source path, public metadata or mask no longer matches the run.")
                    g= pd.read_csv(dest/"gene_count_audit.csv",dtype={"gene":str}).set_index("gene",verify_integrity=True)
                    outgenes,allocated=_vector(dest/"counts.h5ad")
                    if not genes.equals(outgenes) or set(g.index)!=set(genes): raise ValueError("Gene axis differs from source.")
                    if not np.array_equal(g.loc[genes,"input_counts"].to_numpy(),source) or not np.array_equal(g.loc[genes,"output_counts"].to_numpy(),allocated):
                        raise ValueError("Fresh input/output gene counts differ from saved audit.")
                    excess=np.maximum(allocated-source,0)
                    row.update(input_counts=int(source.sum()),output_counts=int(allocated.sum()),gene_excess_counts=int(excess.sum()),
                               n_excess_genes=int((excess>0).sum()),seed_sha256=public_seed,total_runner_seconds=float(summary["total_runner_seconds"]))
                    if int(excess.sum())>0: raise ValueError("Native count excess at the bundle/gene level; retain diagnostic and investigate.")
                    if int(summary["input_counts"])!=row["input_counts"] or int(summary["output_counts"])!=row["output_counts"]:
                        raise ValueError("Count totals disagree with saved summary.")
                    if not (dest/"seed_audit.csv").is_file():raise FileNotFoundError("Missing seed_audit.csv.")
                    row["status"]="verified";output.append(dest/"counts.h5ad")
                except (OSError,TypeError,ValueError,KeyError,IndexError,OverflowError) as exc:
                    row["reason"]=f"{type(exc).__name__}: {exc}"
                rows.append(row)
    return pd.DataFrame(rows),output
