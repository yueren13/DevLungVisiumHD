"""Reference-free adapters for a shared-seed, 2-µm assignment benchmark.

Heavy dependencies are imported inside the corresponding runner so that the
SpatialData inspection kernel need not contain all three segmentation tools.
Each runner consumes only the public input directory and writes a new run.
The evaluator, reference cells, and annotation joins are deliberately absent.

Supported source interfaces were reviewed on 2026-10-28: bin2cell 0.3.5,
pysmurf 3.0.2, and proseg 3.2.0. Runtime signatures and executable help are
checked; an installed version is never inferred from these review versions.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import gzip
import hashlib
import importlib
import importlib.metadata
import inspect
import json
import os
from pathlib import Path
import pickle
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
import warnings


DEFAULT_PROSEG_EXE = ""  # explicit machine-specific absolute path required


def _json_default(value):
    if isinstance(value, Path):
        return str(value)
    if hasattr(value, "item"):
        return value.item()
    if hasattr(value, "tolist"):
        return value.tolist()
    raise TypeError(type(value).__name__)


def _write_json(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, default=_json_default, allow_nan=False))
    tmp.replace(path)


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def environment_report():
    result = {"python": sys.version, "executable": sys.executable, "packages": {}}
    for name in ("numpy", "pandas", "scipy", "anndata", "scanpy", "bin2cell",
                 "pysmurf", "smurf", "torch", "tensorflow", "stardist", "psutil"):
        try:
            result["packages"][name] = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            pass
    try:
        result["cpu_affinity"] = sorted(os.sched_getaffinity(0))
    except AttributeError:
        result["cpu_affinity"] = None
    return result


class _Run:
    """Record wall time and sampled resident memory, including child processes."""

    def __init__(self, method, input_dir, output_dir, config):
        self.output = Path(output_dir).expanduser().resolve()
        self.input = Path(input_dir).expanduser().resolve()
        if self.output == self.input or self.input in self.output.parents:
            raise ValueError("Method outputs must be outside the frozen input directory.")
        self.output.mkdir(parents=True, exist_ok=True)
        if any(self.output.iterdir()):
            raise FileExistsError(
                f"Run directory is not empty: {self.output}. Use a new directory for a new run."
            )
        self.report = {
            "method": method, "status": "running", "input_dir": str(self.input),
            "output_dir": str(self.output), "config": dict(config),
            "environment": environment_report(), "stages_seconds": {},
            "memory_sampling_interval_seconds": 0.25,
            "memory_scope": "entire runner process plus children; includes interpreter and loaded inputs",
            "stardist_in_primary_timing": False,
        }
        self.stop = threading.Event()
        self.peak_rss = None
        self.start_rss = None

    def _monitor(self):
        try:
            import psutil
        except ImportError:
            self.report["memory_monitor_error"] = "psutil is not installed"
            return
        try:
            process = psutil.Process()
        except psutil.Error as exc:
            self.report["memory_monitor_error"] = str(exc)
            return
        while not self.stop.is_set():
            try:
                total = process.memory_info().rss
                for child in process.children(recursive=True):
                    try:
                        total += child.memory_info().rss
                    except psutil.Error:
                        pass
                if self.start_rss is None:
                    self.start_rss = total
                self.peak_rss = max(self.peak_rss or 0, total)
            except psutil.Error:
                pass
            self.stop.wait(0.25)

    def __enter__(self):
        self.started = time.perf_counter()
        self.old_affinity = None
        self.old_env = {}
        requested = self.report["config"].get("threads", self.report["config"].get("nthreads"))
        if requested is not None:
            requested = int(requested)
            if requested < 1:
                raise ValueError("Requested CPU threads must be positive.")
            try:
                self.old_affinity = os.sched_getaffinity(0)
                chosen = sorted(self.old_affinity)[:requested]
                os.sched_setaffinity(0, chosen)
                self.report["actual_cpu_affinity"] = chosen
            except (AttributeError, OSError):
                self.report["actual_cpu_affinity"] = None
            for key in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"):
                self.old_env[key] = os.environ.get(key)
                os.environ[key] = str(requested)
            self.report["cpu_limit_note"] = "Fixed CPU affinity where supported; BLAS/OpenMP variables set before lazy imports. Fresh runner processes are recommended."
        self.thread = threading.Thread(target=self._monitor, daemon=True)
        self.thread.start()
        _write_json(self.output / "run_summary.json", self.report)
        return self

    @contextmanager
    def stage(self, name):
        start = time.perf_counter()
        try:
            yield
        finally:
            self.report["stages_seconds"][name] = time.perf_counter() - start

    def __exit__(self, typ, exc, tb):
        self.stop.set()
        self.thread.join(timeout=1)
        self.report["total_runner_seconds"] = time.perf_counter() - self.started
        self.report["peak_process_tree_rss_bytes"] = self.peak_rss
        self.report["initial_process_tree_rss_bytes"] = self.start_rss
        self.report["peak_gpu_bytes"] = None
        self.report["gpu_memory_note"] = "Not measured by this portable runner; use an external GPU monitor if required."
        self.report["status"] = "failed" if exc is not None else "completed"
        if self.old_affinity is not None:
            try:
                os.sched_setaffinity(0, self.old_affinity)
            except OSError:
                pass
        for key, value in self.old_env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        if exc is not None:
            self.report["error"] = f"{typ.__name__}: {exc}"
            (self.output / "traceback.txt").write_text("".join(traceback.format_exception(typ, exc, tb)))
        _write_json(self.output / "run_summary.json", self.report)
        return False


def validate_input(input_dir, *, load_image=False):
    """Load a public input bundle and check counts, grid, labels, and coordinates.

    Coordinates in bins.obsm['spatial'] are [x,y] in the image's boundary-based
    pixel frame: physical bin centers divided by image_mpp. Array pixel [0,0]
    has its physical center at [0.5,0.5] * image_mpp.
    """
    import anndata as ad
    import numpy as np
    import pandas as pd
    import scipy.sparse as sp

    root = Path(input_dir).expanduser().resolve()
    meta = json.loads((root / "metadata.json").read_text())
    for key in ("image_mpp", "bin_size_um", "nrows", "ncols"):
        if key not in meta:
            raise KeyError(f"metadata.json is missing {key}")
    if float(meta["bin_size_um"]) != 2.0:
        raise ValueError("These method presets require 2-µm bins.")
    mpp = float(meta["image_mpp"])
    if not np.isfinite(mpp) or mpp <= 0:
        raise ValueError("image_mpp must be a positive verified physical scale.")
    nrows, ncols = int(meta["nrows"]), int(meta["ncols"])
    if min(nrows, ncols) < 2:
        raise ValueError("A two-dimensional grid with at least two rows/columns is required.")
    a = ad.read_h5ad(root / meta.get("bins_filename", "bins.h5ad"))
    a.X = sp.csr_matrix(a.X)
    if not a.obs_names.is_unique or not a.var_names.is_unique:
        raise ValueError("Bin barcodes and feature names must each be unique.")
    if a.n_obs != nrows * ncols:
        raise ValueError("Provide the full rectangular bin grid, including zero-count bins.")
    if not np.isfinite(a.X.data).all() or (a.X.data < 0).any():
        raise ValueError("Input counts must be finite and nonnegative.")
    if not np.equal(a.X.data, np.rint(a.X.data)).all():
        raise ValueError("Input must contain raw integer counts, without normalization/destriping.")
    a.X = a.X.astype(np.int64)
    rc = a.obs[["array_row", "array_col"]].to_numpy(dtype=np.int64)
    if ((rc < 0).any() or (rc[:, 0] >= nrows).any() or (rc[:, 1] >= ncols).any()
            or len(np.unique(rc[:, 0] * ncols + rc[:, 1])) != len(rc)):
        raise ValueError("Invalid, duplicated, or incomplete array coordinates.")
    expected_names = pd.Index([f"s_002um_{r:05d}_{c:05d}-1" for r, c in rc])
    if not a.obs_names.equals(expected_names):
        raise ValueError("SMURF requires barcodes s_002um_RRRRR_CCCCC-1 matching array_row/col.")
    xy = np.asarray(a.obsm["spatial"], dtype=float)
    expected_xy = (rc[:, ::-1] + 0.5) * 2.0 / mpp
    if xy.shape != expected_xy.shape or not np.allclose(xy, expected_xy, rtol=0, atol=1e-6):
        raise ValueError("Bin image coordinates disagree with 2-µm physical bin centers.")
    seeds = np.load(root / meta.get("seed_filename", "seeds.npy"), mmap_mode="r", allow_pickle=False)
    if seeds.ndim != 2 or seeds.dtype != np.uint32:
        raise ValueError("seeds.npy must be a 2D uint32 array, with zero background.")
    expected_shape = np.array([nrows, ncols]) * 2.0 / mpp
    if not np.allclose(seeds.shape, expected_shape, rtol=0, atol=1e-6):
        raise ValueError("Seed mask dimensions do not cover the full bin grid at image_mpp.")
    if not np.allclose(expected_shape, np.rint(expected_shape)):
        raise ValueError("The output image grid must align with the bin grid.")
    ids = np.unique(seeds)
    ids = ids[ids > 0].astype(np.int64)
    if not len(ids):
        raise ValueError("The shared mask contains no positive seeds.")
    # Only observation fields needed for inference survive adapter loading.
    # Cell-type labels or Xenium IDs must never enter a method through .obs/.uns.
    safe_obs = a.obs[[k for k in ("array_row", "array_col", "in_tissue") if k in a.obs]].copy()
    if "in_tissue" not in safe_obs:
        raise ValueError("Input bins need the common broad in_tissue mask.")
    public = ad.AnnData(X=a.X, obs=safe_obs, var=a.var.copy())
    public.obsm["spatial"] = xy
    public.uns["spatial"] = {"synthetic_hd": {
        "scalefactors": {"microns_per_pixel": mpp, "spot_diameter_fullres": 2.0 / mpp},
        "metadata": {"source_image_path": str(root / meta.get("image_filename", "image.tif"))},
    }}
    image = None
    if load_image:
        import tifffile
        image = tifffile.imread(root / meta.get("image_filename", "image.tif"))
        if image.ndim != 3 or image.shape[2] != 3 or image.shape[:2] != seeds.shape:
            raise ValueError("Compact H&E image and shared labels must have matching RGB/yx grids.")
    diagnostics = {
        "n_bins": public.n_obs, "n_nonzero_bins": int(np.count_nonzero(np.asarray(public.X.sum(1)))),
        "n_genes": public.n_vars, "input_counts": int(public.X.sum()),
        "n_shared_seeds": len(ids), "image_shape": list(seeds.shape),
        "image_mpp": mpp, "seed_sha256": _sha256(root / meta.get("seed_filename", "seeds.npy")),
        "metadata_sha256": _sha256(root / "metadata.json"),
    }
    return public, seeds, meta, image, diagnostics


def _numeric_seed_ids(values):
    """Strict label parsing; never extract a coincidental digit from an arbitrary ID."""
    import numpy as np
    result = []
    for value in values:
        s = str(value)
        if not re.fullmatch(r"[1-9][0-9]*(?:\.0+)?", s):
            raise ValueError(f"Output seed identity is not an exact positive integer: {s!r}")
        result.append(int(s.split(".")[0]))
    result = np.asarray(result, dtype=np.int64)
    if len(np.unique(result)) != len(result):
        raise ValueError("Multiple output rows have the same seed identity; an explicit merge/split policy is needed.")
    return result


def _finish_counts(cdata, bins, seeds, run, *, seed_values, initialization_ids=None):
    """Persist native raw counts on the common gene axis and log dropped seeds."""
    import anndata as ad
    import numpy as np
    import pandas as pd
    import scipy.sparse as sp

    ids = _numeric_seed_ids(seed_values)
    master = np.unique(seeds)
    master = master[master > 0].astype(np.int64)
    if not np.isin(ids, master).all():
        raise ValueError("Method introduced IDs that were not in the shared seed mask.")
    if not cdata.var_names.is_unique:
        raise ValueError("Method output gene names are not unique.")
    unknown = cdata.var_names.difference(bins.var_names)
    if len(unknown):
        raise ValueError(f"Output contains genes absent from the public input: {unknown[:5].tolist()}")
    X = sp.csr_matrix(cdata.X)
    if not np.isfinite(X.data).all() or (X.data < 0).any():
        raise ValueError("Output has negative or nonfinite values.")
    if not np.equal(X.data, np.rint(X.data)).all():
        raise ValueError("The primary standardized output requires raw allocated counts, not expected values.")
    # Zero columns make absent output genes explicit rather than shrink the metric universe.
    gene_indices = bins.var_names.get_indexer(cdata.var_names)
    coo = X.tocoo()
    Xall = sp.csr_matrix((coo.data.astype(np.int64), (coo.row, gene_indices[coo.col])),
                        shape=(cdata.n_obs, bins.n_vars))
    obs = cdata.obs.copy()
    obs["method_output_id"] = cdata.obs_names.astype(str)
    obs["seed_id"] = ids
    obs.index = pd.Index([str(i) for i in ids], name="seed_id_index")
    out = ad.AnnData(X=Xall, obs=obs, var=bins.var.copy())
    if "spatial" in cdata.obsm:
        out.obsm["spatial"] = np.asarray(cdata.obsm["spatial"])
    out.uns["benchmark_method"] = str(run.report["method"])
    out.uns["seed_identity_rule"] = "input-mask positive integer ID; never rematched after perturbation"
    out.uns["counts_semantics"] = "native allocated raw counts; common input gene axis"
    input_gene = np.asarray(bins.X.sum(0)).ravel().astype(np.int64)
    output_gene = np.asarray(out.X.sum(0)).ravel().astype(np.int64)
    conservation = pd.DataFrame({"gene": bins.var_names, "input_counts": input_gene,
                                 "output_counts": output_gene,
                                 "unassigned_or_excess": input_gene - output_gene})
    conservation.to_csv(run.output / "gene_count_audit.csv", index=False)
    accepted = set(int(i) for i in (initialization_ids if initialization_ids is not None else master))
    audit = pd.DataFrame({"seed_id": master})
    audit["accepted_at_initialization"] = [int(i) in accepted for i in master]
    audit["present_in_output"] = np.isin(master, ids)
    totals = dict(zip(ids, np.asarray(out.X.sum(1)).ravel()))
    audit["output_counts"] = [int(totals.get(i, 0)) for i in master]
    audit.to_csv(run.output / "seed_audit.csv", index=False)
    run.report.update({"n_output_cells": out.n_obs, "output_counts": int(out.X.sum()),
                       "n_output_genes_native": cdata.n_vars,
                       "n_genes_with_excess_counts": int((output_gene > input_gene).sum()),
                       "excess_counts_total": int(np.maximum(output_gene - input_gene, 0).sum()),
                       "missing_output_seed_count": int((~audit.present_in_output).sum())})
    if (output_gene > input_gene).any():
        warnings.warn("Output has excess counts for one or more genes; inspect gene_count_audit.csv before interpretation.")
    out.write_h5ad(run.output / "counts.h5ad")
    return out


def run_bin2cell(input_dir, output_dir, config=None):
    """Run native Bin2cell expansion from shared seeds, without GEX salvage."""
    cfg = {"algorithm": "max_bin_distance", "max_bin_distance": 2,
           "volume_ratio": 4, "k": 4, "subset_pca": True, **(config or {})}
    with _Run("bin2cell", input_dir, output_dir, cfg) as run:
        with run.stage("load_and_validate"):
            import numpy as np
            import scipy.sparse as sp
            import bin2cell as b2c
            bins, seeds, meta, _, diag = validate_input(input_dir)
            run.report.update(diag)
            label_path = run.output / "shared_seeds.npz"
            sp.save_npz(label_path, sp.csr_matrix(seeds))
        with run.stage("assignment"):
            b2c.insert_labels(bins, labels_npz_path=str(label_path), basis="spatial",
                              spatial_key="spatial", mpp=float(meta["image_mpp"]),
                              labels_key="labels_shared")
            initial = bins.obs["labels_shared"].to_numpy(dtype=np.int64)
            n_assigned = int((initial > 0).sum())
            if n_assigned < max(2, int(cfg["k"])):
                raise RuntimeError("Too few bin centers intersect shared seeds for native Bin2cell kNN expansion.")
            if (initial == 0).any():
                b2c.expand_labels(
                    bins, labels_key="labels_shared", expanded_labels_key="labels_assigned",
                    algorithm=cfg["algorithm"], max_bin_distance=int(cfg["max_bin_distance"]),
                    volume_ratio=float(cfg["volume_ratio"]), k=int(cfg["k"]),
                    subset_pca=bool(cfg["subset_pca"]),
                )
            else:
                bins.obs["labels_assigned"] = initial
            cdata = b2c.bin_to_cell(bins, labels_key="labels_assigned", spatial_keys=["spatial"])
        with run.stage("standardize_and_write"):
            _finish_counts(cdata, bins, seeds, run, seed_values=cdata.obs["object_id"],
                           initialization_ids=np.unique(initial[initial > 0]))
            mapping = bins.obs[["array_row", "array_col", "labels_shared", "labels_assigned"]].copy()
            mapping.index.name = "barcode"
            mapping.to_parquet(run.output / "bin_assignment.parquet")
        run.report["raw_counts_unmodified"] = True
        run.report["secondary_gex_seeds"] = False
        run.report["destripe"] = False
        run.report["cpu_note"] = "Native Bin2cell calls SciPy workers=-1; use a fixed process CPU allocation for fair timing."
    return run.report


def _make_smurf_object(bins, image, seeds, meta):
    """Exact synthetic-grid geometry; bypass full-slide image loading/inference."""
    import numpy as np
    import pandas as pd
    from smurf.spatial_object import spatial_object

    nr, nc = int(meta["nrows"]), int(meta["ncols"])
    mpp = float(meta["image_mpp"])
    rc = bins.obs[["array_row", "array_col"]].to_numpy(dtype=np.int64)
    xy = np.asarray(bins.obsm["spatial"])
    df = pd.DataFrame({"barcode": bins.obs_names.astype(str),
                       "in_tissue": bins.obs["in_tissue"].to_numpy(dtype=np.int64),
                       "array_row": rc[:, 0], "array_col": rc[:, 1],
                       "pxl_row_in_fullres": xy[:, 1], "pxl_col_in_fullres": xy[:, 0]})
    # Sparse expressions include the whole rectangular grid. Every physical pixel
    # receives the correct dataframe row, independently of barcode row ordering.
    lookup = np.empty((nr, nc), dtype=np.int64)
    lookup[rc[:, 0], rc[:, 1]] = np.arange(len(rc))
    rr = np.floor((np.arange(image.shape[0]) + 0.5) * mpp / 2.0).astype(int)
    cc = np.floor((np.arange(image.shape[1]) + 0.5) * mpp / 2.0).astype(int)
    pixels = lookup[rr[:, None], cc[None, :]]
    so = spatial_object(image, df, df.copy(), 0, nr, 0, nc,
                        0, image.shape[0], 0, image.shape[1], pixels, "HE")
    so.segmentation_final = np.asarray(seeds)
    # Current upstream ignores spot_id == 0 when selecting nucleus main bins.
    # Keep that library behavior, and refuse to hide its effect on a real seed.
    if np.any((pixels == 0) & (seeds > 0)):
        raise ValueError("SMURF's current spot_id=0 exclusion intersects a seed. Put the first bin in the shared white gutter.")
    return so


def _recover_smurf_outputs(work):
    """The upstream max-iteration branch can leave only numbered best states."""
    import numpy as np
    work = Path(work)
    a, c = work / "adatas.h5ad", work / "cells_final.pkl"
    if a.exists() and c.exists():
        return a, c, None
    aa = {int(m.group(1)): p for p in work.glob("adatas_*.h5ad")
          if (m := re.fullmatch(r"adatas_(\d+)\.h5ad", p.name))}
    cc = {int(m.group(1)): p for p in work.glob("cells_final_*.pkl")
          if (m := re.fullmatch(r"cells_final_(\d+)\.pkl", p.name))}
    common = sorted(aa.keys() & cc.keys())
    if not common:
        raise RuntimeError("SMURF produced no complete saved iteration. Inspect its run log and model-gene/cell counts.")
    with open(work / "mis.pkl", "rb") as handle:
        scores = pickle.load(handle)  # only this run's local upstream output
    valid = [i for i in common if i < len(scores) and np.isfinite(scores[i])]
    if not valid:
        raise RuntimeError("SMURF saved states have no finite mutual-information score.")
    best = max(valid, key=lambda i: float(scores[i]))
    shutil.copy2(aa[best], a)
    shutil.copy2(cc[best], c)
    return a, c, best


def _targeted_panel_clustering(config):
    """Explicit optional adaptation; never silently substituted for stock SMURF."""
    def cluster(adata, save=False, iter=None, path=None, resolution=2,
                regress_out=False, random_state=0, show=False):
        import numpy as np
        import scanpy as sc
        a = adata.copy()
        sc.pp.filter_genes(a, min_cells=int(config.get("panel_gene_min_cells", 3)))
        if min(a.n_obs, a.n_vars) < 3:
            raise RuntimeError("Insufficient cells/genes for targeted-panel SMURF clustering.")
        sc.pp.normalize_total(a, target_sum=1e4)
        sc.pp.log1p(a)
        # All panel genes with nonzero variance, without genome-wide HVG cutoffs.
        means = np.asarray(a.X.mean(0)).ravel()
        squares = np.asarray(a.X.multiply(a.X).mean(0)).ravel()
        keep = squares - means * means > 1e-12
        a = a[:, keep].copy()
        npcs = min(int(config.get("panel_n_pcs", 30)), a.n_obs - 1, a.n_vars - 1)
        if npcs < 2:
            raise RuntimeError("Fewer than three varying genes/cells after targeted-panel preprocessing.")
        if regress_out:
            raise ValueError("This declared targeted-panel configuration does not implement regress_out.")
        sc.pp.scale(a, max_value=10)
        sc.tl.pca(a, n_comps=npcs, svd_solver="arpack", random_state=random_state)
        sc.pp.neighbors(a, n_neighbors=min(int(config.get("panel_n_neighbors", 10)), a.n_obs - 1),
                        n_pcs=npcs, random_state=random_state)
        sc.tl.leiden(a, resolution=resolution, random_state=random_state,
                     flavor="igraph", n_iterations=2)
        return a
    return cluster


def _smurf_weight_profiles_compat(final_clusters, bins, cells_final, so):
    """Upstream cluster-profile calculation with NumPy boolean sparse indexing.

    pysmurf 3.0.1 passes a pandas Series into SciPy's sparse indexer, which fails
    with recent pandas/SciPy. The 3.0.2 source uses a NumPy boolean array. This
    local calculation reproduces the same sums, cluster means, and L2
    normalization; it does not alter the clustering or assignment algorithm.
    """
    import numpy as np
    import scipy.sparse as sp
    rows = []
    for value in final_clusters.obs_names:
        cid = int(float(value))
        indices = [so.set_toindex_data[pair] for pair in cells_final[cid]
                   if pair in so.set_toindex_data]
        rows.append(sp.csr_matrix(bins.X[indices].sum(axis=0)))
    summed = sp.vstack(rows, format="csr")
    clusters = final_clusters.obs["leiden"].astype(str).to_numpy()
    names = set(clusters)
    if names != {str(i) for i in range(len(names))}:
        raise ValueError("SMURF cluster profiles require consecutive 0-based Leiden labels.")
    weights = np.vstack([np.asarray(summed[clusters == str(i)].mean(axis=0)).ravel()
                         for i in range(len(names))])
    norms = np.linalg.norm(weights, axis=1)
    if not np.isfinite(norms).all() or (norms <= 0).any():
        raise ValueError("SMURF has zero/nonfinite cluster profiles.")
    return weights / norms[:, None]


def run_smurf(input_dir, output_dir, config=None):
    """Run SMURF-lite or SMURF-full, retaining the common mask's seed IDs.

    Default clustering is upstream stock. A targeted-panel clustering adaptation
    is available only by an explicit config choice; report it as a distinct
    configuration. Neither mode imports Xenium annotations or reference labels.
    """
    supplied = dict(config or {})
    for old, new in (("minimum_nucleus_counts", "min_nucleus_counts"),
                     ("max_spot", "max_nucleus_main_spots"), ("max_iterations", "max_iter")):
        if old in supplied:
            if new in supplied and supplied[old] != supplied[new]:
                raise ValueError(f"Conflicting config values: {old} and {new}")
            supplied[new] = supplied.pop(old)
    cfg = {
        "variant": "lite", "clustering_backend": "stock", "model_gene_min_counts": 1,
        "cells_main_pct": 1 / 6, "max_nucleus_main_spots": 50, "min_nucleus_counts": 5,
        "nuclei_rna_min_percent": 0.4, "cluster_resolution": 2.0, "regress_out": False,
        "max_distance_bins": 2, "allow_equal": False, "max_iter": 30, "stop_iter": 2,
        "random_seed": 17, "device": "cuda", "maximum_cells": 10000,
        "num_epochs": 1000, "learning_rate": 0.1, **supplied,
    }
    if cfg["variant"] not in ("lite", "full"):
        raise ValueError("SMURF variant must be 'lite' or 'full'.")
    if cfg["clustering_backend"] not in ("stock", "targeted_panel"):
        raise ValueError("Unknown SMURF clustering_backend.")
    with _Run("smurf_" + cfg["variant"], input_dir, output_dir, cfg) as run:
        with run.stage("load_and_validate"):
            import numpy as np
            import scanpy as sc
            import smurf as su
            helper = importlib.import_module("smurf.__helper__")
            if cfg["variant"] == "lite":
                # Check the installed allocator before the long clustering loop.
                # A private function copy keeps coordinates in full bin-row order;
                # no package files, tissue flags, counts or inference settings change.
                from .smurf_compat import prepare_smurf_lite_allocator, smurf_lite_preflight
                lite_allocator, coordinate_audit = prepare_smurf_lite_allocator(su)
                run.report["smurf_lite_coordinate_compatibility"] = coordinate_audit
                run.report["smurf_lite_preflight"] = smurf_lite_preflight(su)
            bins, seeds, meta, image, diag = validate_input(input_dir, load_image=True)
            run.report.update(diag)
            for name in ("nuclei_rna", "singlecellanalysis", "itering_arragement", "calculate_weight_to_celltype"):
                if not callable(getattr(su, name, None)):
                    raise RuntimeError(f"Installed SMURF lacks required API: {name}")
            if cfg["variant"] == "lite" and "plot" not in inspect.signature(su.get_finaldata_fast).parameters:
                raise RuntimeError("Installed SMURF-lite cannot disable sampled pixel plotting. Use a compatible version and record it.")
            so = _make_smurf_object(bins, image, seeds, meta)
            np.random.seed(int(cfg["random_seed"]))
            gene_total = np.asarray(bins.X.sum(0)).ravel()
            model_gene_mask = gene_total >= int(cfg["model_gene_min_counts"])
            adata_model = bins[:, model_gene_mask].copy()
            run.report["n_model_genes"] = adata_model.n_vars
            run.report["model_gene_threshold_scope"] = "total count per gene in fixed inference bundle; final output restores all input genes"
            if adata_model.n_vars < 3:
                raise RuntimeError("Too few model genes; lower the development-set threshold or increase fixed bundle context.")
            work = run.output / "smurf_iterations"
            work.mkdir()
        original_export = su.singlecellanalysis
        original_internal = helper.singlecellanalysis
        if cfg["clustering_backend"] == "targeted_panel":
            cluster = _targeted_panel_clustering(cfg)
            su.singlecellanalysis = cluster
            helper.singlecellanalysis = cluster
        try:
            with run.stage("initialization_and_clustering"):
                so.generate_cell_spots_information(max_spot=int(cfg["max_nucleus_main_spots"]),
                                                    cells_main_pct=float(cfg["cells_main_pct"]))
                accepted = np.asarray(list(so.cells_main), dtype=np.int64)
                run.report["n_overlap_accepted_seeds"] = len(accepted)
                su.nuclei_rna(adata_model, so, min_percent=float(cfg["nuclei_rna_min_percent"]))
                nuclei = so.final_nuclei.copy()
                sc.pp.filter_cells(nuclei, min_counts=int(cfg["min_nucleus_counts"]))
                run.report["n_expression_accepted_seeds"] = nuclei.n_obs
                if nuclei.n_obs < 5:
                    raise RuntimeError("SMURF needs more nuclei for its nearest-neighbor network and clustering; use a larger fixed bundle.")
                raw = nuclei.copy()
                if cfg["clustering_backend"] == "stock" and min(nuclei.n_obs, nuclei.n_vars) <= 41:
                    raise RuntimeError("Stock SMURF requests 40 PCs; this bundle has too few cells/genes. Use larger fixed context or explicitly calibrate targeted_panel mode.")
                try:
                    clustered = su.singlecellanalysis(
                        nuclei, resolution=float(cfg["cluster_resolution"]),
                        regress_out=bool(cfg["regress_out"]), random_state=int(cfg["random_seed"]), show=False,
                    )
                except ValueError as exc:
                    raise RuntimeError("SMURF initial clustering failed. Inspect the HVG/PC requirements on this targeted panel; do not change settings only for a poor-alignment condition.") from exc
            with run.stage("iterative_assignment"):
                su.itering_arragement(
                    clustered, raw, adata_model, so, resolution=float(cfg["cluster_resolution"]),
                    regress_out=bool(cfg["regress_out"]), save_folder=str(work) + os.sep,
                    show=False, keep_previous=False, max_distance=int(cfg["max_distance_bins"]),
                    allow_equal=bool(cfg["allow_equal"]), max_iter=int(cfg["max_iter"]),
                    stop_iter=int(cfg["stop_iter"]),
                )
                ap, cp, recovered = _recover_smurf_outputs(work)
                run.report["recovered_best_iteration"] = recovered
                final_clusters = sc.read_h5ad(ap)
                with open(cp, "rb") as handle:
                    cells_final = pickle.load(handle)  # same run, not an untrusted imported pickle
            with run.stage("final_count_allocation"):
                if str(getattr(su, "__version__", "")) == "3.0.1":
                    weights = _smurf_weight_profiles_compat(final_clusters, bins, cells_final, so)
                    run.report["smurf_compatibility"] = "3.0.1 cluster-profile sparse boolean index converted to NumPy; same calculation as upstream3.0.2"
                else:
                    weights = su.calculate_weight_to_celltype(final_clusters, bins, cells_final, so)
                if not np.isfinite(weights).all() or (np.linalg.norm(weights, axis=1) == 0).any():
                    raise RuntimeError("SMURF final cluster profiles are zero/nonfinite; inspect model-gene and seed filtering.")
                if cfg["variant"] == "lite":
                    cdata = lite_allocator(cells_final, so, final_clusters, bins, weights,
                                           plot=False, hi_scale=0.1, low_scale=0.05)
                    run.report["randomness_note"] = "Upstream SMURF-lite currently resets its multinomial RNG to zero internally. Repeat timings are not independent allocation seeds."
                else:
                    prep = su.make_preparation(cells_final, so, final_clusters, bins, weights,
                                               maximum_cells=int(cfg["maximum_cells"]))
                    if len(prep) != 11:
                        raise RuntimeError("SMURF-full make_preparation return contract changed.")
                    (pct, spots_x, types_x, cells_x, nonzero, nonzero_ml,
                     before, before_x, groups, spot_ids, spot_props) = prep
                    allocation = su.start_optimization(
                        spots_x, types_x, cells_x, nonzero_ml, device=cfg["device"],
                        num_epochs=int(cfg["num_epochs"]), learning_rate=float(cfg["learning_rate"]),
                        random_seed=int(cfg["random_seed"]), print_memory=False,
                    )
                    cdata = su.get_finaldata(
                        bins, final_clusters, allocation, weights, before, groups, pct, nonzero,
                        spots_X_dic=spots_x, nonzero_indices_toml=nonzero_ml,
                        cells_before_ml_x=before_x, so=so, hi_scale=0.1, low_scale=0.05,
                    )
                    with open(run.output / "full_allocation_weights.pkl", "wb") as handle:
                        pickle.dump(allocation, handle)
            with run.stage("standardize_and_write"):
                _finish_counts(cdata, bins, seeds, run, seed_values=cdata.obs_names,
                               initialization_ids=accepted)
                # Candidate footprints are NOT the realized fractional allocation.
                # Keep provenance without claiming that a sampled display is a cell membrane.
                import pandas as pd
                footprint = [(int(float(cid)), int(r), int(c)) for cid, coords in cells_final.items() for r, c in coords]
                pd.DataFrame(footprint, columns=["seed_id", "array_row", "array_col"]).to_parquet(
                    run.output / "candidate_footprints.parquet", index=False)
                run.report["allocation_diagnostic"] = "candidate_footprints are overlapping candidate regions, not hard/realized bin assignments"
                run.report["pixel_plot_generated"] = False
        finally:
            su.singlecellanalysis = original_export
            helper.singlecellanalysis = original_internal
    return run.report


def probe_proseg(executable=DEFAULT_PROSEG_EXE):
    path = Path(executable).expanduser()
    if not path.is_absolute():
        raise ValueError("Supply Proseg's absolute executable path for the Domino environment.")
    if not path.is_file() or not os.access(path, os.X_OK):
        raise FileNotFoundError(f"Proseg executable is missing or not executable: {path}")
    reports = {}
    for option in ("--version", "--help"):
        result = subprocess.run([str(path), option], capture_output=True, text=True, timeout=30, check=False)
        reports[option] = (result.stdout + result.stderr).strip()
        if result.returncode:
            raise RuntimeError(f"{path} {option} returned {result.returncode}: {reports[option]}")
    required = ["--visiumhd", "--cellpose-masks", "--cellpose-x-transform", "--cellpose-y-transform",
                "--output-counts", "--output-cell-metadata", "--output-gene-metadata", "--output-spatialdata"]
    missing = [name for name in required if name not in reports["--help"]]
    if missing:
        raise RuntimeError(f"Installed Proseg lacks native-HD/shared-mask options: {missing}. Record a compatible executable version before running.")
    return {"executable": str(path), "version": reports["--version"], "help": reports["--help"]}


def proseg_mask_affine(meta):
    """Exact synthetic mask-to-native-reader transform; no fitted old-slide offset."""
    mpp = float(meta["image_mpp"])
    center = float(meta.get("mask_pixel_center_offset", 0.5)) * mpp
    axis_order = meta.get("proseg_axis_order")
    if axis_order == "row_col":
        return [0.0, mpp, center], [mpp, 0.0, center]
    if axis_order == "col_row":
        return [mpp, 0.0, center], [0.0, mpp, center]
    raise ValueError("Declare proseg_axis_order='row_col' or 'col_row' after checking the installed native-HD reader.")


def build_proseg_command(input_dir, output_dir, meta, config):
    """Pure argv builder; affine coefficients are three separate CLI arguments."""
    root, out = Path(input_dir).resolve(), Path(output_dir).resolve()
    executable = Path(config.get("executable", DEFAULT_PROSEG_EXE)).expanduser()
    if not executable.is_absolute():
        raise ValueError("Proseg executable must be an absolute path.")
    x, y = proseg_mask_affine(meta)
    cmd = [str(executable), "--visiumhd", "--nthreads", str(int(config.get("nthreads", 32))),
           "--cellpose-masks", str(root / meta.get("seed_filename", "seeds.npy")),
           "--cellpose-x-transform", *[f"{v:.12g}" for v in x],
           "--cellpose-y-transform", *[f"{v:.12g}" for v in y],
           "--output-spatialdata", str(out / "proseg.zarr"),
           "--output-cell-metadata", str(out / "cell_metadata.csv.gz"),
           "--output-gene-metadata", str(out / "gene_metadata.csv.gz"),
           "--output-counts", str(out / "counts.mtx.gz"),
           "--exclude-spatialdata-transcripts"]
    if config.get("write_transcript_metadata", True):
        cmd.extend(["--output-transcript-metadata", str(out / "transcript_metadata.parquet")])
    # No arbitrary extra_args: prevent accidental native Xenium, fixed-mask,
    # hidden-reference, or input-output substitutions in the controlled track.
    if config.get("extra_args"):
        raise ValueError("Use an explicit separately reviewed runner for additional Proseg flags.")
    cmd.append(str(root / "binned_outputs"))
    return cmd


def validate_proseg_coordinates(executable, work_dir, *, axis_order="row_col", image_mpp=0.5):
    """Run an asymmetric synthetic fixture through the installed native reader.

    This checks observed molecule locations/counts and unchanged-mask centroids,
    not segmentation accuracy. Morphology updates and diffusion are disabled
    ONLY in this small coordinate test. The resulting JSON is tied to the exact
    executable bytes/version, pixel-center convention, and coordinate order.
    The production runner verifies it without asking for a boolean approval.
    """
    import numpy as np
    import pandas as pd
    import scipy.io
    import scipy.sparse as sp

    out = Path(work_dir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    if any(out.iterdir()):
        raise FileExistsError(f"Coordinate fixture directory must be new/empty: {out}")
    probe = probe_proseg(executable)
    required = ("--no-diffusion", "--morphology-steps-per-iter", "--burnin-samples",
                "--samples", "--recorded-samples", "--hillclimb", "--ncomponents",
                "--output-transcript-metadata")
    missing = [flag for flag in required if flag not in probe["help"]]
    if missing:
        raise RuntimeError(f"Installed Proseg cannot run the controlled coordinate fixture: missing {missing}")
    if axis_order not in ("row_col", "col_row"):
        raise ValueError("axis_order must be row_col or col_row.")
    mpp = float(image_mpp)
    if not np.isclose(2 / mpp, round(2 / mpp)):
        raise ValueError("Coordinate fixture requires an integer number of image pixels per bin.")
    nr, nc, ng = 64, 108, 24
    h, w = int(round(nr * 2 / mpp)), int(round(nc * 2 / mpp))
    labels = np.zeros((h, w), dtype=np.uint32)
    counts = sp.lil_matrix((nr * nc, ng), dtype=np.int64)
    rr, cc = np.indices((nr, nc))
    rows, cols = rr.ravel(), cc.ravel()
    genes = [f"fixture_gene_{i:02d}" for i in range(ng)]
    barcodes = [f"s_002um_{r:05d}_{c:05d}-1" for r, c in zip(rows, cols)]
    centers = [(r, c) for r in (9, 28, 47) for c in (12, 35, 64, 91)]
    expected_centroids = {}
    expected_observations = []
    for sid, (r, c) in enumerate(centers, start=1):
        x, y = (c + 0.5) * 2, (r + 0.5) * 2
        r0, r1 = int(round((y - 7) / mpp)), int(round((y + 7) / mpp))
        c0, c1 = int(round((x - 5) / mpp)), int(round((x + 5) / mpp))
        labels[r0:r1, c0:c1] = sid
        expected_centroids[sid] = [x, y] if axis_order == "col_row" else [y, x]
        for br in range(r - 2, r + 3):
            for bc in range(c - 1, c + 2):
                obs_xy = [(bc + 0.5) * 2, (br + 0.5) * 2]
                if axis_order == "row_col":
                    obs_xy = obs_xy[::-1]
                for g, gene in enumerate(genes):
                    amount = 8 if g == sid % ng else 1
                    counts[br * nc + bc, g] = amount
                    expected_observations.append((*obs_xy, gene, amount))
    labels_path = out / "seeds.npy"
    np.save(labels_path, labels, allow_pickle=False)
    native = out / "binned_outputs" / "square_002um"
    matrix_dir, spatial_dir = native / "raw_feature_bc_matrix", native / "spatial"
    matrix_dir.mkdir(parents=True)
    spatial_dir.mkdir()
    with gzip.open(matrix_dir / "matrix.mtx.gz", "wb") as handle:
        scipy.io.mmwrite(handle, counts.T.tocoo(), field="integer")
    with gzip.open(matrix_dir / "features.tsv.gz", "wt") as handle:
        for gene in genes:
            handle.write(f"{gene}\t{gene}\tGene Expression\n")
    with gzip.open(matrix_dir / "barcodes.tsv.gz", "wt") as handle:
        handle.write("\n".join(barcodes) + "\n")
    pd.DataFrame({"barcode": barcodes, "in_tissue": np.ones(nr * nc, dtype=np.int32),
                  "array_row": rows, "array_col": cols,
                  "pxl_row_in_fullres": (rows.astype(float) + 0.5) * 2 / mpp,
                  "pxl_col_in_fullres": (cols.astype(float) + 0.5) * 2 / mpp}).to_parquet(
        spatial_dir / "tissue_positions.parquet", index=False)
    _write_json(spatial_dir / "scalefactors_json.json", {"microns_per_pixel": mpp})
    meta = {"image_mpp": mpp, "proseg_axis_order": axis_order,
            "mask_pixel_center_offset": 0.5, "seed_filename": "seeds.npy"}
    native_out = out / "native_output"
    native_out.mkdir()
    cmd = build_proseg_command(out, native_out, meta,
                               {"executable": executable, "nthreads": 2, "write_transcript_metadata": True})
    # The final argument is the input directory. Add fixture-only flags before it.
    cmd[-1:-1] = ["--no-diffusion", "--morphology-steps-per-iter", "0",
                  "--burnin-samples", "0", "--samples", "1", "--recorded-samples", "1",
                  "--hillclimb", "0", "--ncomponents", "2"]
    _write_json(out / "command.json", {"argv": cmd})
    with open(out / "proseg.log", "w", buffering=1) as log:
        result = subprocess.run(cmd, cwd=native_out, stdout=log, stderr=subprocess.STDOUT,
                                text=True, check=False)
    if result.returncode:
        raise RuntimeError(f"Proseg coordinate fixture failed with code {result.returncode}. Inspect {out / 'proseg.log'}")
    observed = pd.read_parquet(native_out / "transcript_metadata.parquet")
    required_columns = {"observed_x", "observed_y", "gene"}
    if not required_columns.issubset(observed):
        raise RuntimeError("Installed Proseg output omits original observed coordinates needed for this test.")
    actual = observed.groupby(["observed_x", "observed_y", "gene"], observed=True).size().rename("count")
    expected = pd.DataFrame(expected_observations, columns=["observed_x", "observed_y", "gene", "count"])
    expected = expected.set_index(["observed_x", "observed_y", "gene"])["count"]
    comparison = pd.concat([expected.rename("expected"), actual.rename("actual")], axis=1).fillna(0)
    if not np.array_equal(comparison["expected"].to_numpy(), comparison["actual"].to_numpy()):
        comparison[comparison.expected != comparison.actual].to_csv(out / "coordinate_mismatches.csv")
        raise ValueError("Proseg native-reader observed coordinates/counts failed the asymmetric test; inspect axis order before production.")
    cells = pd.read_csv(native_out / "cell_metadata.csv.gz", dtype={"original_cell_id": str})
    ids = _numeric_seed_ids(cells["original_cell_id"])
    if set(ids) != set(expected_centroids):
        raise ValueError("Proseg fixture did not retain all known masks; inspect the installed mask importer before production.")
    target_xy = np.asarray([expected_centroids[int(i)] for i in ids])
    got_xy = cells[["centroid_x", "centroid_y"]].to_numpy(dtype=float)
    distances = np.linalg.norm(got_xy - target_xy, axis=1)
    # Native 2-µm voxelization changes a mask centroid by up to about one voxel.
    if not np.isfinite(distances).all() or distances.max() > 3.0:
        raise ValueError("Unchanged-mask centroids disagree with the native image transform by >3 µm.")
    evidence = {"status": "passed", "executable": probe["executable"],
                "executable_sha256": _sha256(probe["executable"]), "version": probe["version"],
                "proseg_axis_order": axis_order, "image_mpp": mpp,
                "mask_pixel_center_offset": 0.5,
                "n_observed_molecules": len(observed), "n_masks": len(ids),
                "max_unchanged_mask_centroid_error_um": float(distances.max()),
                "purpose": "native reader coordinates/counts and mask transform only; no accuracy/timing benchmark"}
    report_path = out / "coordinate_validation.json"
    _write_json(report_path, evidence)
    return report_path


def _check_proseg_coordinate_evidence(config, meta, probe):
    path = config.get("coordinate_validation_json")
    if not path:
        raise ValueError("Run validate_proseg_coordinates(...) once and supply its coordinate_validation_json path. Production inputs have not been run.")
    evidence = json.loads(Path(path).expanduser().read_text())
    expected = {"status": "passed", "executable": probe["executable"],
                "version": probe["version"], "executable_sha256": _sha256(probe["executable"]),
                "proseg_axis_order": meta["proseg_axis_order"],
                "image_mpp": float(meta["image_mpp"]),
                "mask_pixel_center_offset": float(meta.get("mask_pixel_center_offset", 0.5))}
    mismatches = [key for key, value in expected.items() if evidence.get(key) != value]
    if mismatches:
        raise ValueError(f"Proseg coordinate evidence does not match this executable/input convention: {mismatches}")
    return evidence


def _validate_native_proseg_inputs(native, bins, meta):
    """Ensure Proseg sees exactly the same observations as the Python methods."""
    import numpy as np
    import pandas as pd
    import pyarrow as pa
    import pyarrow.parquet as pq
    import scipy.io
    import scipy.sparse as sp
    native = Path(native)
    matrix = native / "raw_feature_bc_matrix"
    with gzip.open(matrix / "barcodes.tsv.gz", "rt") as handle:
        barcodes = [line.rstrip("\r\n") for line in handle]
    with gzip.open(matrix / "features.tsv.gz", "rt") as handle:
        features = [line.rstrip("\r\n").split("\t") for line in handle]
    if barcodes != bins.obs_names.tolist():
        raise ValueError("Native Proseg and AnnData input barcode order differ.")
    if any(len(row) < 3 for row in features) or [row[1] for row in features] != bins.var_names.tolist():
        raise ValueError("Native Proseg gene symbols/order differ from bins.h5ad.")
    native_counts = sp.csr_matrix(scipy.io.mmread(matrix / "matrix.mtx.gz").T)
    if native_counts.shape != bins.X.shape or (native_counts - bins.X).nnz:
        raise ValueError("Native Proseg count matrix differs from the shared raw bin matrix.")
    table = pq.read_table(native / "spatial" / "tissue_positions.parquet")
    for name, expected in (("barcode", pa.string()), ("pxl_row_in_fullres", pa.float64()),
                           ("pxl_col_in_fullres", pa.float64())):
        if table.schema.field(name).type != expected:
            raise TypeError(f"Installed native Proseg reader requires Arrow {expected} for {name}; found {table.schema.field(name).type}.")
    pos = table.to_pandas().set_index("barcode").reindex(bins.obs_names)
    expected_xy = np.asarray(bins.obsm["spatial"])
    actual_xy = pos[["pxl_col_in_fullres", "pxl_row_in_fullres"]].to_numpy(dtype=float)
    if not np.allclose(actual_xy, expected_xy, rtol=0, atol=1e-6):
        raise ValueError("Native Proseg tissue positions differ from the shared bin centers.")
    sf = json.loads((native / "spatial" / "scalefactors_json.json").read_text())
    if float(sf["microns_per_pixel"]) != float(meta["image_mpp"]):
        raise ValueError("Native Proseg image scale differs from the shared input scale.")


def run_proseg(input_dir, output_dir, config=None):
    """Run the user's absolute-path Proseg executable on native 2-µm inputs."""
    supplied = dict(config or {})
    if "threads" in supplied:
        if "nthreads" in supplied and supplied["threads"] != supplied["nthreads"]:
            raise ValueError("Conflicting Proseg threads/nthreads values.")
        supplied["nthreads"] = supplied["threads"]
    cfg = {"executable": DEFAULT_PROSEG_EXE, "nthreads": 32,
           "write_transcript_metadata": True, **supplied}
    with _Run("proseg", input_dir, output_dir, cfg) as run:
        with run.stage("load_and_validate"):
            import anndata as ad
            import numpy as np
            import pandas as pd
            import scipy.io
            import scipy.sparse as sp
            bins, seeds, meta, _, diag = validate_input(input_dir)
            run.report.update(diag)
            probe = probe_proseg(cfg["executable"])
            (run.output / "proseg_help.txt").write_text(probe.pop("help"))
            run.report["proseg"] = probe
            if "axis_order" in cfg and cfg["axis_order"] != meta.get("proseg_axis_order"):
                raise ValueError("Proseg config axis_order disagrees with the input metadata.")
            run.report["coordinate_validation"] = _check_proseg_coordinate_evidence(cfg, meta, probe)
            native = Path(input_dir) / "binned_outputs" / "square_002um"
            for rel in ("raw_feature_bc_matrix/matrix.mtx.gz", "raw_feature_bc_matrix/features.tsv.gz",
                        "raw_feature_bc_matrix/barcodes.tsv.gz", "spatial/tissue_positions.parquet",
                        "spatial/scalefactors_json.json"):
                if not (native / rel).is_file():
                    raise FileNotFoundError(native / rel)
            _validate_native_proseg_inputs(native, bins, meta)
            cmd = build_proseg_command(input_dir, output_dir, meta, cfg)
            _write_json(run.output / "command.json", {"argv": cmd})
        with run.stage("native_process_including_io"):
            with open(run.output / "proseg.log", "w", buffering=1) as log:
                process = subprocess.Popen(cmd, cwd=run.output, stdout=subprocess.PIPE,
                                           stderr=subprocess.STDOUT, text=True, bufsize=1)
                assert process.stdout is not None
                try:
                    for line in process.stdout:
                        print(line, end="")
                        log.write(line)
                    rc = process.wait()
                except BaseException:
                    process.terminate()
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.wait()
                    raise
                finally:
                    process.stdout.close()
                if rc:
                    raise RuntimeError(f"Proseg returned code {rc}. See {run.output / 'proseg.log'}")
        with run.stage("standardize_and_write"):
            cells = pd.read_csv(run.output / "cell_metadata.csv.gz", dtype={"original_cell_id": str})
            genes = pd.read_csv(run.output / "gene_metadata.csv.gz", dtype={"gene": str})
            if "original_cell_id" not in cells or "cell" not in cells or "gene" not in genes:
                raise RuntimeError("Proseg output metadata schema changed; no centroid rematching is allowed.")
            if not np.array_equal(cells["cell"].to_numpy(), np.arange(len(cells))):
                raise ValueError("Proseg cell metadata order is not the matrix's documented 0-based row order.")
            X = sp.csr_matrix(scipy.io.mmread(run.output / "counts.mtx.gz"))
            if X.shape != (len(cells), len(genes)):
                raise ValueError("Proseg raw count matrix is not cell-by-gene in its metadata order.")
            cells.index = pd.Index(cells["cell"].astype(str), name="proseg_cell")
            cdata = ad.AnnData(X=X, obs=cells, var=pd.DataFrame(index=pd.Index(genes["gene"].astype(str))))
            if {"centroid_x", "centroid_y"}.issubset(cells.columns):
                xy_native = cells[["centroid_x", "centroid_y"]].to_numpy(dtype=float)
                if meta["proseg_axis_order"] == "row_col":
                    xy_native = xy_native[:, ::-1]
                cdata.obsm["spatial"] = xy_native / float(meta["image_mpp"])
            _finish_counts(cdata, bins, seeds, run, seed_values=cells["original_cell_id"])
            run.report["initialization_audit_note"] = "Proseg does not expose a separate accepted-seed list here; seed_audit initialization field means offered, with final retention recorded separately."
            run.report["timing_note"] = "Native process wall time includes Proseg's input/output. Its internal inference cannot be isolated by this CLI adapter; do not compare this stage directly with Python assignment-only times."
            run.report["randomness_note"] = "Current native Proseg is stochastic without a public deterministic seed option; run repeated trials."
    return run.report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("method", choices=["bin2cell", "smurf", "proseg"])
    parser.add_argument("input_dir")
    parser.add_argument("output_dir")
    parser.add_argument("--config", type=Path, help="JSON containing this method's configuration dictionary")
    args = parser.parse_args()
    cfg = json.loads(args.config.read_text()) if args.config else {}
    runner = {"bin2cell": run_bin2cell, "smurf": run_smurf, "proseg": run_proseg}[args.method]
    report = runner(args.input_dir, args.output_dir, cfg)
    print(json.dumps(report, indent=2, default=_json_default))


if __name__ == "__main__":
    main()
