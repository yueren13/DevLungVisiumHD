"""Bounded patch reads, transcript filtering, 2-µm binning and core review.

Inputs use the verified physical frame defined in inventory.CoordinateSpec.
The image is sampled onto a declared output pixel grid; molecules retain their
unshifted measured XY until binning. H&E and nuclei perturbations belong later.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping
import json

import numpy as np
import pandas as pd
from scipy import sparse

from .inventory import CoordinateSpec, _affine, apply_affine, element_to_um, text_ids

UNKNOWN_REFERENCE = "__unassigned__"


def _bounds(bounds_um: Iterable[float]) -> tuple[float,float,float,float]:
    bounds = tuple(map(float,bounds_um))
    if len(bounds) != 4 or not np.isfinite(bounds).all() or bounds[2] <= bounds[0] or bounds[3] <= bounds[1]:
        raise ValueError("bounds_um must be finite x0,y0,x1,y1 with positive width/height.")
    return bounds


def core_bounds(center_x_um: float, center_y_um: float, *, core_size_um=500.0,
                halo_um=100.0, bin_size_um=2.0, grid_origin_um=(0.0,0.0)) -> dict:
    """Snap the lower left to the global bin grid; keep the adjustment explicit."""
    if core_size_um <= 0 or halo_um < 0 or bin_size_um <= 0:
        raise ValueError("Core and bin size must be positive; halo must be nonnegative.")
    if not np.isclose(core_size_um/bin_size_um, round(core_size_um/bin_size_um)) or not np.isclose(halo_um/bin_size_um,round(halo_um/bin_size_um)):
        raise ValueError("Core size and halo must be integer multiples of bin_size_um.")
    requested = np.array([center_x_um, center_y_um],float)
    origin = np.asarray(grid_origin_um,float)
    corner = origin + np.floor((requested-core_size_um/2-origin)/bin_size_um)*bin_size_um
    center = corner+core_size_um/2
    return {"center_x_um":float(center[0]),"center_y_um":float(center[1]),
            "requested_center_x_um":float(requested[0]),"requested_center_y_um":float(requested[1]),
            "core_bounds_um":[float(corner[0]),float(corner[1]),float(corner[0]+core_size_um),float(corner[1]+core_size_um)],
            "read_bounds_um":[float(corner[0]-halo_um),float(corner[1]-halo_um),float(corner[0]+core_size_um+halo_um),float(corner[1]+core_size_um+halo_um)],
            "core_size_um":float(core_size_um),"halo_um":float(halo_um),"bin_size_um":float(bin_size_um)}


def point_in_core(x: Any, y: Any, core: Mapping, *, include_halo=False) -> np.ndarray:
    bounds = core["read_bounds_um" if include_halo else "core_bounds_um"]
    x0,y0,x1,y1 = _bounds(bounds)
    x = np.asarray(x); y = np.asarray(y)
    valid = (x>=x0)&(x<x1)&(y>=y0)&(y<y1)
    if not include_halo and core.get("core_shape","square") == "circle":
        radius = (x1-x0)/2
        valid &= (x-(x0+x1)/2)**2+(y-(y0+y1)/2)**2 <= radius**2
    return valid


def suggest_candidates(cells: pd.DataFrame, *, sample_id: str, component_column="component",
                       core_size_um=500.0, halo_um=100.0, spacing_um=700.0,
                       min_cells=100, max_candidates_per_component=60, seed=2026) -> pd.DataFrame:
    """Uniform spatial-grid candidate centers with density estimates.

    These are *unreviewed candidates*, not automatically good/poor alignments.
    Each component comes from matched annotations; cells lacking annotation are
    still counted in the original-cell density. No alignment is inferred from
    8–9 sparse registration landmarks.
    """
    needed={"sample_id","reference_cell_id","x_um","y_um"}
    if not needed.issubset(cells):
        raise ValueError(f"Reference cells missing {sorted(needed-set(cells))}.")
    frame=cells[cells.sample_id.astype(str)==str(sample_id)].copy()
    if frame.empty: raise ValueError(f"No reference cells for sample {sample_id}.")
    if component_column not in frame: frame[component_column]=str(sample_id)
    assigned=frame[frame[component_column].notna()]
    rows=[]; rng=np.random.default_rng(seed)
    for component, group in assigned.groupby(component_column,sort=True):
        xy=group[["x_um","y_um"]].to_numpy(float)
        quantized=np.floor(xy/spacing_um).astype(np.int64)
        for ix,iy in np.unique(quantized,axis=0):
            center=np.array([(ix+.5)*spacing_um,(iy+.5)*spacing_um])
            core=core_bounds(*center,core_size_um=core_size_um,halo_um=halo_um)
            hit=point_in_core(frame.x_um,frame.y_um,core)
            nhit=int(hit.sum())
            in_component=hit & (frame[component_column].astype(str).to_numpy()==str(component))
            if nhit<int(min_cells) or in_component.sum()==0: continue
            annotated=frame.loc[hit,component_column].notna()
            rows.append({"sample_id":str(sample_id),"component":str(component),
                         **{k:v for k,v in core.items() if not k.endswith("bounds_um")},
                         "n_reference_cells":nhit,"n_component_cells":int(in_component.sum()),
                         "annotation_coverage":float(annotated.mean()),
                         "component_purity_among_annotated":float(in_component.sum()/max(annotated.sum(),1)),
                         "candidate_status":"unreviewed","alignment_group":"", "selected":False,
                         "residual_median_um":np.nan,"residual_p90_um":np.nan,"n_validation_landmarks":0})
    if not rows: return pd.DataFrame(columns=["core_id","sample_id","component","center_x_um","center_y_um","selected"])
    result=pd.DataFrame(rows)
    pieces=[]
    for _, group in result.groupby("component",sort=True):
        if len(group)>max_candidates_per_component:
            group=group.iloc[np.sort(rng.choice(len(group),max_candidates_per_component,replace=False))]
        pieces.append(group)
    result=pd.concat(pieces,ignore_index=True).sort_values(["component","center_y_um","center_x_um"]).reset_index(drop=True)
    result.insert(0,"core_id",[f"{sample_id}_candidate_{i+1:04d}" for i in range(len(result))])
    return result


def selected_core_records(selection: pd.DataFrame, *, core_size_um=500.0,halo_um=100.0,
                          bin_size_um=2.0, require_residual_review=True, allow_overlap=False) -> list[dict]:
    required={"core_id","sample_id","component","center_x_um","center_y_um","alignment_group","selected"}
    if not required.issubset(selection): raise ValueError(f"Selection missing {sorted(required-set(selection))}")
    # Explicit string parsing avoids bool('False') == True after CSV round trips.
    selected=selection.selected.astype(str).str.lower().isin(["true","1","yes"])
    chosen=selection[selected].copy()
    if chosen.empty: raise ValueError("No cores selected. Review candidate overlays and select cores before building inputs.")
    if chosen.core_id.duplicated().any(): raise ValueError("core_id must be unique.")
    if not chosen.alignment_group.isin(["good","poor","development"]).all():
        raise ValueError("Selected alignment_group must be good, poor or development after image review.")
    if require_residual_review:
        needed=["n_validation_landmarks","residual_median_um","residual_p90_um"]
        if not set(needed).issubset(chosen) or chosen[needed].isna().any(axis=None):
            raise ValueError("Record held-out local landmark counts/median/p90 µm in the selection table.")
        if (pd.to_numeric(chosen.n_validation_landmarks)<3).any():
            raise ValueError("At least 3 distinct reviewed local correspondence landmarks per core are required by this design.")
    output=[]
    for row in chosen.to_dict("records"):
        row.update(core_bounds(row["center_x_um"],row["center_y_um"],core_size_um=core_size_um,halo_um=halo_um,bin_size_um=bin_size_um))
        row.setdefault("core_shape","square")
        output.append(row)
    if not allow_overlap:
        for i,a in enumerate(output):
            for b in output[i+1:]:
                if str(a["sample_id"])!=str(b["sample_id"]): continue
                aa=a["core_bounds_um"]; bb=b["core_bounds_um"]
                if max(aa[0],bb[0])<min(aa[2],bb[2]) and max(aa[1],bb[1])<min(aa[3],bb[3]):
                    raise ValueError(f"Scored cores overlap: {a['core_id']} and {b['core_id']}. Move one or explicitly document overlap; avoid duplicated scoring cells.")
    return output


def canonicalize_transcripts(frame: pd.DataFrame, transform_to_um: Any, *, genes: Iterable[str],
                            columns: Mapping | None=None, min_qv=20.0,
                            unassigned_values=("UNASSIGNED","Unassigned","unassigned","-1","",None),
                            reference_ids: Iterable[str] | None=None) -> tuple[pd.DataFrame,dict]:
    columns={"x":"x","y":"y","gene":"feature_name","cell_id":"cell_id","qv":"qv","transcript_id":"transcript_id",**(columns or {})}
    required=[columns[k] for k in ("x","y","gene","cell_id")]
    if min_qv is not None: required.append(columns["qv"])
    missing=set(required)-set(frame)
    if missing: raise ValueError(f"Transcript columns absent: {sorted(missing)}. Configure columns or explicitly set min_qv=None only when the earlier filtering policy is documented.")
    xy=apply_affine(frame[[columns["x"],columns["y"]]].to_numpy(float),transform_to_um)
    gene=text_ids(frame[columns["gene"]].to_numpy()).reset_index(drop=True)
    ids=text_ids(frame[columns["cell_id"]].to_numpy()).reset_index(drop=True)
    finite=np.isfinite(xy).all(axis=1)
    gene_keep=gene.isin(genes if isinstance(genes,pd.Index) else set(map(str,genes))).to_numpy()
    quality=np.ones(len(frame),bool) if min_qv is None else pd.to_numeric(frame[columns["qv"]],errors="coerce").to_numpy()>=float(min_qv)
    keep=finite&gene_keep&quality
    sentinel={str(x) for x in unassigned_values if x is not None}
    unknown=ids.isna()|ids.isin(sentinel)
    ids=ids.mask(unknown,UNKNOWN_REFERENCE)
    if reference_ids is not None:
        bad=~ids.isin(reference_ids if isinstance(reference_ids,pd.Index) and UNKNOWN_REFERENCE in reference_ids else set(map(str,reference_ids))|{UNKNOWN_REFERENCE})
        if (bad.to_numpy()&keep).any():
            raise ValueError(f"Eligible molecules reference unknown non-sentinel cell IDs: {ids[bad&keep].head(8).tolist()}. Check sample source and barcode mapping.")
    result=pd.DataFrame({"x_um":xy[keep,0],"y_um":xy[keep,1],"gene":gene[keep].to_numpy(),"reference_cell_id":ids[keep].to_numpy()})
    if columns["transcript_id"] in frame:
        result["transcript_id"]=text_ids(frame[columns["transcript_id"]].to_numpy())[keep].to_numpy()
    if columns["qv"] in frame:
        result["qv"]=pd.to_numeric(frame[columns["qv"]],errors="coerce").to_numpy()[keep]
    audit={"input_rows":len(frame),"kept_rows":len(result),"nonfinite_xy":int((~finite).sum()),
           "outside_gene_universe":int((~gene_keep).sum()),"below_qv_or_missing_qv":int((~quality).sum()),
           "kept_unassigned":int((result.reference_cell_id==UNKNOWN_REFERENCE).sum()),
           "min_qv":min_qv, "categories_are_overlapping":True}
    return result,audit


def iter_transcript_regions(points: Any, cores: list[dict], *, transform_to_um: Any,
                            genes: Iterable[str], columns: Mapping | None=None,
                            min_qv=20.0, reference_ids=None, emit_empty=False,
                            unassigned_values=None):
    """Scan each Dask partition once and yield bounded canonical core chunks.

    Each yield is ``(core_id, frame, partition_audit)``. Context halos may
    overlap, so the same molecule can legitimately appear in two core inputs;
    scored interiors are independently checked for overlap. The full slide is
    never collected into one DataFrame.
    """
    if not cores: raise ValueError("No cores supplied.")
    columns={"x":"x","y":"y","gene":"feature_name","cell_id":"cell_id","qv":"qv","transcript_id":"transcript_id",**(columns or {})}
    if isinstance(points,(str,Path)):
        import pyarrow.parquet as pq
        pqfile=pq.ParquetFile(points)
        needed=[c for c in dict.fromkeys(columns.values()) if c in pqfile.schema_arrow.names]
        partitions=(b.to_pandas() for b in pqfile.iter_batches(columns=needed,batch_size=250_000,use_threads=True))
    else:
        needed=[c for c in dict.fromkeys(columns.values()) if c in points.columns]
        source=points[needed]
        partitions=source.to_delayed() if hasattr(source,"to_delayed") else [source]
    if reference_ids is not None:
        reference_ids = pd.Index(list(map(str,reference_ids)) + [UNKNOWN_REFERENCE])
    genes = pd.Index(list(map(str,genes)))
    for partition_number,part in enumerate(partitions):
        frame=part.compute() if hasattr(part,"compute") else part
        extra={} if unassigned_values is None else {"unassigned_values":unassigned_values}
        canonical,audit=canonicalize_transcripts(frame,transform_to_um,genes=genes,columns=columns,min_qv=min_qv,reference_ids=reference_ids,**extra)
        audit["partition_number"]=partition_number
        for core in cores:
            keep=point_in_core(canonical.x_um,canonical.y_um,core,include_halo=True)
            if keep.any() or emit_empty:
                yield str(core["core_id"]),canonical.loc[keep].reset_index(drop=True),dict(audit)


def write_transcript_core_parts(points: Any, cores: list[dict], output_dir: str | Path, **kwargs) -> dict:
    """Persist core chunks to Parquet datasets; existing outputs are refused."""
    output=Path(output_dir)
    if output.exists() and any(output.iterdir()): raise FileExistsError(f"Refusing to mix prior transcript chunks with this run: {output}")
    output.mkdir(parents=True,exist_ok=True)
    counts={str(c["core_id"]):0 for c in cores}; parts={k:0 for k in counts}; audits={}
    for core_id,frame,audit in iter_transcript_regions(points,cores,emit_empty=True,**kwargs):
        audits[audit["partition_number"]]=audit
        if frame.empty:
            continue
        dest=output/core_id; dest.mkdir(parents=True,exist_ok=True)
        frame.to_parquet(dest/f"part_{parts[core_id]:06d}.parquet",index=False)
        counts[core_id]+=len(frame); parts[core_id]+=1
    result={"core_rows":counts,"parts":parts,"partition_audits":list(audits.values()),
            "note":"Core row totals count overlapping halos more than once; partition audit categories overlap."}
    (output/"extraction_audit.json").write_text(json.dumps(result,indent=2))
    if any(n==0 for n in counts.values()):
        raise ValueError(f"No eligible molecules in cores {[k for k,v in counts.items() if v==0]}; inspect coordinates and filters.")
    return result


@dataclass
class BinnedPatch:
    counts: sparse.csr_matrix
    bins: pd.DataFrame
    genes: list[str]
    contributions: pd.DataFrame
    metadata: dict

    def to_anndata(self):
        import anndata as ad
        result=ad.AnnData(self.counts.copy(),obs=self.bins.copy().set_index("barcode",drop=False),var=pd.DataFrame(index=self.genes))
        result.obsm["spatial"]=self.bins[["pxl_col_in_fullres","pxl_row_in_fullres"]].to_numpy(float)
        result.uns["p06212_input"]=self.metadata
        return result


def bin_transcripts(frame: pd.DataFrame, bounds_um: Iterable[float], *, genes: Iterable[str],
                    bin_size_um=2.0,image_mpp=0.5,core: Mapping|None=None,
                    max_grid_bins=4_000_000) -> BinnedPatch:
    """Bin measured molecules once; keep reference contribution table hidden.

    Barcodes and rows cover the entire rectangular grid, including zero bins.
    Boundary coordinates are half-open. The output pixel center is expressed
    in the full-resolution patch image's boundary-origin pixel coordinates.
    """
    x0,y0,x1,y1=_bounds(bounds_um)
    if bin_size_um<=0 or image_mpp<=0: raise ValueError("bin_size_um and image_mpp must be positive.")
    shape_float=np.array([(y1-y0)/bin_size_um,(x1-x0)/bin_size_um])
    if not np.allclose(shape_float,np.rint(shape_float),atol=1e-8,rtol=0): raise ValueError("Patch extent must be divisible by bin_size_um.")
    h,w=np.rint(shape_float).astype(int)
    if h*w>max_grid_bins: raise MemoryError("Full rectangular bin grid exceeds max_grid_bins.")
    gene_list=list(map(str,genes))
    if not gene_list or len(gene_list)!=len(set(gene_list)): raise ValueError("genes must be a fixed unique nonempty universe.")
    need={"x_um","y_um","gene","reference_cell_id"}
    if not need.issubset(frame): raise ValueError(f"Canonical transcripts missing {sorted(need-set(frame))}")
    xy=frame[["x_um","y_um"]].to_numpy(float)
    inside=(xy[:,0]>=x0)&(xy[:,0]<x1)&(xy[:,1]>=y0)&(xy[:,1]<y1)&np.isfinite(xy).all(axis=1)
    sub=frame.loc[inside].copy()
    col=np.floor((sub.x_um.to_numpy()-x0)/bin_size_um).astype(np.int64)
    row=np.floor((sub.y_um.to_numpy()-y0)/bin_size_um).astype(np.int64)
    linear=row*w+col
    gene_index=pd.Index(gene_list).get_indexer(sub.gene.astype(str))
    if (gene_index<0).any(): raise ValueError("Transcript gene not in fixed gene universe; filter explicitly before binning.")
    counts=sparse.coo_matrix((np.ones(len(sub),np.int64),(linear,gene_index)),shape=(h*w,len(gene_list))).tocsr()
    rr,cc=np.divmod(np.arange(h*w,dtype=np.int64),w)
    barcode=[f"s_002um_{r:05d}_{c:05d}-1" for r,c in zip(rr,cc)]
    bins=pd.DataFrame({"barcode":barcode,"array_row":rr,"array_col":cc,
                       "x_um":x0+(cc+.5)*bin_size_um,"y_um":y0+(rr+.5)*bin_size_um,
                       "pxl_row_in_fullres":(rr+.5)*bin_size_um/image_mpp,
                       "pxl_col_in_fullres":(cc+.5)*bin_size_um/image_mpp,
                       "in_tissue":np.ones(h*w,np.int8)})
    bins["total_counts"]=np.asarray(counts.sum(axis=1)).ravel()
    bins["score_bin"]=point_in_core(bins.x_um,bins.y_um,core) if core is not None else True
    sub["barcode"]=np.asarray(barcode,dtype=object)[linear]
    truth=(sub.groupby(["barcode","gene","reference_cell_id"],observed=True,dropna=False,sort=False).size().rename("count").reset_index())
    if int(counts.sum())!=len(sub) or int(truth["count"].sum())!=len(sub): raise AssertionError("Binning lost or duplicated molecules.")
    metadata={"bin_size_um":float(bin_size_um),"image_mpp":float(image_mpp),"bounds_um":list(map(float,(x0,y0,x1,y1))),
              "grid_shape_yx":[int(h),int(w)],"input_molecules":int(len(frame)),"binned_molecules":int(len(sub)),
              "excluded_outside_patch":int((~inside).sum()),"coordinate_frame":"original Xenium morphology µm",
              "reference_access":"contributions is hidden evaluator data; never expose it to a method", "full_grid_including_zero_bins":True}
    return BinnedPatch(counts,bins,gene_list,truth,metadata)


def extract_image_patch(he_reader: Any, dapi_source: Any, he_to_native_pixel_xy: Any,
                        bounds_um: Iterable[float], spec: CoordinateSpec, *, image_mpp=0.5,
                        force_level0=True,max_read_mib=192,max_output_pixels=25_000_000):
    """Read H&E and DAPI into one physical patch canvas without whole-slide I/O."""
    from .vendor.qc_helpers import he_preview,dapi_preview
    spec.validate(); bounds=_bounds(bounds_um)
    shape=np.array([(bounds[3]-bounds[1])/image_mpp,(bounds[2]-bounds[0])/image_mpp])
    if not np.allclose(shape,np.rint(shape),atol=1e-8,rtol=0): raise ValueError("Patch extent must be divisible by image_mpp.")
    shape=tuple(np.rint(shape).astype(int))
    if np.prod(shape)>max_output_pixels: raise MemoryError("Patch exceeds max_output_pixels.")
    native_bounds=tuple(np.asarray(bounds)/float(spec.morphology_pixel_size_um))
    he,he_valid,he_log=he_preview(he_reader,_affine(he_to_native_pixel_xy),native_bounds,output_shape=shape,
                                 force_level0=force_level0,max_read_mib=max_read_mib)
    dapi,dapi_valid,dapi_log=dapi_preview(dapi_source,native_bounds,output_shape=shape,
                                        force_level0=force_level0,max_read_mib=max_read_mib)
    metadata={"bounds_um":list(bounds),"image_mpp":float(image_mpp),"shape_yx":list(map(int,shape)),
              "he_log":he_log,"dapi_log":dapi_log,"coordinate_spec":spec.as_dict(),
              "patch_boundary_pixel_to_um":[[float(image_mpp),0,bounds[0]],[0,float(image_mpp),bounds[1]],[0,0,1]]}
    return {"he":np.round(np.clip(he,0,1)*255).astype(np.uint8),"dapi":dapi,
            "he_valid":he_valid,"dapi_valid":dapi_valid,"metadata":metadata}


def rasterize_reference_geometry(geometry: Any, bounds_um: Iterable[float], *, image_mpp=0.5,
                                 max_output_pixels=25_000_000, overlap_policy="error",
                                 conflict_mask_path: str | Path | None=None) -> tuple[np.ndarray,pd.DataFrame,dict]:
    """Rasterize hidden reference polygons with an explicit integer→barcode map.

    Multiple nuclei from a reference cell share an integer label; we retain
    the geometry count in the map. ``overlap_policy='error'`` refuses any
    intercell overlap. The explicit ``'exclude'`` policy sets conflicting
    pixels to background, flags BOTH cells in the ID map, and records every
    affected barcode. Exclude flagged reference cells from primary seed
    matching, but retain their molecules in benchmark inputs/reference totals.
    """
    from skimage.draw import polygon
    if overlap_policy not in {"error","exclude"}:
        raise ValueError("overlap_policy must be 'error' or 'exclude'.")
    bounds=_bounds(bounds_um); x0,y0,x1,y1=bounds
    shape_float=np.array([(y1-y0)/image_mpp,(x1-x0)/image_mpp])
    if not np.allclose(shape_float,np.rint(shape_float),atol=1e-8,rtol=0): raise ValueError("Extent must be divisible by image_mpp.")
    h,w=np.rint(shape_float).astype(int)
    if h*w>max_output_pixels: raise MemoryError("Reference raster exceeds max_output_pixels.")
    boxes=geometry.geometry.bounds
    keep=(boxes.maxx>x0)&(boxes.minx<x1)&(boxes.maxy>y0)&(boxes.miny<y1)
    chosen=geometry.loc[keep]
    ids=sorted(chosen.reference_cell_id.astype(str).unique())
    id_to_label={value:i+1 for i,value in enumerate(ids)}
    labels=np.zeros((h,w),np.uint32); conflict_mask=np.zeros((h,w),bool); conflicting_labels=set()
    def parts(geom):
        if geom.geom_type=="Polygon": return [geom]
        if geom.geom_type=="MultiPolygon": return list(geom.geoms)
        raise TypeError(f"Expected Polygon/MultiPolygon, got {geom.geom_type}.")
    for _,row in chosen.iterrows():
        value=id_to_label[str(row.reference_cell_id)]
        for poly in parts(row.geometry):
            coords=np.asarray(poly.exterior.coords)
            rr,cc=polygon((coords[:,1]-y0)/image_mpp-.5,(coords[:,0]-x0)/image_mpp-.5,shape=(h,w))
            if not len(rr): continue
            local=np.zeros((int(rr.max()-rr.min()+1),int(cc.max()-cc.min()+1)),bool)
            rbase=int(rr.min());cbase=int(cc.min());local[rr-rbase,cc-cbase]=True
            for ring in poly.interiors:
                hole=np.asarray(ring.coords)
                r,c=polygon((hole[:,1]-y0)/image_mpp-.5-rbase,(hole[:,0]-x0)/image_mpp-.5-cbase,shape=local.shape)
                local[r,c]=False
            target=labels[rbase:rbase+local.shape[0],cbase:cbase+local.shape[1]]
            overlap=local&(target!=0)&(target!=value)
            if overlap.any():
                conflicting_labels.update(int(x) for x in np.unique(target[overlap]))
                conflicting_labels.add(value)
                conflict_mask[rbase:rbase+local.shape[0],cbase:cbase+local.shape[1]] |= overlap
            target[local]=value
    conflict=int(conflict_mask.sum())
    if conflict and overlap_policy=="error":
        raise ValueError(f"Hidden reference geometry overlaps by {conflict} raster pixels between different cells. Audit reference geometry before matching.")
    if conflict:
        labels[conflict_mask]=0
    if conflict_mask_path is not None:
        path=Path(conflict_mask_path)
        path.parent.mkdir(parents=True,exist_ok=True)
        if path.exists():
            raise FileExistsError(f"Refusing to overwrite reference ambiguity mask: {path}")
        np.save(path,conflict_mask)
    mapping=pd.DataFrame({"reference_label":range(1,len(ids)+1),"reference_cell_id":ids})
    counts=chosen.groupby(chosen.reference_cell_id.astype(str)).size()
    mapping["n_geometry_parts"]=mapping.reference_cell_id.map(counts)
    mapping["ambiguous_reference_overlap"]=mapping.reference_label.isin(conflicting_labels)
    return labels,mapping,{"shape_yx":[int(h),int(w)],"n_reference_cells":len(ids),"conflicting_pixels":conflict,
                           "conflicting_reference_ids":mapping.loc[mapping.ambiguous_reference_overlap,"reference_cell_id"].tolist(),
                           "overlap_policy":overlap_policy,"conflict_mask_path":str(conflict_mask_path) if conflict_mask_path else None,
                           "image_mpp":float(image_mpp),"bounds_um":list(bounds),"sampling":"pixel centers"}


def residuals_from_local_landmarks(landmarks: pd.DataFrame, *, he_to_native_pixel_xy: Any,
                                  morphology_pixel_size_um: float) -> tuple[pd.DataFrame,pd.DataFrame]:
    """Local independent H&E/DAPI correspondences; do not refit on these."""
    required={"core_id","he_x_px","he_y_px","dapi_x_native_px","dapi_y_native_px"}
    if not required.issubset(landmarks): raise ValueError(f"Local landmarks missing {sorted(required-set(landmarks))}.")
    target=apply_affine(landmarks[["he_x_px","he_y_px"]],he_to_native_pixel_xy)
    fixed=landmarks[["dapi_x_native_px","dapi_y_native_px"]].to_numpy(float)
    delta=(target-fixed)*float(morphology_pixel_size_um)
    output=landmarks.copy();output["residual_dx_um"]=delta[:,0];output["residual_dy_um"]=delta[:,1]
    output["residual_um"]=np.linalg.norm(delta,axis=1)
    summary=output.groupby("core_id").agg(n_validation_landmarks=("residual_um","size"),residual_median_um=("residual_um","median"),
                                          residual_p90_um=("residual_um",lambda a:np.quantile(a,.9)),residual_max_um=("residual_um","max")).reset_index()
    return output,summary
