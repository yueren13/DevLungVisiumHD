"""Collect measured benchmark outputs and draw a compact scientific report.

No scores, uncertainty bands, missing timings, or biological replicates are
invented. The primary plotting unit is an extracted core; technical repeats
and directions are averaged within a core before a perturbation curve is drawn.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import json
import re

import numpy as np
import pandas as pd


@dataclass
class BenchmarkTables:
    cores: pd.DataFrame
    celltypes: pd.DataFrame
    coverage: pd.DataFrame
    runs: pd.DataFrame
    audits: pd.DataFrame
    issues: list[str]


def _read_table(path: Path) -> pd.DataFrame:
    try:
        frame = pd.read_csv(path, dtype={"sample_id": str, "core_id": str, "component_id": str,
                                        "bundle_id": str, "seed_id": str, "reference_cell_id": str})
    except pd.errors.EmptyDataError:
        return pd.DataFrame()
    frame["source_file"] = str(path)
    return frame


def _concat(frames):
    nonempty = [frame for frame in frames if len(frame)]
    return pd.concat(nonempty, ignore_index=True, sort=False) if nonempty else pd.DataFrame()


def collect_evaluations(evaluation_root: str | Path, results_root: Optional[str | Path] = None) -> BenchmarkTables:
    """Read evaluator CSVs and native run summaries, including failed runs.

    ``evaluation_root`` may be the results root if each run has an evaluation
    subdirectory. Runtime layout is
    ``results/{bundle}/{condition}/{method}/repeat_01/run_summary.json``.
    Runtime files named ``summary.json`` are accepted for caller-generated
    summaries, but a neighboring ``run_summary.json`` takes precedence.
    """
    evaluation_root = Path(evaluation_root)
    results_root = Path(results_root) if results_root is not None else evaluation_root
    if not evaluation_root.exists():
        raise FileNotFoundError(evaluation_root)
    issues = []
    core_frames, type_frames, coverage_frames, audit_rows = [], [], [], []
    for path in sorted(evaluation_root.rglob("core_reference_agreement.csv")):
        frame = _read_table(path)
        core_frames.append(frame)
        directory = path.parent
        type_path = directory / "celltype_reference_agreement.csv"
        coverage_path = directory / "reference_seed_coverage.csv"
        audit_path = directory / "evaluation_audit.json"
        if type_path.exists():
            type_frames.append(_read_table(type_path))
        if coverage_path.exists():
            coverage = _read_table(coverage_path)
            for name in ("method", "condition", "replicate", "bundle_id"):
                if name in frame and frame[name].nunique(dropna=False) == 1:
                    coverage[name] = frame[name].iloc[0]
            coverage_frames.append(coverage)
        if audit_path.exists():
            audit = json.loads(audit_path.read_text())
            audit["source_file"] = str(audit_path)
            audit_rows.append({key: value for key, value in audit.items()
                               if not isinstance(value, (dict, list))})
        else:
            issues.append(f"No evaluation_audit.json beside {path}.")
    cores = _concat(core_frames)
    if len(cores):
        keys = [name for name in ("bundle_id", "method", "condition", "replicate", "sample_id", "core_id") if name in cores]
        duplicated = cores.duplicated(keys, keep=False)
        if duplicated.any():
            examples = cores.loc[duplicated, keys + ["source_file"]].head(6).to_dict("records")
            raise ValueError(f"Duplicate core/run evaluation rows; do not pool repeated copies: {examples}")
    else:
        issues.append("No completed core evaluation CSVs were found; accuracy panels will have no measurements.")
    run_rows = []
    summaries = sorted(results_root.rglob("run_summary.json")) if results_root.exists() else []
    summaries += [path for path in sorted(results_root.rglob("summary.json"))
                  if not (path.parent / "run_summary.json").exists()] if results_root.exists() else []
    for path in summaries:
        raw = json.loads(path.read_text())
        if "status" not in raw or "method" not in raw:
            continue
        row = {"source_file": str(path), "method": raw["method"], "status": raw["status"]}
        parts = path.parent.relative_to(results_root).parts
        if len(parts) == 4:
            row.update({"bundle_id": parts[0], "condition": parts[1], "layout_method": parts[2]})
            match = re.fullmatch(r"repeat_(\d+)", parts[3])
            row["replicate"] = int(match.group(1)) if match else None
        else:
            row.update({key: raw.get(key) for key in ("bundle_id", "condition", "replicate")})
            issues.append(f"Runtime identity has nonstandard directory layout: {path.parent}")
        for key in ("total_runner_seconds", "peak_process_tree_rss_bytes", "initial_process_tree_rss_bytes",
                    "peak_gpu_bytes", "n_bins", "n_nonzero_bins", "n_genes", "input_counts",
                    "n_shared_seeds", "n_output_cells", "output_counts", "missing_output_seed_count",
                    "excess_counts_total", "n_genes_with_excess_counts", "error", "timing_note",
                    "memory_scope", "gpu_memory_note", "stardist_in_primary_timing"):
            row[key] = raw.get(key)
        for stage, seconds in raw.get("stages_seconds", {}).items():
            key = "stage_" + re.sub(r"[^a-zA-Z0-9_]+", "_", stage) + "_seconds"
            row[key] = seconds
        run_rows.append(row)
    runs = pd.DataFrame(run_rows)
    if len(runs):
        duplicate_columns = [name for name in ("bundle_id", "condition", "method", "replicate") if name in runs]
        complete_ids = runs[duplicate_columns].notna().all(axis=1)
        if runs.loc[complete_ids].duplicated(duplicate_columns).any():
            raise ValueError("Multiple run summaries identify the same bundle/condition/method/replicate.")
        n_failed = int(runs["status"].eq("failed").sum())
        if n_failed:
            issues.append(f"{n_failed} method runs failed. Failed runs remain in runtime audit but are not plotted as completed performance.")
    else:
        issues.append("No method run summaries were found; timing and memory panels will have no measurements.")
    return BenchmarkTables(cores, _concat(type_frames), _concat(coverage_frames), runs,
                           pd.DataFrame(audit_rows), issues)


def core_means(cores: pd.DataFrame, *, baseline_condition: Optional[str] = None) -> pd.DataFrame:
    """Average technical repeats within core; preserve natural residual metadata."""
    if cores.empty:
        return cores.copy()
    frame = cores.copy()
    if baseline_condition is not None:
        frame = frame.loc[frame["condition"].eq(baseline_condition)]
    if frame.empty:
        return frame
    keys = [name for name in ("bundle_id", "method", "condition", "sample_id", "core_id") if name in frame]
    metadata = [name for name in ("component_id", "alignment_group", "median_residual_um", "p90_residual_um",
                                  "added_offset_um", "dx_um", "dy_um") if name in frame]
    metrics = [name for name in frame.select_dtypes(include=["number", "bool"]).columns
               if name not in keys + metadata + ["replicate"]]
    aggregations = {name: "mean" for name in metrics}
    for name in metadata:
        for key, group in frame.groupby(keys, dropna=False, observed=True):
            if group[name].nunique(dropna=True) > 1:
                raise ValueError(f"Metadata {name} differs across technical repeats for {key}.")
        aggregations[name] = "first"
    return frame.groupby(keys, dropna=False, observed=True, sort=False).agg(aggregations).reset_index()


def _no_measurements(ax, text):
    ax.text(0.5, 0.5, text, transform=ax.transAxes, ha="center", va="center", fontsize=10, color="#64748b", wrap=True)
    ax.set_xticks([])
    ax.set_yticks([])


def paired_curve_data(core_level: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Use one fixed core set with every method and offset in the curve.

    Natural-only cores at offset zero cannot enter the controlled curve unless
    the same core was also run at positive offsets. This prevents a spurious
    curve caused by changing the set of tissues between x-axis values.
    """
    if core_level.empty or "added_offset_um" not in core_level:
        return pd.DataFrame(), {"n_paired_cores": 0, "n_incomplete_cores": 0}
    data = core_level.dropna(subset=["added_offset_um", "normalized_l1_gene_count_error"]).copy()
    if data.empty or not data.added_offset_um.gt(0).any():
        return pd.DataFrame(), {"n_paired_cores": 0, "n_incomplete_cores": 0}
    units = [name for name in ("bundle_id", "sample_id", "core_id") if name in data]
    keys = units + ["method", "added_offset_um"]
    data = data.groupby(keys, observed=True, dropna=False)["normalized_l1_gene_count_error"].mean().reset_index()
    methods = sorted(data.method.unique())
    offsets = sorted(data.added_offset_um.unique())
    expected = {(method, offset) for method in methods for offset in offsets}
    selected = []
    incomplete = 0
    for _, group in data.groupby(units, observed=True, dropna=False):
        if not group.added_offset_um.gt(0).any():
            continue
        observed = set(zip(group.method, group.added_offset_um))
        if observed == expected:
            selected.append(group)
        else:
            incomplete += 1
    return _concat(selected), {"n_paired_cores": len(selected), "n_incomplete_cores": incomplete,
                               "methods": [str(value) for value in methods],
                               "offsets_um": [float(value) for value in offsets]}


def plot_benchmark_report(tables: BenchmarkTables, output_path: str | Path, *, baseline_condition: str = "baseline", title: str = "pseudo-HD assignment benchmark") -> Path:
    """Save a one-page figure showing only collected measurements.

    Curves require an explicit numeric ``added_offset_um`` in core summaries.
    Natural residuals require ``median_residual_um``; condition names are never
    parsed into an invented displacement. Single-specimen cores are descriptive spatial units. Colors are consistent across panels.
    """
    import matplotlib
    matplotlib.use("Agg", force=False)
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D

    all_cores = core_means(tables.cores)
    baseline = core_means(tables.cores, baseline_condition=baseline_condition)
    methods = sorted(set(all_cores.get("method", pd.Series(dtype=str)).dropna().astype(str)) |
                     set(tables.runs.get("method", pd.Series(dtype=str)).dropna().astype(str)))
    palette = ["#2563eb", "#d97706", "#0f766e", "#9333ea", "#dc2626", "#475569"]
    colors = {m: {"bin2cell":"#2563eb","smurf_lite":"#d97706","proseg":"#0f766e"}.get(m,palette[i % len(palette)]) for i,m in enumerate(methods)}
    fig, axes = plt.subplots(3, 2, figsize=(13.0, 13.8))
    fig.set_facecolor("white")
    for ax in axes.flat:
        ax.spines[["top", "right"]].set_visible(False)
        ax.tick_params(labelsize=9)
        ax.grid(axis="y", color="#e2e8f0", linewidth=0.6)
        ax.set_axisbelow(True)
    ax = axes[0, 0]
    ax.set_title("A   Natural alignment groups · baseline", loc="left", fontsize=12, weight="bold")
    if len(baseline) and "alignment_group" in baseline:
        groups = sorted(baseline["alignment_group"].fillna("unspecified").astype(str).unique())
        shifts = np.linspace(-0.25, 0.25, max(len(methods), 1)) if len(methods) > 1 else [0]
        for j, method in enumerate(methods):
            for i, group_name in enumerate(groups):
                values = baseline.loc[baseline.method.eq(method) & baseline.alignment_group.fillna("unspecified").astype(str).eq(group_name), "normalized_l1_gene_count_error"].dropna().to_numpy()
                if len(values):
                    # Deterministic jitter is only a visual offset, never a data transformation.
                    jitter = np.linspace(-0.04, 0.04, len(values))
                    ax.scatter(i + shifts[j] + jitter, values, color=colors[method], s=20, alpha=0.65)
                    ax.plot([i + shifts[j] - 0.055, i + shifts[j] + 0.055], [np.median(values)] * 2, color=colors[method], linewidth=3)
        ax.set_xticks(range(len(groups)), groups)
        ax.set_ylabel("Gene-count L1 / reference counts\n(lower is better)")
        ax.set_xlabel("Each dot is one core; line is the median")
    else:
        _no_measurements(ax, f"No {baseline_condition!r} core evaluations with alignment-group labels.")

    ax = axes[0, 1]
    ax.set_title("B   Paired controlled-offset response", loc="left", fontsize=12, weight="bold")
    curve, curve_audit = paired_curve_data(all_cores)
    if len(curve):
        for method in methods:
            values = curve.loc[curve.method.eq(method)].groupby("added_offset_um")["normalized_l1_gene_count_error"].mean().sort_index()
            if len(values):
                ax.plot(values.index, values.values, marker="o", color=colors[method], linewidth=1.8)
        ax.set_xlabel(f"Added displacement (µm); {curve_audit['n_paired_cores']} fixed paired cores")
        ax.set_ylabel("Mean core normalized gene-count L1")
    else:
        _no_measurements(ax, "No complete paired core set across methods and explicit added offsets.")

    ax = axes[1, 0]
    ax.set_title("C   Natural residual versus assignment error", loc="left", fontsize=12, weight="bold")
    if len(baseline) and "median_residual_um" in baseline and baseline.median_residual_um.notna().any():
        for method in methods:
            values = baseline.loc[baseline.method.eq(method)].dropna(subset=["median_residual_um", "normalized_l1_gene_count_error"])
            ax.scatter(values.median_residual_um, values.normalized_l1_gene_count_error, color=colors[method], s=25, alpha=0.7)
        ax.set_xlabel("Measured local median residual (µm)")
        ax.set_ylabel("Core normalized gene-count L1")
    else:
        _no_measurements(ax, "No independent local residual measurements were supplied.")

    ax = axes[1, 1]
    ax.set_title("D   Count totals on the fixed baseline cells", loc="left", fontsize=12, weight="bold")
    if len(baseline):
        for i, method in enumerate(methods):
            values = baseline.loc[baseline.method.eq(method)]
            denominator = values.reference_counts.replace(0, np.nan)
            ratios = (values.predicted_counts / denominator).dropna()
            if len(ratios):
                jitter = np.linspace(-0.08, 0.08, len(ratios))
                ax.scatter(i + jitter, ratios, color=colors[method], alpha=0.6, s=20)
                ax.plot([i - 0.12, i + 0.12], [ratios.mean()] * 2, color=colors[method], linewidth=3)
        ax.axhline(1, color="#475569", linestyle="--", linewidth=1)
        ax.set_xticks(range(len(methods)), methods, rotation=15)
        ax.set_ylabel("Predicted / reference counts per core")
        ax.set_xlabel("Missing output cells remain zero; line is the mean")
    else:
        _no_measurements(ax, f"No {baseline_condition!r} evaluations for matched-cell count totals.")

    completed = tables.runs.loc[tables.runs["status"].eq("completed")] if len(tables.runs) else pd.DataFrame()
    for ax, column, divisor, subtitle, ylabel in [
        (axes[2, 0], "total_runner_seconds", 60.0, "E   Total method runner time", "Minutes (load + method + standardized output)"),
        (axes[2, 1], "peak_process_tree_rss_bytes", 2**30, "F   Peak sampled process-tree memory", "Peak resident memory (GiB)"),
    ]:
        ax.set_title(subtitle, loc="left", fontsize=12, weight="bold")
        valid = completed.dropna(subset=["input_counts", column]) if len(completed) and column in completed else pd.DataFrame()
        if len(valid):
            for method in methods:
                values = valid.loc[valid.method.eq(method)]
                ax.scatter(values.input_counts / 1e6, values[column] / divisor, color=colors[method], s=26, alpha=0.7)
            ax.set_xlabel("Input molecules in the complete inference bundle (millions)")
            ax.set_ylabel(ylabel)
        else:
            _no_measurements(ax, "No completed runs with this resource measurement.")
    if methods:
        handles = [Line2D([0], [0], color=colors[method], marker="o", linestyle="", label=method) for method in methods]
        fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, 0.946), ncol=min(len(methods), 5), frameon=False)
    n_core = all_cores[[name for name in ("sample_id", "core_id") if name in all_cores]].drop_duplicates().shape[0] if len(all_cores) else 0
    n_completed = int(tables.runs.status.eq("completed").sum()) if len(tables.runs) else 0
    n_failed = int(tables.runs.status.eq("failed").sum()) if len(tables.runs) else 0
    fig.suptitle(title, fontsize=18, weight="bold", x=0.07, ha="left", y=0.99)
    fig.text(0.07, 0.961, f"{n_core} evaluated cores · {n_completed} completed method runs · {n_failed} failed runs · baseline: {baseline_condition}", fontsize=10, color="#475569")
    footer = (
        "Core summaries average technical repeats; offset curves use a fixed complete core set and average directions. Zero added offset retains baseline residual.\n"
        "Cores within one specimen are not independent biological replicates. Natural residual associations are confounded by tissue context.\n"
        "Count agreement is conditional on frozen one-to-one baseline seed matches. Shared StarDist cost is excluded from method timing.\n"
        "Runner times use the same broad boundary; native Proseg's internal inference and I/O are not separated. RAM is sampled; VRAM may be unmeasured."
    )
    fig.text(0.07, 0.018, footer, fontsize=8.5, color="#475569", va="bottom", linespacing=1.45)
    fig.subplots_adjust(left=0.08, right=0.98, top=0.905, bottom=0.13, hspace=0.48, wspace=0.31)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=170, facecolor="white")
    plt.close(fig)
    return output_path


def make_report(
    evaluation_root: str | Path,
    results_root: str | Path,
    output_dir: str | Path,
    *,
    baseline_condition: str = "baseline",
    title: str = "pseudo-HD assignment benchmark",
) -> dict:
    """Collect tables and write one figure plus complete compact CSV audits."""
    tables = collect_evaluations(evaluation_root, results_root)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    for frame, name in [(tables.cores, "all_core_metrics.csv"), (tables.celltypes, "all_celltype_metrics.csv"),
                        (tables.coverage, "all_reference_seed_coverage.csv"), (tables.runs, "all_runtime_audits.csv"),
                        (tables.audits, "all_evaluation_audits.csv")]:
        frame.to_csv(output_dir / name, index=False)
    paths = {"figure": str(plot_benchmark_report(tables, output_dir / "benchmark_summary.png",
                                                 baseline_condition=baseline_condition, title=title)),
             "tables_directory": str(output_dir)}
    _, curve_audit = paired_curve_data(core_means(tables.cores))
    report = {"paths": paths, "baseline_condition": baseline_condition,
              "n_core_evaluation_rows": len(tables.cores), "n_runtime_rows": len(tables.runs),
              "issues": tables.issues, "controlled_curve_audit": curve_audit,
              "interpretation": "Descriptive within-slide, core-level benchmark. No independent-slide confidence claim."}
    (output_dir / "report_audit.json").write_text(json.dumps(report, indent=2))
    return report
