"""Audited polygon repair on derived Xenium geometry; source rows are preserved.

No cells or transcripts are removed. Every source row retains one output row,
including all polygon parts under its existing reference_cell_id. Unresolved
rows stop strict loading after reports have been saved.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import gzip
import json
import re

import numpy as np
import pandas as pd
import shapely
from shapely.affinity import affine_transform
from shapely.geometry import MultiPolygon
from shapely.ops import unary_union
from shapely.validation import explain_validity

try:
    from shapely import make_valid
except ImportError:
    try:
        from shapely.validation import make_valid
    except ImportError as exc:
        raise ImportError(
            "This repair needs Shapely's make_valid (Shapely >=1.8 with GEOS >=3.8). "
            "The notebook does not change your environment; report the installed versions."
        ) from exc

UPDATE_VERSION = "p06212_geometry_repair_v1"
ISSUE_COLUMNS = [
    "sample_id", "shape_name", "source_row", "source_index", "reference_cell_id",
    "source_geometry_type", "source_validity_reason", "source_xy_finite",
    "transformed_validity_reason", "action", "repair_operations", "unresolved_reason",
    "output_geometry_type", "output_polygon_parts", "lower_dimensional_parts_omitted",
    "area_before_um2", "area_after_um2", "area_change_um2", "relative_area_change",
    "centroid_shift_um", "max_bounds_change_um", "area_comparison_note", "review_flags",
]


def _text(value):
    return value.decode("utf-8") if isinstance(value, bytes) else str(value)


def _numeric(value):
    try:
        result = float(value)
        return result if np.isfinite(result) else None
    except (ValueError, TypeError):
        return None


def _coords(g):
    if g is None or g.is_empty:
        return
    if g.geom_type == "Polygon":
        yield np.asarray(g.exterior.coords, dtype=float)[:, :2]
        for ring in g.interiors:
            yield np.asarray(ring.coords, dtype=float)[:, :2]
    elif hasattr(g, "geoms"):
        for part in g.geoms:
            yield from _coords(part)
    else:
        yield np.asarray(g.coords, dtype=float)[:, :2]


def _finite(g):
    return g is not None and all(np.isfinite(x).all() for x in _coords(g))


def _reason(g):
    if g is None:
        return "missing"
    if g.is_empty:
        return "empty"
    try:
        return explain_validity(g)
    except Exception as exc:
        return f"validity_check_failed: {type(exc).__name__}: {exc}"


def _usable(g):
    return (g is not None and not g.is_empty and g.geom_type in ("Polygon", "MultiPolygon")
            and _finite(g) and g.is_valid and np.isfinite(g.area) and g.area > 0)


def _polygon_parts(g):
    if g is None or g.is_empty:
        return [], 0
    if g.geom_type == "Polygon":
        return [g], 0
    if hasattr(g, "geoms"):
        parts, nonarea = [], 0
        for child in g.geoms:
            p, n = _polygon_parts(child)
            parts.extend(p)
            nonarea += n
        return parts, nonarea
    return [], 1


def _polygonal(g):
    """Preserve the union of all polygon parts, never just the largest one."""
    parts, nonarea = _polygon_parts(g)
    if not parts:
        return None, nonarea, False
    result = parts[0] if len(parts) == 1 else MultiPolygon(parts)
    united = False
    if not result.is_valid:
        # E.g. a collection of individually valid polygons with shared edges.
        # Union keeps every polygon's area and creates no buffered territory.
        result = unary_union(parts)
        united = True
    if result.geom_type not in ("Polygon", "MultiPolygon"):
        return None, nonarea, united
    return result, nonarea, united


def _batch_stats(values):
    """Bound memory by caller chunks; Shapely 2 uses vectorized checks."""
    n = len(values)
    if hasattr(shapely, "get_coordinates"):
        missing = np.asarray(shapely.is_missing(values), dtype=bool)
        empty = np.asarray(shapely.is_empty(values), dtype=bool)
        valid = np.asarray(shapely.is_valid(values), dtype=bool)
        area = np.asarray(shapely.area(values), dtype=float)
        polygon = np.isin(shapely.get_type_id(values), [3, 6])
        xy, owners = shapely.get_coordinates(values, return_index=True)
        finite = np.ones(n, dtype=bool)
        if len(xy):
            finite[np.unique(owners[~np.isfinite(xy).all(axis=1)])] = False
        finite[missing] = False
    else:
        missing = np.asarray([g is None for g in values])
        empty = np.asarray([g is not None and g.is_empty for g in values])
        valid = np.asarray([g is not None and g.is_valid for g in values])
        area = np.asarray([g.area if g is not None else np.nan for g in values])
        polygon = np.asarray([g is not None and g.geom_type in ("Polygon", "MultiPolygon") for g in values])
        finite = np.asarray([_finite(g) for g in values])
    usable = (~missing & ~empty & valid & finite & polygon & np.isfinite(area) & (area > 0))
    return dict(missing=missing, empty=empty, valid=valid, finite=finite, polygon=polygon,
                area=area, usable=usable)


def _transform_batch(values, matrix):
    if hasattr(shapely, "transform") and not np.asarray(shapely.has_z(values)).any():
        return list(shapely.transform(values, lambda xy: xy @ matrix[:2, :2].T + matrix[:2, 2]))
    coeff = [matrix[0, 0], matrix[0, 1], matrix[1, 0], matrix[1, 1], matrix[0, 2], matrix[1, 2]]
    return [None if g is None else affine_transform(g, coeff) for g in values]


def _wkb(g):
    try:
        return None if g is None else g.wkb_hex
    except Exception:
        return None


def _repair_one(source, baseline, matrix):
    operations, nonarea = [], 0
    if source is None:
        return None, operations, nonarea, "missing_geometry"
    if source.is_empty:
        return None, operations, nonarea, "empty_geometry"
    if not _finite(source):
        return None, operations, nonarea, "nonfinite_source_xy"
    try:
        work = source
        if not work.is_valid:
            work = make_valid(work)
            operations.append("make_valid_source")
        normalized, omitted, united = _polygonal(work)
        nonarea += omitted
        if source.geom_type not in ("Polygon", "MultiPolygon") or omitted:
            operations.append("extract_all_polygon_parts")
        if united:
            operations.append("union_all_polygon_parts")
        if normalized is None or not _usable(normalized):
            return None, operations, nonarea, "no_usable_polygonal_area_after_source_repair"
        output = _transform_batch([normalized], matrix)[0]
        if not _finite(output):
            return None, operations, nonarea, "nonfinite_xy_after_transform"
        if not output.is_valid:
            output = make_valid(output)
            operations.append("make_valid_transformed")
            output, omitted, united = _polygonal(output)
            nonarea += omitted
            if omitted:
                operations.append("extract_all_transformed_polygon_parts")
            if united:
                operations.append("union_all_transformed_polygon_parts")
        if not _usable(output):
            return None, operations, nonarea, "no_usable_polygonal_area_after_transform"
        if not operations:
            operations.append("polygonal_normalization")
        return output, operations, nonarea, ""
    except Exception as exc:
        return None, operations, nonarea, f"repair_failed: {type(exc).__name__}: {exc}"


class GeometryRepairError(ValueError):
    def __init__(self, result):
        self.result = result
        self.audit_directory = result.audit_directory
        bad = result.issues.loc[result.issues["action"].eq("unresolved")]
        examples = bad[["reference_cell_id", "unresolved_reason"]].head(8).to_dict("records")
        if result.summary.get("empty_element"):
            super().__init__(
                f"{result.summary['sample_id']} / {result.summary['shape_name']}: "
                f"the configured geometry element has no rows. Audit directory: "
                f"{result.audit_directory or '(not requested)'}. No reference population was inferred."
            )
            return
        super().__init__(
            f"{result.summary['sample_id']} / {result.summary['shape_name']}: "
            f"{result.summary['n_unresolved']} geometries remain unusable after audited repair. "
            f"No cells were dropped. Examples: {examples}. "
            f"Audit directory: {result.audit_directory or '(not requested)'}. "
            "Inspect the report and recover these boundaries from verified original segmentation masks "
            "or define a documented region-exclusion strategy before benchmarking."
        )


@dataclass
class GeometryRepairResult:
    geometries: list
    issues: pd.DataFrame
    summary: dict
    geometry_records: list
    audit_directory: str | None = None

    def require_valid(self):
        if self.summary["n_unresolved"] or self.summary.get("empty_element"):
            raise GeometryRepairError(self)
        return self

    def save(self, directory):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        prefix = re.sub(r"[^A-Za-z0-9_.-]", "_", self.summary["shape_name"])
        self.audit_directory = str(directory.resolve())
        self.summary["audit_directory"] = self.audit_directory
        self.issues.to_csv(directory / f"{prefix}_issues.csv", index=False)
        with gzip.open(directory / f"{prefix}_geometries.jsonl.gz", "wt", encoding="utf-8") as out:
            for record in self.geometry_records:
                out.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
        (directory / f"{prefix}_summary.json").write_text(json.dumps(self.summary, indent=2, allow_nan=False) + "\n")


def audit_and_repair_geometries(geometries, reference_ids, matrix, *, sample_id,
                                shape_name, source_indices=None, audit_dir=None,
                                strict=True, chunk_size=20000, progress=False):
    """Diagnose all source rows, repair copied polygons, and audit affected rows.

    Finite self-intersections may be repairable even if the original polygon's
    reported area is zero. None/empty/nonfinite/nonarea remnants are unresolved.
    An invalid source's area is not a reliable biological reference; area/centroid
    changes are diagnostics, never automatic acceptance thresholds.
    """
    matrix = np.asarray(matrix, dtype=float)
    if (matrix.shape != (3, 3) or not np.isfinite(matrix).all()
            or not np.allclose(matrix[2], [0, 0, 1], atol=1e-10, rtol=0)
            or abs(np.linalg.det(matrix[:2, :2])) < 1e-14):
        raise ValueError("Expected a finite, invertible 3x3 XY affine.")
    if not isinstance(chunk_size, int) or chunk_size < 1:
        raise ValueError("chunk_size must be a positive integer.")
    values = list(geometries)
    n = len(values)
    ids = list(reference_ids)
    indices = list(range(n)) if source_indices is None else list(source_indices)
    if len(ids) != n or len(indices) != n:
        raise ValueError("Geometry, ID, and source-index lengths must agree exactly.")
    if any(pd.isna(x) or not _text(x).strip() for x in ids):
        raise ValueError("Geometry IDs must be nonmissing and nonempty.")
    ids = [_text(x) for x in ids]
    try:
        geos_version = shapely.geos_version_string
    except AttributeError:
        from shapely.geos import geos_version_string
        geos_version = geos_version_string
    summary = dict(update_version=UPDATE_VERSION, sample_id=str(sample_id), shape_name=str(shape_name),
                   shapely_version=shapely.__version__, geos_version=geos_version,
                   transform_to_um=matrix.tolist(), n_rows=n, n_unchanged=0, n_repaired=0,
                   n_unresolved=0, n_source_missing=0, n_source_empty=0, n_source_nonfinite=0,
                   n_source_invalid=0, n_transformed_invalid=0, n_transform_exceptions=0,
                   n_cells_removed=0, method="make_valid default linework; retain all polygonal area",
                   area_note="Areas/centroids of invalid source polygons may be unreliable; changes are diagnostic.",
                   source_geometry_modified=False)
    outputs = [None] * n
    issues, geometry_records = [], []
    for start in range(0, n, chunk_size):
        stop = min(start + chunk_size, n)
        chunk = values[start:stop]
        src = _batch_stats(chunk)
        for key, field in (("missing", "n_source_missing"), ("empty", "n_source_empty")):
            summary[field] += int(src[key].sum())
        summary["n_source_nonfinite"] += int((~src["missing"] & ~src["finite"]).sum())
        summary["n_source_invalid"] += int((~src["missing"] & ~src["empty"] & ~src["valid"]).sum())
        transformed = [None] * len(chunk)
        candidates = np.flatnonzero(~src["missing"] & ~src["empty"] & src["finite"])
        if len(candidates):
            try:
                computed = _transform_batch([chunk[j] for j in candidates], matrix)
                for j, g in zip(candidates, computed):
                    transformed[j] = g
            except Exception:
                # Isolate a numerical/GEOS exception so every other row is audited.
                for j in candidates:
                    try:
                        transformed[j] = _transform_batch([chunk[j]], matrix)[0]
                    except Exception:
                        summary["n_transform_exceptions"] += 1
        dst = _batch_stats(transformed)
        summary["n_transformed_invalid"] += int((~dst["missing"] & ~dst["empty"] & ~dst["valid"]).sum())
        okay = src["usable"] & dst["usable"]
        for local, good in enumerate(okay):
            row = start + local
            source, baseline = chunk[local], transformed[local]
            if good:
                outputs[row] = baseline
                summary["n_unchanged"] += 1
                continue
            output, operations, nonarea, unresolved = _repair_one(source, baseline, matrix)
            outputs[row] = output
            action = "unresolved" if unresolved else "repaired"
            summary[f"n_{action}"] += 1
            area_before = _numeric(None if baseline is None else baseline.area)
            area_after = _numeric(None if output is None else output.area)
            delta = None if area_before is None or area_after is None else area_after - area_before
            relative = None if delta is None or not area_before or area_before <= 0 else delta / area_before
            centroid_shift, bounds_change = None, None
            if baseline is not None and output is not None:
                try:
                    centroid_shift = _numeric(baseline.centroid.distance(output.centroid))
                    bounds_change = _numeric(np.max(np.abs(np.asarray(baseline.bounds) - np.asarray(output.bounds))))
                except Exception:
                    pass
            output_parts = len(_polygon_parts(output)[0]) if output is not None else 0
            flags = []
            if not src["valid"][local]:
                flags.append("source_invalid_area_is_diagnostic")
            if area_before is None or area_before <= 0:
                flags.append("area_ratio_not_defined")
            if relative is not None and abs(relative) > 0.05:
                flags.append("absolute_area_change_gt_5pct_review")
            if output_parts > 1:
                flags.append("multiple_polygon_parts_retained")
            if nonarea:
                flags.append("nonarea_remnants_recorded")
            if unresolved:
                flags.append("unresolved")
            record = dict(sample_id=str(sample_id), shape_name=str(shape_name), source_row=row,
                          source_index=_text(indices[row]), reference_cell_id=ids[row],
                          source_geometry_type=None if source is None else source.geom_type,
                          source_validity_reason=_reason(source), source_xy_finite=bool(src["finite"][local]),
                          transformed_validity_reason=_reason(baseline), action=action,
                          repair_operations=";".join(operations), unresolved_reason=unresolved,
                          output_geometry_type=None if output is None else output.geom_type,
                          output_polygon_parts=output_parts, lower_dimensional_parts_omitted=nonarea,
                          area_before_um2=area_before, area_after_um2=area_after,
                          area_change_um2=delta, relative_area_change=relative,
                          centroid_shift_um=centroid_shift, max_bounds_change_um=bounds_change,
                          area_comparison_note=("invalid source area/centroid are diagnostic only" if not src["valid"][local]
                                                else "original source was topologically valid"),
                          review_flags=";".join(flags))
            issues.append(record)
            geometry_records.append(dict(record, source_wkb_hex=_wkb(source),
                                         before_um_wkb_hex=_wkb(baseline), after_um_wkb_hex=_wkb(output)))
        if progress and (stop == n or stop % (chunk_size * 5) == 0):
            print(f"  {sample_id}/{shape_name}: {stop:,}/{n:,} rows; "
                  f"{summary['n_repaired']:,} repaired, {summary['n_unresolved']:,} unresolved", flush=True)
    if n == 0:
        # An absent element cannot define a benchmark population; keep the audit.
        summary["empty_element"] = True
    frame = pd.DataFrame(issues, columns=ISSUE_COLUMNS)
    summary["n_affected_unique_cell_ids"] = int(frame["reference_cell_id"].nunique())
    result = GeometryRepairResult(outputs, frame, summary, geometry_records)
    if audit_dir is not None:
        result.save(audit_dir)
    if strict:
        result.require_valid()
    return result


def plot_geometry_audit(directory, shape_name, *, max_examples=4, dpi=180):
    """Plot a bounded number of recorded before/after geometries in µm."""
    import matplotlib.pyplot as plt
    from shapely import wkb

    directory = Path(directory)
    prefix = re.sub(r"[^A-Za-z0-9_.-]", "_", str(shape_name))
    path = directory / f"{prefix}_geometries.jsonl.gz"
    examples = []
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            examples.append(json.loads(line))
            if len(examples) >= max_examples:
                break
    if not examples:
        return None
    fig, axes = plt.subplots(len(examples), 2, figsize=(9, 3.5 * len(examples)), squeeze=False)

    def draw(ax, g, color):
        if g is None or g.is_empty:
            ax.text(0.5, 0.5, "No usable geometry", transform=ax.transAxes, ha="center")
            return
        for xy in _coords(g):
            if len(xy) and np.isfinite(xy).all():
                ax.plot(xy[:, 0], xy[:, 1], color=color, linewidth=1.25)
                ax.scatter(xy[:, 0], xy[:, 1], color=color, s=5)

    for row, item in enumerate(examples):
        before = None if not item["before_um_wkb_hex"] else wkb.loads(bytes.fromhex(item["before_um_wkb_hex"]))
        after = None if not item["after_um_wkb_hex"] else wkb.loads(bytes.fromhex(item["after_um_wkb_hex"]))
        bounds = []
        for g in (before, after):
            if g is not None and not g.is_empty and np.isfinite(g.bounds).all():
                bounds.append(g.bounds)
        for column, (g, title, color) in enumerate(((before, "Before repair", "#9C3260"), (after, "After repair", "#087F8C"))):
            ax = axes[row, column]
            draw(ax, g, color)
            ax.set_title(f"{item['reference_cell_id']} — {title}\n{item['action']}", fontsize=10)
            ax.set_aspect("equal")
            ax.set_xlabel("x (µm)"); ax.set_ylabel("y (µm)")
            if bounds:
                b = np.asarray(bounds)
                lo, hi = b[:, :2].min(axis=0), b[:, 2:].max(axis=0)
                pad = max(float((hi - lo).max()) * 0.08, 0.1)
                ax.set_xlim(lo[0] - pad, hi[0] + pad)
                ax.set_ylim(hi[1] + pad, lo[1] - pad)
    fig.suptitle(f"{shape_name}: first {len(examples)} affected rows; all polygon parts retained", fontsize=12)
    fig.tight_layout()
    fig.savefig(directory / f"{prefix}_repair_examples.png", dpi=dpi, bbox_inches="tight")
    return fig
