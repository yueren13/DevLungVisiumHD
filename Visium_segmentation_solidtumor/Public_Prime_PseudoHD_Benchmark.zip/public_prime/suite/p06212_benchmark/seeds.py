"""Shared StarDist masks, reviewed baseline identity, and paired image offsets.

The baseline seed→reference match lives in the evaluator directory. An optional
local correspondence shift is used only to propose identities for review; it
never corrects the actual benchmark H&E/seeds or the RNA observations. Frozen
identities are reused for every method and offset without rematching.
"""
from __future__ import annotations

from pathlib import Path
import json
import shutil
import time
import numpy as np
import pandas as pd
from scipy.ndimage import shift

from .common import read_json,write_json,file_sha256,object_sha256,versions


def _labels(array,shape=None):
    value=np.asarray(array)
    if value.ndim!=2 or value.dtype.kind not in "iu" or value.min(initial=0)<0 or value.max(initial=0)>np.iinfo(np.uint32).max:
        raise ValueError("A common mask must be a 2D nonnegative integer array fitting uint32; 0 means background.")
    if shape is not None and tuple(value.shape)!=tuple(shape):
        raise ValueError(f"Mask shape {value.shape} differs from image {tuple(shape)}.")
    return value.astype(np.uint32,copy=False)


def _tile_slices(placement,shape):
    x=int(placement['x0_px']);y=int(placement['y0_px']);w=int(placement['width_px']);h=int(placement['height_px'])
    if not (x>=0 and y>=0 and w>0 and h>0 and x+w<=shape[1] and y+h<=shape[0]):
        raise ValueError(f"Invalid tile placement for {placement.get('core_id')}: {placement}")
    return slice(y,y+h),slice(x,x+w)


def _present_counts(labels):
    values,counts=np.unique(labels,return_counts=True)
    keep=values>0
    return dict(zip(map(int,values[keep]),map(int,counts[keep])))


def seed_geometry(labels,metadata):
    """Public mask geometry only; no reference barcodes or annotation labels."""
    labels=_labels(labels);occupied=np.zeros(labels.shape,bool);rows=[];seen=set()
    mpp=float(metadata['image_mpp'])
    for place in metadata['placements']:
        ys,xs=_tile_slices(place,labels.shape)
        if occupied[ys,xs].any():raise ValueError('Core tiles overlap in the public mosaic.')
        occupied[ys,xs]=True;tile=labels[ys,xs]
        yy,xx=np.nonzero(tile)
        if not len(yy):continue
        ids,inverse,counts=np.unique(tile[yy,xx],return_inverse=True,return_counts=True)
        if seen.intersection(map(int,ids)):raise ValueError('A seed ID appears in more than one tile; renumber external masks explicitly before use.')
        seen.update(map(int,ids));n=len(ids)
        minx=np.full(n,tile.shape[1],int);maxx=np.zeros(n,int);miny=np.full(n,tile.shape[0],int);maxy=np.zeros(n,int)
        np.minimum.at(minx,inverse,xx);np.maximum.at(maxx,inverse,xx)
        np.minimum.at(miny,inverse,yy);np.maximum.at(maxy,inverse,yy)
        cx=np.bincount(inverse,weights=xx)/counts+xs.start+.5
        cy=np.bincount(inverse,weights=yy)/counts+ys.start+.5
        for i,label in enumerate(ids):
            rows.append({'seed_id':int(label),'core_id':str(place['core_id']),'sample_id':str(place['sample_id']),
                         'n_pixels':int(counts[i]),'centroid_x_px':float(cx[i]),'centroid_y_px':float(cy[i]),
                         'mosaic_x_um':float(cx[i]*mpp),'mosaic_y_um':float(cy[i]*mpp),
                         'min_col':int(minx[i]+xs.start),'min_row':int(miny[i]+ys.start),
                         'max_col_exclusive':int(maxx[i]+xs.start+1),'max_row_exclusive':int(maxy[i]+ys.start+1)})
    if (labels[~occupied]>0).any():raise ValueError('External/generated common mask contains nuclei in a gutter or outside declared tiles.')
    if not rows:raise ValueError('No positive common nuclei detected; inspect image scale and StarDist parameters.')
    return pd.DataFrame(rows).sort_values('seed_id').reset_index(drop=True)


def generate_shared_seeds(input_dir,stardist_config,external_mask_path=None,*,allow_unfrozen=False):
    """Run one common detector on each tile or import one reviewed common mask.

    Parameters and calibration are explicit. The original historical code used
    joint RGB percentiles; this version applies that same normalization once
    per fixed core tile. No detection is performed in white gutters.
    """
    import tifffile
    directory=Path(input_dir);metadata=read_json(directory/'metadata.json');cfg=dict(stardist_config)
    frozen=cfg.get('parameters_frozen') is True and bool(str(cfg.get('calibration_note','')).strip())
    if not frozen and not allow_unfrozen:
        raise ValueError('Calibrate StarDist on separate development regions, then set parameters_frozen=True and calibration_note before generating benchmark seeds. allow_unfrozen=True is for development only.')
    image_path=directory/metadata.get('image_filename','image.tif');image_hash=file_sha256(image_path)
    provenance={'image_sha256':image_hash,'stardist_config':cfg,'external_mask_sha256':file_sha256(external_mask_path) if external_mask_path else None,
                'normalization':'joint RGB percentiles per fixed core, clipped to [0,1]', 'parameters_frozen':frozen}
    provenance_hash=object_sha256(provenance)
    seed_path=directory/'seeds.npy';seed_meta_path=directory/'seed_metadata.json'
    if seed_path.exists() or seed_meta_path.exists():
        if seed_path.exists() and seed_meta_path.exists():
            old=read_json(seed_meta_path)
            if old.get('provenance_sha256')==provenance_hash and old.get('seeds_sha256')==file_sha256(seed_path):
                return old
        raise FileExistsError('Existing common seeds differ from this image/configuration. Preserve the run and choose a new baseline directory.')
    image=tifffile.imread(image_path)
    if image.ndim!=3 or image.shape[2]!=3:raise ValueError('StarDist H&E input must be HxWx3 RGB.')
    start=time.perf_counter();timings=[]
    if external_mask_path:
        labels=_labels(np.load(external_mask_path,allow_pickle=False),image.shape[:2]).copy()
        source='external shared mask'
    else:
        from stardist.models import StarDist2D
        from csbdeep.utils import normalize
        model=StarDist2D.from_pretrained(cfg.get('model','2D_versatile_he'))
        labels=np.zeros(image.shape[:2],np.uint32);next_id=1
        for place in metadata['placements']:
            ys,xs=_tile_slices(place,labels.shape);tile=image[ys,xs];t0=time.perf_counter()
            norm=normalize(tile,float(cfg.get('pmin',1)),float(cfg.get('pmax',99.8)),axis=(0,1,2),clip=True).astype(np.float32,copy=False)
            kwargs={'axes':'YXC','prob_thresh':float(cfg.get('prob_thresh',.02)),
                    'nms_thresh':float(cfg.get('nms_thresh',.3)),'n_tiles':tuple(cfg.get('n_tiles',(2,2,1)))}
            block=int(cfg.get('block_size',4096))
            if max(tile.shape[:2])<=block:
                local,_=model.predict_instances(norm,show_tile_progress=False,**kwargs)
                mode='predict_instances'
            else:
                local,_=model.predict_instances_big(norm,block_size=block,min_overlap=int(cfg.get('min_overlap',128)),
                       context=int(cfg.get('context',128)),show_progress=True,**kwargs)
                mode='predict_instances_big'
            local=_labels(local,tile.shape[:2]);ids,counts=np.unique(local,return_counts=True)
            min_area=int(cfg.get('minimum_area_px',0))
            keep_ids=ids[(ids>0)&(counts>=max(min_area,1))]
            if next_id+len(keep_ids)>np.iinfo(np.uint32).max:raise OverflowError('Too many common seed IDs for uint32.')
            # Searchsorted works for sparse original IDs without a huge LUT.
            out=np.zeros(local.shape,np.uint32)
            valid=np.isin(local,keep_ids)
            out[valid]=np.searchsorted(keep_ids,local[valid]).astype(np.uint32)+next_id
            labels[ys,xs]=out;next_id+=len(keep_ids)
            timings.append({'core_id':str(place['core_id']),'seconds':time.perf_counter()-t0,'n_seeds':len(keep_ids),'inference_mode':mode})
        source='StarDist per fixed core'
        del model
    geometry=seed_geometry(labels,metadata)
    temporary=directory/'seeds.partial.npy';np.save(temporary,labels,allow_pickle=False);temporary.replace(seed_path)
    geometry.to_csv(directory/'seed_geometry.csv',index=False)
    result={**provenance,'provenance_sha256':provenance_hash,'seeds_sha256':file_sha256(seed_path),
            'source':source,'n_seeds':len(geometry),'shape_yx':list(labels.shape),'elapsed_seconds':time.perf_counter()-start,
            'per_core_inference':timings,'package_versions':versions(),
            'timing_scope':'shared upstream detection/import; exclude from primary assignment timing'}
    write_json(seed_meta_path,result)
    metadata.update({'seed_filename':'seeds.npy','seed_metadata_filename':'seed_metadata.json',
                     'shared_seed_state':'frozen' if frozen else 'development','seeds_sha256':result['seeds_sha256']})
    write_json(directory/'metadata.json',metadata)
    return result


def _bool(value):
    if pd.isna(value):return False
    if value in (True,1,'True','true','1'):return True
    if value in (False,0,'False','false','0',''):return False
    raise ValueError(f'Not an explicit boolean: {value!r}')


def _candidate_overlap(shifted_seed,reference,seed_area,ref_area):
    valid=(shifted_seed>0)&(reference>0)
    if not valid.any():return pd.DataFrame(columns=['seed_id','reference_label','overlap_pixels','seed_overlap_fraction','reference_overlap_fraction'])
    pairs,count=np.unique(np.column_stack([shifted_seed[valid],reference[valid]]),axis=0,return_counts=True)
    result=pd.DataFrame({'seed_id':pairs[:,0].astype(np.int64),'reference_label':pairs[:,1].astype(np.int64),'overlap_pixels':count})
    result['seed_overlap_fraction']=result.overlap_pixels/result.seed_id.map(seed_area)
    result['reference_overlap_fraction']=result.overlap_pixels/result.reference_label.map(ref_area)
    return result


def _reference_lookup(reference_dir):
    directory=Path(reference_dir)
    ref=pd.read_csv(directory/'reference_cells.csv',dtype={'reference_cell_id':str,'sample_id':str,'core_id':str,'component_id':str})
    if ref.reference_cell_id.duplicated().any():raise ValueError('Reference metadata IDs must be unique.')
    ids=pd.read_csv(directory/'nuclei_ids.csv',dtype={'reference_cell_id':str,'sample_id':str,'core_id':str})
    if ids.raster_label.duplicated().any():raise ValueError('Reference raster labels must be unique.')
    return ref,ids


def propose_seed_map(input_dir,reference_dir,selection_df,matching_config):
    """Propose one-to-one baseline identities; write a reviewable candidate map.

    A local mean H&E−DAPI residual is subtracted only from a temporary matching
    mask. This helps preserve identity in naturally poor regions. It is not a
    dense deformation correction and remains provisional until reviewed.
    """
    source=Path(input_dir);dest=Path(reference_dir)
    if (dest/'seed_map.csv').exists():raise FileExistsError('A reviewed seed map already exists; it cannot be regenerated/rematched in place.')
    metadata=read_json(source/'metadata.json');mpp=float(metadata['image_mpp'])
    if 'perturbation' in metadata or float(metadata.get('dx_um',0))!=0 or float(metadata.get('dy_um',0))!=0:
        raise ValueError('Identity proposals are allowed only on the original baseline input, never on perturbed conditions.')
    seeds=_labels(np.load(source/'seeds.npy',allow_pickle=False))
    reference=_labels(np.load(dest/'nuclei.npy',allow_pickle=False),seeds.shape)
    geometry=seed_geometry(seeds,metadata);ref,ids=_reference_lookup(dest)
    lookup=ref.set_index('reference_cell_id',drop=False);id_lookup=ids.set_index('raster_label',drop=False)
    selected=selection_df.copy();selected['core_id']=selected.core_id.astype(str)
    if selected.core_id.duplicated().any():raise ValueError('Selected core IDs are not unique.')
    selected=selected.set_index('core_id');cfg=dict(matching_config)
    sf=float(cfg.get('minimum_seed_overlap',.25));rf=float(cfg.get('minimum_reference_overlap',.25));ratio=float(cfg.get('ambiguity_ratio',.8))
    if not (0<sf<=1 and 0<rf<=1 and 0<ratio<=1):raise ValueError('Overlap thresholds/ambiguity ratio must be in (0,1].')
    records=[];all_overlaps=[];corrections=[]
    for place in metadata['placements']:
        cid=str(place['core_id']);ys,xs=_tile_slices(place,seeds.shape)
        if cid not in selected.index:raise ValueError(f'{cid}: selected-core residual metadata missing.')
        row=selected.loc[cid]
        if not all(k in row and pd.notna(row[k]) and np.isfinite(float(row[k])) for k in ('mean_dx_um','mean_dy_um')):
            raise ValueError(f'{cid}: independent local mean_dx_um/mean_dy_um are required for identity proposal.')
        # Integer pixel shifts only for matching; the rounding error is logged.
        use_correction=bool(cfg.get('use_local_translation_for_matching',True))
        dx=int(np.rint(-float(row.mean_dx_um)/mpp)) if use_correction else 0
        dy=int(np.rint(-float(row.mean_dy_um)/mpp)) if use_correction else 0
        local=seeds[ys,xs];temporary=shift(local,shift=(dy,dx),order=0,mode='constant',cval=0,prefilter=False)
        ref_tile=reference[ys,xs]
        seed_area=_present_counts(local);ref_area=_present_counts(ref_tile)
        overlaps=_candidate_overlap(temporary,ref_tile,seed_area,ref_area)
        if len(overlaps):
            overlaps['core_id']=cid;all_overlaps.append(overlaps)
        best_by_ref={};ambig_ref=set()
        for label,g in overlaps.groupby('reference_label',sort=False):
            order=g.sort_values(['overlap_pixels','seed_id'],ascending=[False,True])
            best_by_ref[int(label)]=int(order.seed_id.iloc[0])
            if len(order)>1 and order.overlap_pixels.iloc[1]>=ratio*order.overlap_pixels.iloc[0]:ambig_ref.add(int(label))
        corrections.append({'core_id':cid,'observed_mean_dx_um':float(row.mean_dx_um),'observed_mean_dy_um':float(row.mean_dy_um),
                            'matching_shift_dx_px':dx,'matching_shift_dy_px':dy,
                            'rounding_residual_dx_um':float(row.mean_dx_um)+dx*mpp,'rounding_residual_dy_um':float(row.mean_dy_um)+dy*mpp})
        for g in geometry.loc[geometry.core_id.eq(cid)].itertuples(index=False):
            candidate={'seed_id':int(g.seed_id),'core_id':cid,'sample_id':str(place['sample_id']),
                       'component_id':str(row.get('component_id','')),'alignment_group':str(row.get('alignment_group','')),
                       'scored':False,'match_status':'unmatched','reference_cell_id':'',
                       'seed_overlap_fraction':0.0,'reference_overlap_fraction':0.0,'overlap_pixels':0,
                       'matching_shift_dx_px':dx,'matching_shift_dy_px':dy,'matching_shift_only_for_evaluation':True,
                       'median_residual_um':float(row.get('median_residual_um',np.nan)),
                       'p90_residual_um':float(row.get('p90_residual_um',np.nan))}
            possible=overlaps.loc[overlaps.seed_id.eq(g.seed_id)].sort_values(['overlap_pixels','reference_label'],ascending=[False,True])
            if len(possible):
                top=possible.iloc[0];label=int(top.reference_label)
                if label not in id_lookup.index:raise ValueError(f'Reference raster label {label} has no explicit barcode map.')
                rid=str(id_lookup.loc[label,'reference_cell_id'])
                if rid not in lookup.index:raise ValueError(f'Reference barcode {rid} is absent from hidden metadata.')
                rm=lookup.loc[rid];im=id_lookup.loc[label]
                if str(im['core_id'])!=cid:raise ValueError('Reference raster and core identity disagree.')
                candidate.update({'reference_cell_id':rid,'reference_label':label,
                                  'overlap_pixels':int(top.overlap_pixels),'seed_overlap_fraction':float(top.seed_overlap_fraction),
                                  'reference_overlap_fraction':float(top.reference_overlap_fraction)})
                for name in ('component_id','Leiden_celltype','annotation_status','annotation_component_id'):
                    if name in rm and pd.notna(rm[name]):candidate[name]=rm[name]
                n_ref=rm.get('reference_nucleus_count',im.get('n_geometry_parts',1))
                if pd.isna(n_ref):n_ref=im.get('n_geometry_parts',1)
                ambiguous=_bool(im.get('ambiguous_reference_overlap',False))
                if ambiguous:candidate['match_status']='reference_overlap_ambiguous'
                elif float(n_ref)>1:candidate['match_status']='multinucleate_reference'
                elif len(possible)>1 and possible.overlap_pixels.iloc[1]>=ratio*top.overlap_pixels:candidate['match_status']='multiple_references_ambiguous'
                elif label in ambig_ref:candidate['match_status']='multiple_seeds_ambiguous'
                elif best_by_ref.get(label)!=int(g.seed_id):candidate['match_status']='not_mutual_best'
                elif top.seed_overlap_fraction<sf or top.reference_overlap_fraction<rf:candidate['match_status']='insufficient_overlap'
                else:
                    candidate['match_status']='matched';candidate['scored']=_bool(rm.get('scored',False))
            records.append(candidate)
    candidates=pd.DataFrame(records)
    if candidates.loc[candidates.match_status.eq('matched'),'reference_cell_id'].duplicated().any():raise AssertionError('Proposed reference matches are not one-to-one.')
    candidates.to_csv(dest/'candidate_seed_map.csv',index=False)
    overlap_table=pd.concat(all_overlaps,ignore_index=True) if all_overlaps else pd.DataFrame(columns=['seed_id','reference_label','overlap_pixels','seed_overlap_fraction','reference_overlap_fraction','core_id'])
    overlap_table.to_csv(dest/'candidate_seed_overlaps.csv',index=False)
    audit={'status':'requires local visual review before freeze','input_dir':str(source.resolve()),
           'seeds_sha256':file_sha256(source/'seeds.npy'),'reference_nuclei_sha256':file_sha256(dest/'nuclei.npy'),
           'reference_cells_sha256':file_sha256(dest/'reference_cells.csv'),
           'reference_nuclei_ids_sha256':file_sha256(dest/'nuclei_ids.csv'),
           'shared_seed_state':metadata.get('shared_seed_state'),
           'candidate_map_sha256':file_sha256(dest/'candidate_seed_map.csv'),'matching_config':cfg,
           'n_seeds':len(candidates),'n_proposed_matched':int(candidates.match_status.eq('matched').sum()),
           'n_proposed_scored':int(candidates.scored.sum()),'status_counts':candidates.match_status.value_counts().to_dict(),
           'matching_corrections':corrections,
           'warning':'Local mean-residual correction is used only for identity proposal. Review sparse/poor-alignment or split/merged nuclei; do not rematch after perturbation.'}
    write_json(dest/'candidate_seed_map_audit.json',audit)
    return candidates,audit


def freeze_seed_map(reference_dir,review_note,manual_overrides=None):
    """Freeze a reviewed candidate map. No default note or implicit approval."""
    directory=Path(reference_dir)
    if not str(review_note).strip():raise ValueError('Write a substantive local mapping review note before freezing identity.')
    if (directory/'seed_map.csv').exists():raise FileExistsError('Frozen seed_map.csv already exists; never overwrite or rematch an existing benchmark run.')
    audit=read_json(directory/'candidate_seed_map_audit.json')
    if audit.get('shared_seed_state')!='frozen':
        raise ValueError('Freeze the detector parameters and regenerate the benchmark common mask before freezing an evaluation identity map.')
    candidate_path=directory/'candidate_seed_map.csv'
    if file_sha256(candidate_path)!=audit['candidate_map_sha256']:
        raise ValueError('Candidate mapping was edited outside the reviewed override route. Regenerate the candidate/audit, then use manual_overrides.')
    if file_sha256(Path(audit['input_dir'])/'seeds.npy')!=audit['seeds_sha256']:
        raise ValueError('Common seed mask changed since candidate matching.')
    if file_sha256(directory/'nuclei.npy')!=audit['reference_nuclei_sha256']:
        raise ValueError('Reference nuclei changed since candidate matching.')
    if file_sha256(directory/'reference_cells.csv')!=audit['reference_cells_sha256'] or file_sha256(directory/'nuclei_ids.csv')!=audit['reference_nuclei_ids_sha256']:
        raise ValueError('Reference identity metadata changed since candidate matching.')
    mapping=pd.read_csv(candidate_path,dtype={'seed_id':str,'reference_cell_id':str,'sample_id':str,'core_id':str,'component_id':str},keep_default_na=False)
    ref,ids=_reference_lookup(directory);lookup=ref.set_index('reference_cell_id',drop=False)
    excluded=set(ids.loc[ids.get('ambiguous_reference_overlap',pd.Series(False,index=ids.index)).map(_bool),'reference_cell_id'])
    if 'reference_nucleus_count' in ref:
        excluded.update(ref.loc[pd.to_numeric(ref.reference_nucleus_count,errors='coerce').gt(1),'reference_cell_id'])
    if 'n_geometry_parts' in ids:
        excluded.update(ids.loc[pd.to_numeric(ids.n_geometry_parts,errors='coerce').gt(1),'reference_cell_id'])
    overrides=pd.DataFrame() if manual_overrides is None else (pd.read_csv(manual_overrides,dtype={'seed_id':str,'reference_cell_id':str},keep_default_na=False) if isinstance(manual_overrides,(str,Path)) else manual_overrides.copy())
    if len(overrides):
        if not {'seed_id','reference_cell_id','review_reason'}.issubset(overrides):raise ValueError('Manual overrides require seed_id, reference_cell_id (blank rejects), review_reason.')
        overrides['seed_id']=overrides.seed_id.astype(str)
        if overrides.seed_id.duplicated().any() or not overrides.seed_id.isin(mapping.seed_id).all():raise ValueError('Override seed IDs must be unique existing common seeds.')
        for item in overrides.to_dict('records'):
            if not str(item['review_reason']).strip():raise ValueError('Every override requires its own review_reason.')
            i=mapping.index[mapping.seed_id.eq(item['seed_id'])][0]
            rid='' if pd.isna(item['reference_cell_id']) else str(item['reference_cell_id'])
            mapping.loc[i,'manual_review_reason']=str(item['review_reason'])
            if not rid:
                mapping.loc[i,['match_status','scored','reference_cell_id']]=['manually_excluded',False,''];continue
            if rid not in lookup.index or rid in excluded:raise ValueError(f'{rid}: reference identity absent or excluded for ambiguous/multinucleate geometry.')
            rm=lookup.loc[rid]
            if str(rm.core_id)!=str(mapping.loc[i,'core_id']):raise ValueError('Manual mapping cannot cross source cores.')
            mapping.loc[i,'reference_cell_id']=rid;mapping.loc[i,'match_status']='matched';mapping.loc[i,'scored']=_bool(rm.scored)
            for name in ('component_id','Leiden_celltype','annotation_status','annotation_component_id'):
                if name in rm:mapping.loc[i,name]=rm[name]
    matched=mapping.match_status.eq('matched')
    if mapping.loc[matched,'reference_cell_id'].duplicated().any():raise ValueError('Reviewed accepted matches must be one-to-one. Reject/update the other seed in the same override table.')
    if not (matched & mapping.scored.map(_bool)).any():raise ValueError('No scored reviewed matches remain; inspect the candidate map before freezing.')
    mapping['scored']=mapping.scored.map(_bool)
    mapping.to_csv(directory/'seed_map.csv',index=False)
    if len(overrides):overrides.to_csv(directory/'seed_map_manual_overrides.csv',index=False)
    review={'review_note':str(review_note),'n_manual_overrides':len(overrides),'n_matched':int(matched.sum()),
            'n_scored':int((matched&mapping.scored).sum()),'seed_map_sha256':file_sha256(directory/'seed_map.csv'),
            'baseline_seeds_sha256':audit['seeds_sha256'],'reference_nuclei_sha256':audit['reference_nuclei_sha256'],
            'candidate_map_sha256':audit['candidate_map_sha256'],'frozen':True,
            'identity_rule':'Reuse this baseline map for all methods, natural strata and added offsets; never rematch after an offset.'}
    write_json(directory/'mapping_review.json',review)
    return mapping


def make_perturbed_inputs(source_dir,destination_dir,condition):
    """Translate H&E and frozen nuclei together within each context tile.

    The current grid implementation requires integer image-pixel offsets, so
    the nominal physical displacement is also the exact label displacement.
    RGB uses linear resampling; integer labels use nearest-neighbor sampling.
    The molecule count and position files are copied byte-for-byte unchanged.
    """
    import tifffile
    source=Path(source_dir);dest=Path(destination_dir)
    if dest.exists():raise FileExistsError(dest)
    metadata=read_json(source/'metadata.json');mpp=float(metadata['image_mpp'])
    if 'perturbation' in metadata or float(metadata.get('dx_um',0))!=0 or float(metadata.get('dy_um',0))!=0:
        raise ValueError('Every robustness condition must be generated directly from the original baseline, not cumulatively from another condition.')
    if metadata.get('shared_seed_state')!='frozen':raise ValueError('Only frozen benchmark seeds can be used for robustness conditions.')
    dx=float(condition.get('dx_um',0));dy=float(condition.get('dy_um',0))
    if not np.isfinite([dx,dy]).all():raise ValueError('Condition offsets must be finite.')
    xpix=dx/mpp;ypix=dy/mpp
    if not np.allclose([xpix,ypix],np.rint([xpix,ypix]),atol=1e-8,rtol=0):raise ValueError('Choose offsets that are integer multiples of image_mpp so image and label geometry move exactly together.')
    xpix,ypix=map(int,np.rint([xpix,ypix]))
    halo=metadata.get('halo_um')
    if halo is None:raise ValueError('Baseline metadata needs halo_um to validate that clipping cannot enter the scoring region.')
    if max(abs(dx),abs(dy))>=float(halo):raise ValueError('Added offset must be strictly smaller than the context halo.')
    image=tifffile.imread(source/metadata.get('image_filename','image.tif'))
    baseline=_labels(np.load(source/'seeds.npy',allow_pickle=False),image.shape[:2])
    transformed_image=np.full_like(image,255);transformed_seeds=np.zeros_like(baseline);audit=[]
    for place in metadata['placements']:
        ys,xs=_tile_slices(place,baseline.shape)
        transformed_image[ys,xs]=shift(image[ys,xs],shift=(ypix,xpix,0),order=1,mode='constant',cval=255,prefilter=False)
        transformed_seeds[ys,xs]=shift(baseline[ys,xs],shift=(ypix,xpix),order=0,mode='constant',cval=0,prefilter=False)
        before=_present_counts(baseline[ys,xs]);after=_present_counts(transformed_seeds[ys,xs])
        for seed_id,count in before.items():
            audit.append({'seed_id':seed_id,'core_id':str(place['core_id']),'baseline_pixels':count,'condition_pixels':after.get(seed_id,0),
                          'clipped_pixels':count-after.get(seed_id,0),'seed_completely_lost':seed_id not in after})
    # Validate IDs and tile separation before creating the destination.
    geometry=seed_geometry(transformed_seeds,metadata)
    if not set(geometry.seed_id).issubset(set(np.unique(baseline))):raise AssertionError('Perturbation invented seed IDs.')
    frozen_files=[source/'bins.h5ad']+sorted((source/'binned_outputs').rglob('*'))
    frozen_files=[p for p in frozen_files if p.is_file()]
    original_hashes={str(p.relative_to(source)):file_sha256(p) for p in frozen_files}
    shutil.copytree(source,dest)
    tifffile.imwrite(dest/metadata.get('image_filename','image.tif'),transformed_image,photometric='rgb',compression='deflate')
    np.save(dest/'seeds.npy',transformed_seeds,allow_pickle=False)
    geometry.to_csv(dest/'seed_geometry.csv',index=False)
    pd.DataFrame(audit).to_csv(dest/'seed_shift_audit.csv',index=False)
    for name,digest in original_hashes.items():
        if file_sha256(dest/name)!=digest:raise AssertionError(f'RNA observation file changed during image perturbation: {name}')
    name=str(condition.get('condition_id',condition.get('name','offset')))
    result={'condition_id':name,'dx_um':dx,'dy_um':dy,'dx_px':xpix,'dy_px':ypix,
            'baseline_input':str(source.resolve()),'baseline_seeds_sha256':file_sha256(source/'seeds.npy'),
            'condition_seeds_sha256':file_sha256(dest/'seeds.npy'),'rna_hashes_unchanged':original_hashes,
            'n_baseline_seeds':len(audit),'n_lost_seeds':int(sum(x['seed_completely_lost'] for x in audit)),
            'n_seeds_with_halo_clipping':int(sum(x['clipped_pixels']>0 for x in audit)),
            'no_reference_rematching':True,'halo_um':float(halo)}
    metadata.update({'condition_id':name,'dx_um':dx,'dy_um':dy,'seeds_sha256':result['condition_seeds_sha256'],
                     'baseline_seeds_sha256':result['baseline_seeds_sha256'],'perturbation':result})
    write_json(dest/'metadata.json',metadata);write_json(dest/'perturbation.json',result)
    seedmeta=read_json(dest/'seed_metadata.json');seedmeta.update({'baseline_seeds_sha256':result['baseline_seeds_sha256'],
                       'seeds_sha256':result['condition_seeds_sha256'],'image_sha256':file_sha256(dest/'image.tif'),'condition':result})
    write_json(dest/'seed_metadata.json',seedmeta)
    return result


def review_seed_matches(input_dir,reference_dir,core_id,seed_ids=None):
    """Side-by-side raw H&E nuclei and evaluator-only corrected identity overlay."""
    import tifffile
    import matplotlib.pyplot as plt
    from skimage.segmentation import find_boundaries
    source=Path(input_dir);dest=Path(reference_dir);meta=read_json(source/'metadata.json')
    candidates=pd.read_csv(dest/'candidate_seed_map.csv',dtype={'core_id':str})
    places=[p for p in meta['placements'] if str(p['core_id'])==str(core_id)]
    if len(places)!=1:raise KeyError(core_id)
    image=tifffile.imread(source/'image.tif');seeds=np.load(source/'seeds.npy',allow_pickle=False);refs=np.load(dest/'nuclei.npy',allow_pickle=False)
    ys,xs=_tile_slices(places[0],seeds.shape);rows=candidates.loc[candidates.core_id.eq(str(core_id))]
    if rows.empty:raise ValueError('No candidate seeds for this core.')
    dx=int(rows.matching_shift_dx_px.iloc[0]);dy=int(rows.matching_shift_dy_px.iloc[0])
    local=seeds[ys,xs];ref=refs[ys,xs];rgb=image[ys,xs].copy()
    if seed_ids is not None:
        selected=set(map(int,seed_ids));local=np.where(np.isin(local,list(selected)),local,0).astype(np.uint32)
        rows=rows.loc[rows.seed_id.isin(selected)]
    moved=shift(local,shift=(dy,dx),order=0,mode='constant',cval=0,prefilter=False)
    rgb[find_boundaries(local,mode='outer')]=[0,255,255]
    overlay=np.full((*local.shape,3),245,np.uint8)
    overlay[find_boundaries(ref,mode='outer')]=[230,0,190]
    overlay[find_boundaries(moved,mode='outer')]=[0,180,220]
    fig,axes=plt.subplots(1,2,figsize=(14,7),sharex=True,sharey=True)
    axes[0].imshow(rgb);axes[0].set_title('Actual benchmark H&E + shared nuclei (cyan)')
    axes[1].imshow(overlay);axes[1].set_title(f'Identity proposal only: nuclei shifted ({dx}, {dy}) px\nCyan = seed; magenta = Xenium reference')
    for ax in axes:ax.set_xlabel('Tile image column (pixels)');ax.set_ylabel('Tile image row (pixels)')
    fig.suptitle(f'{core_id}: review correspondence, splits, merges and residual local distortion before freezing')
    fig.tight_layout()
    return fig,rows
