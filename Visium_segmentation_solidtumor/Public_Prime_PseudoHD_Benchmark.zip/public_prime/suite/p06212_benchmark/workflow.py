"""Notebook entry points for the remote, read-only public data sources."""
from __future__ import annotations
from pathlib import Path
import gc
import json
import numpy as np
import pandas as pd
from .common import read_json, write_json, output_root, alignment_matrix, versions
from .inventory import (open_sample, inspect_sample, CoordinateSpec, load_reference_ids_only,
                        load_reference_cells, panel_genes, element_to_um)
from .annotations import match_annotations
from .design import bounds_for_core, validate_selection


def inspect_inputs(config):
    """Metadata and barcode audit can run before physical units are confirmed."""
    root=output_root(config);directory=root/'inventory';directory.mkdir(exist_ok=True)
    write_json(directory/'environment.json',versions())
    all_cells=[];inventory={}
    for sample,settings in config['samples'].items():
        print(f'Inspecting sample {sample}: {settings["zarr_path"]}',flush=True)
        sdata=open_sample(settings['zarr_path'])
        info=inspect_sample(sdata,experiment_path=settings.get('experiment_path'))
        inventory[sample]=info;write_json(directory/f'{sample}_inventory.json',info)
        cells=load_reference_ids_only(sdata,settings,sample_id=sample)
        all_cells.append(cells[['sample_id','reference_cell_id','original_obs_name']])
        del sdata;gc.collect()
    references=pd.concat(all_cells,ignore_index=True)
    match=match_annotations(references,config['annotation_sources'],celltype_col=config['celltype_column'],
                            strict=False,audit_dir=root/'annotation_audit')
    write_json(directory/'input_configuration.json',config)
    return inventory,match


def _reference_kwargs(settings):
    names=('table_name','cell_shape_name','nucleus_shape_name','cell_id_column',
           'cell_shape_id_column','nucleus_shape_id_column')
    return {key:settings[key] for key in names if key in settings}


def prepare_reference_metadata(config):
    """Derive geometry in verified µm, then transfer annotations with an audit."""
    root = output_root(config)
    all_cells = []
    genes = None
    for sample, settings in config['samples'].items():
        spec = CoordinateSpec.from_dict(settings['coordinate_spec']).validate()
        sdata = open_sample(settings['zarr_path'], selection=('images', 'shapes', 'tables'))
        cells = load_reference_cells(sdata, sample, spec, **_reference_kwargs(settings), geometry_audit_dir=root / 'geometry_audit' / 'reference_metadata')
        all_cells.append(cells)
        panel = panel_genes(sdata.tables[settings['table_name']], feature_type_column=settings.get('feature_type_column'), gene_column=settings.get('gene_column'))
        prefixes = tuple(config.get('transcript_qc', {}).get('exclude_gene_prefixes', []))
        panel = [g for g in panel if not prefixes or not g.startswith(prefixes)]
        if genes is None:
            genes = panel
        elif set(panel) != set(genes):
            raise ValueError(f'Sample {sample} has a different measured panel. Declare an explicit common-gene design before pooling; absent genes are not measured zeros.')
        del sdata
        gc.collect()
    reference = pd.concat(all_cells, ignore_index=True)
    drop = [x for x in ('component_id', config['celltype_column'], 'annotation_status') if x in reference]
    reference = reference.drop(columns=drop)
    result = match_annotations(reference, config['annotation_sources'], celltype_col=config['celltype_column'], strict=False, audit_dir=root / 'annotation_audit')
    result.require_valid()
    result.reference_cells['component_id'] = result.reference_cells['sample_id'].map({str(k): str(v.get('component_id') or k) for k,v in config['samples'].items()})
    dest = root / 'reference_metadata'
    dest.mkdir(exist_ok=True)
    result.reference_cells.to_csv(dest / 'cells.csv', index=False)
    write_json(dest / 'panel_genes.json', genes)
    write_json(dest / 'coordinate_configuration.json', {s: x['coordinate_spec'] for s, x in config['samples'].items()})
    return result.reference_cells


def _dapi_source(sdata,settings):
    from .vendor.spatial_helpers import source_from_spatialdata
    spec=CoordinateSpec.from_dict(settings['coordinate_spec']).validate()
    return source_from_spatialdata(sdata,image_name=settings.get('image_name'),
          coordinate_system=spec.coordinate_system,target_to_reference_xy=spec.global_to_native_pixel_xy,
          channel=settings.get('dapi_channel',0))


def preview_cores(config,candidates,core_ids,*,save=True):
    """Return review figures; axes are original Xenium morphology µm.

    H&E is shown after the supplied slide alignment. Use corresponding points
    from these axes in local_correspondences.csv; never use raw HE coordinates
    in that file. A local inset helps resolve nuclei rather than just tissue.
    """
    from .vendor.tiff_helpers import HEReader
    from .vendor.qc_helpers import display_dapi,overlay_dapi
    from .patches import extract_image_patch
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle
    chosen=candidates.set_index('core_id').loc[list(core_ids)].reset_index()
    figures={};root=output_root(config);dest=root/'review'/'images';dest.mkdir(parents=True,exist_ok=True)
    with HEReader(config['he_path'],series_index=config.get('he_series_index',0),max_read_mib=192) as reader:
        for sample,group in chosen.groupby('sample_id'):
            settings=config['samples'][str(sample)];spec=CoordinateSpec.from_dict(settings['coordinate_spec']).validate()
            sdata=open_sample(settings['zarr_path'],selection=('images',));source=_dapi_source(sdata,settings)
            for _,core in group.iterrows():
                bounds=bounds_for_core(core,config['design']['halo_um'])
                patch=extract_image_patch(reader,source,alignment_matrix(sample, config),bounds,spec,
                                          image_mpp=config['design']['image_mpp'])
                norm,_=display_dapi(patch['dapi'],patch['dapi_valid'])
                extent=(bounds[0],bounds[2],bounds[3],bounds[1])
                fig,axes=plt.subplots(1,3,figsize=(18,6),sharex=True,sharey=True)
                axes[0].imshow(patch['he'],extent=extent);axes[0].set_title('Aligned H&E')
                axes[1].imshow(norm,cmap='gray',extent=extent);axes[1].set_title('Xenium DAPI')
                axes[2].imshow(overlay_dapi(patch['he']/255,norm,patch['dapi_valid']),extent=extent);axes[2].set_title('DAPI overlay')
                inner=bounds_for_core(core)
                for ax in axes:
                    ax.add_patch(Rectangle((inner[0],inner[1]),inner[2]-inner[0],inner[3]-inner[1],fill=False,ec='cyan',lw=1))
                    ax.set_xlabel('Original Xenium x (µm)');ax.set_ylabel('Original Xenium y (µm)')
                fig.suptitle(f'{core.core_id} | component {core.component_id} | cyan square = scoring region')
                fig.tight_layout()
                if save:fig.savefig(dest/f'{core.core_id}.png',dpi=160,bbox_inches='tight')
                figures[str(core.core_id)]=fig
            del sdata;gc.collect()
    return figures


def _load_reference_metadata(root):
    return pd.read_csv(root/'reference_metadata'/'cells.csv',dtype={'sample_id':str,'reference_cell_id':str,'component_id':str})


def prepare_development_images(config,candidates,core_ids):
    """Export separate detector-calibration images without making benchmark bins."""
    import tifffile
    from .patches import extract_image_patch
    from .vendor.tiff_helpers import HEReader
    root=output_root(config);records=[]
    chosen=candidates.set_index('core_id').loc[list(core_ids)].reset_index()
    if not chosen.development_only.astype(str).str.lower().isin(['true','1','yes']).all():
        raise ValueError('Mark detector-calibration regions development_only=True before exporting them.')
    with HEReader(config['he_path'],series_index=config.get('he_series_index',0),max_read_mib=192) as reader:
        for sample,group in chosen.groupby('sample_id'):
            settings=config['samples'][str(sample)];spec=CoordinateSpec.from_dict(settings['coordinate_spec']).validate()
            sdata=open_sample(settings['zarr_path'],selection=('images',));source=_dapi_source(sdata,settings)
            for _,core in group.iterrows():
                bounds=bounds_for_core(core,config['design']['halo_um'])
                patch=extract_image_patch(reader,source,alignment_matrix(sample, config),bounds,spec,image_mpp=config['design']['image_mpp'])
                dest=root/'development'/str(core.core_id)
                if dest.exists():raise FileExistsError(f'{dest} already exists; preserve each calibration trial.')
                dest.mkdir(parents=True)
                tifffile.imwrite(dest/'image.tif',patch['he'],photometric='rgb',compression='deflate')
                tifffile.imwrite(dest/'dapi_review_only.tif',patch['dapi'].astype(np.float32),compression='deflate')
                h,w=patch['he'].shape[:2]
                metadata={'image_mpp':config['design']['image_mpp'],'image_filename':'image.tif',
                    'image_shape':[h,w,3],'halo_um':config['design']['halo_um'],'shared_seed_state':'development',
                    'development_only':True,'placements':[{'core_id':str(core.core_id),'sample_id':str(sample),
                         'x0_px':0,'y0_px':0,'width_px':w,'height_px':h,'source_bounds_um':list(bounds)}]}
                write_json(dest/'metadata.json',metadata)
                records.append({'core_id':str(core.core_id),'input_dir':str(dest)})
            del sdata;gc.collect()
    return pd.DataFrame(records)


def extract_selected_cores(config, selection):
    """Scan each selected sample's molecule partitions once, then crop images.

    The output cache is evaluator-owned because it contains original IDs and
    hidden nuclear labels. build_bundle copies only public observations onward.
    """
    import tifffile
    from .patches import core_bounds, write_transcript_core_parts, bin_transcripts, extract_image_patch, rasterize_reference_geometry, UNKNOWN_REFERENCE
    from .vendor.tiff_helpers import HEReader
    validate_selection(selection, config['design'])
    root = output_root(config)
    cache = root / '_reference' / 'core_cache'
    cache.mkdir(parents=True, exist_ok=True)
    all_reference = _load_reference_metadata(root)
    genes = read_json(root / 'reference_metadata' / 'panel_genes.json')
    design = config['design']
    records = []
    for row in selection.to_dict('records'):
        row.update(core_bounds(row['center_x_um'], row['center_y_um'], core_size_um=design['core_side_um'], halo_um=design['halo_um'], bin_size_um=design['bin_size_um']))
        records.append(row)
    with HEReader(config['he_path'], series_index=config.get('he_series_index', 0), max_read_mib=192) as reader:
        for sample in selection.sample_id.astype(str).unique():
            settings = config['samples'][sample]
            if not settings.get('transcript_source_verified') or not settings.get('transcript_source_note', '').strip():
                raise ValueError(f'{sample}: document whether these points retain unassigned molecules and the original QV policy before simulation. Set transcript_source_verified and transcript_source_note after inspecting the source construction history.')
            spec = CoordinateSpec.from_dict(settings['coordinate_spec']).validate()
            sdata = open_sample(settings['zarr_path'])
            source = _dapi_source(sdata, settings)
            refs, cell_geometry, nucleus_geometry = load_reference_cells(sdata, sample, spec, return_geometries=True, **_reference_kwargs(settings), geometry_audit_dir=root / 'geometry_audit' / 'core_extraction')
            if nucleus_geometry is None:
                raise ValueError(f'{sample}: reference nucleus geometry is needed for an auditable baseline seed match.')
            subset = [r for r in records if str(r['sample_id']) == sample]
            if settings.get('transcripts_parquet_path'):
                points = Path(settings['transcripts_parquet_path'])  # streamed record batches; no whole-file read
                if not points.is_file(): raise FileNotFoundError(points)
                transform = settings.get('raw_transcript_to_morphology_um')
                if transform is None:
                    raise ValueError('Declare the original Parquet XY-to-morphology-µm affine; an unchanged Xenium export normally uses identity. Configure x_location/y_location columns explicitly.')
            else:
                points = sdata.points[settings['points_name']]
                transform = element_to_um(points, spec)
            parts = root / '_reference' / 'transcript_parts' / sample
            write_transcript_core_parts(points, subset, parts, transform_to_um=transform, genes=genes, columns=settings['transcript_columns'], min_qv=config['transcript_qc'].get('qv_min'), unassigned_values=config['transcript_qc'].get('unassigned_values'), reference_ids=refs.reference_cell_id)
            sample_meta = all_reference.loc[all_reference.sample_id.eq(sample)].copy()
            for core in subset:
                cid = str(core['core_id'])
                dest = cache / cid
                if dest.exists() and any(dest.iterdir()):
                    raise FileExistsError(f'{dest} already contains a core; use a new run directory.')
                dest.mkdir(parents=True, exist_ok=True)
                molecules = pd.read_parquet(parts / cid)
                binned = bin_transcripts(molecules, core['read_bounds_um'], genes=genes, bin_size_um=design['bin_size_um'], image_mpp=design['image_mpp'], core=core)
                binned.to_anndata().write_h5ad(dest / 'bins.h5ad', compression='gzip')
                binned.contributions.to_parquet(dest / 'contributions.parquet', index=False)
                image = extract_image_patch(reader, source, alignment_matrix(sample, config), core['read_bounds_um'], spec, image_mpp=design['image_mpp'])
                if not image['he_valid'].all() or not image['dapi_valid'].all():
                    raise ValueError(f'{cid}: crop reaches unavailable H&E/DAPI pixels; revise this core before running methods.')
                tifffile.imwrite(dest / 'he.tif', image['he'], photometric='rgb', compression='deflate')
                tifffile.imwrite(dest / 'dapi.tif', image['dapi'].astype(np.float32), compression='deflate')
                labels, ids, raster_meta = rasterize_reference_geometry(nucleus_geometry, core['read_bounds_um'], image_mpp=design['image_mpp'], overlap_policy='exclude')
                np.save(dest / 'reference_nuclei.npy', labels, allow_pickle=False)
                ids.to_csv(dest / 'reference_nuclei_ids.csv', index=False)
                bx0, by0, bx1, by1 = core['read_bounds_um']
                cx0, cy0, cx1, cy1 = core['core_bounds_um']
                box_intersect = sample_meta.cell_max_x_um.gt(bx0) & sample_meta.cell_min_x_um.lt(bx1) & sample_meta.cell_max_y_um.gt(by0) & sample_meta.cell_min_y_um.lt(by1)
                molecular_ids = set(molecules.reference_cell_id) - {UNKNOWN_REFERENCE}
                ref = sample_meta.loc[box_intersect | sample_meta.reference_cell_id.isin(molecular_ids) | sample_meta.reference_cell_id.isin(ids.reference_cell_id)].copy()
                ref['scored'] = ref.cell_min_x_um.ge(cx0) & ref.cell_max_x_um.lt(cx1) & ref.cell_min_y_um.ge(cy0) & ref.cell_max_y_um.lt(cy1)
                ref['reference_raster_ambiguous'] = ref.reference_cell_id.isin(raster_meta.get('conflicting_reference_ids', []))
                ref.to_csv(dest / 'reference_cells.csv', index=False)
                write_json(dest / 'metadata.json', {**binned.metadata, 'image_read': image['metadata'], 'reference_raster': raster_meta, 'core': core, 'source_coordinate_spec': spec.as_dict()})
                print(f'Extracted {cid}: {int(binned.counts.sum()):,} molecules; {int(ref.scored.sum()):,} complete scoring cells', flush=True)
            del sdata
            gc.collect()
    write_json(root / 'frozen_build_configuration.json', config)
    return cache


def build_bundles(config,selection):
    from .mosaic import build_bundle
    root=output_root(config);rows=[]
    for bundle,cores in selection.groupby('bundle_id',sort=True):
        destination=root/'inputs'/str(bundle)/'baseline'
        reference=root/'_reference'/'bundles'/str(bundle)
        meta=build_bundle(cores,root/'_reference'/'core_cache',destination,reference,config['design'])
        rows.append({'bundle_id':str(bundle),'condition_id':'baseline','input_dir':str(destination),
                     'reference_dir':str(reference),'n_cores':len(cores),'input_molecules':meta['n_input_molecules'],
                     'dx_um':0.0,'dy_um':0.0})
    result=pd.DataFrame(rows);result.to_csv(root/'bundle_manifest.csv',index=False)
    return result

# p06212_geometry_repair_v1
