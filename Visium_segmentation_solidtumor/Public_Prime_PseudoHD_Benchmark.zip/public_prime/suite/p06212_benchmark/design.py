"""Candidate cores, local registration review, and a balanced fixed design."""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree


def bounds_for_core(core, halo_um=0.0):
    half = float(core['core_side_um']) / 2 + float(halo_um)
    x, y = float(core['center_x_um']), float(core['center_y_um'])
    return (x-half, y-half, x+half, y+half)


def propose_candidates(reference_cells, design):
    """Use tissue occupancy and annotations only for sampling, never method input.

    Centres follow a fixed lattice; overlapping candidates are not independent
    observations. At the default 700 µm spacing, 500 µm cores +100 µm halos
    touch without sharing area. Unknown annotation labels remain in the tissue.
    """
    required = {'sample_id','reference_cell_id','x_um','y_um','component_id'}
    if not required.issubset(reference_cells): raise ValueError(f'Missing {required-set(reference_cells)}')
    side = float(design['core_side_um']); step = float(design['candidate_step_um'])
    bin_size = float(design['bin_size_um']); halo = float(design['halo_um'])
    if design.get('core_shape','square') != 'square':
        raise ValueError('This first implementation uses 500 µm squares; circular cores need a shared scoring mask and are not silently substituted.')
    if abs(side/bin_size-round(side/bin_size))>1e-8 or abs(step/bin_size-round(step/bin_size))>1e-8:
        raise ValueError('Core side and candidate step must be integer multiples of the 2 µm grid.')
    rows=[]
    for sample, group in reference_cells.groupby('sample_id',sort=True):
        xy=group[['x_um','y_um']].to_numpy(float)
        finite=np.isfinite(xy).all(axis=1)
        group=group.loc[finite].reset_index(drop=True); xy=xy[finite]
        tree=cKDTree(xy)
        occupied=np.unique(np.floor(xy/step).astype(int),axis=0)
        for ix,iy in occupied:
            # Preserve a common 2µm grid phase in original morphology µm.
            x0=round(ix*step/bin_size)*bin_size; y0=round(iy*step/bin_size)*bin_size
            cx=x0+side/2; cy=y0+side/2
            if x0-halo<0 or y0-halo<0: continue
            ids=tree.query_ball_point([cx,cy],side/2,p=np.inf)
            sub=group.iloc[ids]
            sub=sub.loc[sub.x_um.ge(x0)&sub.x_um.lt(x0+side)&sub.y_um.ge(y0)&sub.y_um.lt(y0+side)]
            if len(sub)<int(design['minimum_reference_cells']): continue
            annotated=sub['component_id'].dropna().astype(str)
            annotated=annotated[~annotated.isin(['','nan','None'])]
            if not len(annotated): continue
            frequencies=annotated.value_counts()
            component=str(frequencies.index[0]); fraction=float(frequencies.iloc[0]/len(annotated))
            if fraction<float(design['minimum_component_fraction']): continue
            row={'core_id':f'{sample}_x{ix:03d}_y{iy:03d}', 'sample_id':str(sample),
                 'component_id':component,'center_x_um':cx,'center_y_um':cy,
                 'core_side_um':side,'core_shape':'square','reference_cells':len(sub),
                 'annotation_fraction':len(annotated)/len(sub),'component_fraction':fraction,
                 'review_group':'','image_quality':'unreviewed','review_notes':'',
                 'selected':False,'development_only':False}
            if 'Leiden_celltype' in sub:
                counts=sub['Leiden_celltype'].dropna().astype(str).value_counts()
                row['dominant_celltype']=str(counts.index[0]) if len(counts) else ''
                row['n_annotated_celltypes']=len(counts)
            rows.append(row)
    return pd.DataFrame(rows).sort_values(['sample_id','component_id','core_id']).reset_index(drop=True) if rows else pd.DataFrame()


PAIR_COLUMNS=['core_id','landmark_id','he_x_um','he_y_um','dapi_x_um','dapi_y_um','note']


def make_review_files(candidates, directory):
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=True)
    candidate_path=directory/'candidate_cores.csv'
    if candidate_path.exists():
        raise FileExistsError(f'{candidate_path} already exists; preserve existing review annotations.')
    candidates.to_csv(candidate_path,index=False)
    pd.DataFrame(columns=PAIR_COLUMNS).to_csv(directory/'local_correspondences.csv',index=False)
    return candidate_path


def residual_summary(pairs):
    """Independent local pairs on the already affine-registered H&E/DAPI.

    These coordinates all use original Xenium morphology µm, including the
    H&E point after the existing matrix. This computes residuals; it does not
    fit away the errors being measured.
    """
    columns=['core_id','n_correspondences','median_residual_um','p90_residual_um',
             'max_residual_um','mean_dx_um','mean_dy_um','residual_spread_um']
    if len(pairs)==0:return pd.DataFrame(columns=columns)
    missing=set(PAIR_COLUMNS[:-1])-set(pairs)
    if missing:raise ValueError(f'Missing correspondence columns: {missing}')
    if pairs.duplicated(['core_id','landmark_id']).any():raise ValueError('Duplicate landmark IDs within a core.')
    xy=pairs[['he_x_um','he_y_um','dapi_x_um','dapi_y_um']].to_numpy(float)
    if not np.isfinite(xy).all():raise ValueError('Every correspondence needs finite coordinates.')
    frame=pairs.copy(); delta=xy[:,:2]-xy[:,2:]
    frame['dx_um']=delta[:,0];frame['dy_um']=delta[:,1]
    frame['distance_um']=np.linalg.norm(delta,axis=1)
    result=[]
    for cid,g in frame.groupby('core_id',sort=False):
        center=g[['dx_um','dy_um']].mean().to_numpy()
        result.append({'core_id':cid,'n_correspondences':len(g),
            'median_residual_um':g.distance_um.median(),'p90_residual_um':g.distance_um.quantile(.9),
            'max_residual_um':g.distance_um.max(),'mean_dx_um':center[0],'mean_dy_um':center[1],
            'residual_spread_um':np.sqrt(np.mean(np.sum((g[['dx_um','dy_um']].to_numpy()-center)**2,axis=1)))})
    return pd.DataFrame(result,columns=columns)


def classify_candidates(candidates,pairs,design):
    report=candidates.drop(columns=[x for x in residual_summary(pairs).columns if x!='core_id' and x in candidates]).merge(
        residual_summary(pairs),on='core_id',how='left',validate='one_to_one')
    report['alignment_group']='unclassified'
    enough=report.n_correspondences.fillna(0)>=int(design['minimum_correspondences'])
    good=design.get('good_max_residual_um');poor=design.get('poor_min_residual_um')
    if good is not None and poor is not None and float(good)>=float(poor):
        raise ValueError('Good threshold must be less than poor threshold.')
    if good is not None:report.loc[enough & report.median_residual_um.le(float(good)),'alignment_group']='good'
    if poor is not None:report.loc[enough & report.median_residual_um.ge(float(poor)),'alignment_group']='poor'
    # Manual group override is deliberate and retained in audit, never silent.
    manual=report.review_group.fillna('').isin(['good','poor']) & enough
    report.loc[manual,'alignment_group']=report.loc[manual,'review_group']
    report['group_source']=np.where(manual,'reviewed_manual','fixed_threshold')
    return report


def _as_bool(series):
    return series.astype(str).str.lower().isin(['true','1','yes'])


def choose_balanced(report,design):
    """Fixed-seed random sampling within measured strata; return shortfalls.

    Image-quality failures and development cores are excluded. A shortfall is
    preserved instead of relabelling a good region as poor to reach a quota.
    """
    eligible=report.loc[report.image_quality.eq('usable') & ~_as_bool(report.development_only)].copy()
    chosen=[];audit=[];rng=np.random.default_rng(int(design['random_seed']))
    for component,groups in design['target_counts'].items():
        for quality,target in groups.items():
            pool=eligible.loc[eligible.component_id.eq(component)&eligible.alignment_group.eq(quality)]
            n=min(int(target),len(pool))
            use=pool.iloc[rng.permutation(len(pool))[:n]].copy()
            chosen.append(use)
            audit.append({'component_id':component,'alignment_group':quality,'target':int(target),
                          'eligible':len(pool),'selected':n,'shortfall':int(target)-n})
    selected=pd.concat(chosen,ignore_index=True) if chosen else eligible.iloc[:0].copy()
    if len(selected):selected['selected']=True
    return selected,pd.DataFrame(audit)


def validate_selection(cores,design):
    if cores.empty:raise ValueError('No reviewed cores selected.')
    if cores.core_id.duplicated().any():raise ValueError('Duplicate core IDs.')
    if not cores.alignment_group.isin(['good','poor']).all():raise ValueError('Selected cores must have measured good/poor groups.')
    if not cores.image_quality.eq('usable').all():raise ValueError('Review image/tissue quality before selecting a core.')
    if (cores.n_correspondences.fillna(0)<int(design['minimum_correspondences'])).any():raise ValueError('Insufficient local landmarks in selected cores.')
    if _as_bool(cores.development_only).any():raise ValueError('Development cores cannot be scored as held-out benchmark cores.')
    side=float(design['core_side_um']);bin_size=float(design['bin_size_um']);halo=float(design['halo_um'])
    if not np.isfinite(cores[['center_x_um','center_y_um','core_side_um']].to_numpy(float)).all():raise ValueError('Nonfinite core coordinates or size.')
    if side<=0 or bin_size<=0 or halo<0 or not np.allclose(cores.core_side_um.astype(float),side):raise ValueError('Core sizes must match the declared design.')
    for sample,g in cores.groupby('sample_id'):
        xy=g[['center_x_um','center_y_um']].to_numpy(float)
        lower=xy-side/2-halo
        if not np.allclose(lower/bin_size,np.round(lower/bin_size),atol=1e-7):raise ValueError('Selected crop origins are not on the common bin grid.')
        for a in range(len(g)):
            for b in range(a):
                if np.all(np.abs(xy[a]-xy[b])<side+2*halo-1e-7):
                    raise ValueError(f'Context crops overlap within sample {sample}: {g.iloc[a].core_id}, {g.iloc[b].core_id}. Move/drop a core to avoid duplicate molecular observations.')
    return cores


def assign_bundles(cores,design):
    """Bundle both natural quality groups in each sample/component where possible."""
    result=cores.copy();result['bundle_id']='';result['tile_index']=-1
    maximum=int(design['cores_per_bundle'])
    for component,g in result.groupby('component_id',sort=True):
        queues={q:list(g.loc[g.alignment_group.eq(q)].sort_values('core_id').index) for q in ('good','poor')}
        order=[]
        while queues['good'] or queues['poor']:
            for q in ('good','poor'):
                if queues[q]:order.append(queues[q].pop(0))
        for position,index in enumerate(order):
            result.loc[index,'bundle_id']=f'{component}_B{position//maximum+1:02d}'
            result.loc[index,'tile_index']=position%maximum
    return result.sort_values(['bundle_id','tile_index']).reset_index(drop=True)


def append_correspondences(path,core_id,he_xy,dapi_xy,note='independent local review'):
    """Append paired positions in original morphology µm to a reviewed CSV."""
    he=np.asarray(he_xy,float);dapi=np.asarray(dapi_xy,float)
    if he.shape!=dapi.shape or he.ndim!=2 or he.shape[1]!=2:raise ValueError('HE and DAPI pairs require equal (N,2) arrays.')
    path=Path(path);existing=pd.read_csv(path,dtype={'core_id':str}) if path.exists() else pd.DataFrame(columns=PAIR_COLUMNS)
    start=len(existing.loc[existing.core_id.eq(str(core_id))])
    rows=[dict(zip(PAIR_COLUMNS,[str(core_id),start+i+1,*a,*b,note])) for i,(a,b) in enumerate(zip(he,dapi))]
    result=pd.concat([existing,pd.DataFrame(rows)],ignore_index=True)
    residual_summary(result)
    result.to_csv(path,index=False)
    return residual_summary(result)
