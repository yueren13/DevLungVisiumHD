"""Launch each method in a fresh interpreter from its selected Jupyter kernel.

Absolute executables and argument arrays are used; no shell command is built.
The parent notebook remains usable while subprocess logs stream to disk.
"""
from __future__ import annotations
from pathlib import Path
import json
import os
import subprocess
import signal
import sys
import time
from .common import write_json


def launch_method(method,input_dir,output_dir,config,*,python_executable=None):
    # Preserve the venv/UV interpreter path. Resolving its symlink can invoke
    # base Python instead and lose the selected environment's site-packages.
    python=Path(python_executable or sys.executable).expanduser().absolute()
    if not python.is_file():raise FileNotFoundError(python)
    output=Path(output_dir).resolve();output.parent.mkdir(parents=True,exist_ok=True)
    if output.exists() and any(output.iterdir()):raise FileExistsError(f'{output} is not empty. Use another repeat or run directory.')
    # Logs stay beside the method-owned output until its strict empty-dir check.
    log=output.with_name(output.name+'_launcher.log')
    config_path=output.with_name(output.name+'_method_config.json')
    write_json(config_path,config)
    command=[str(python),'-m','p06212_benchmark.runner','--worker',method,
             str(Path(input_dir).resolve()),str(output),str(config_path)]
    env=os.environ.copy();package_root=str(Path(__file__).resolve().parent.parent)
    env['PYTHONPATH']=package_root+(os.pathsep+env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
    threads=int(config.get('threads',16))
    if threads<1:raise ValueError('threads must be positive.')
    for variable in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
        env[variable]=str(threads)
    started=time.perf_counter()
    print(f'Starting {method}: {output}\nWorker Python: {python}\nLog: {log}',flush=True)
    with log.open('w') as handle:
        process=subprocess.Popen(command,stdout=handle,stderr=subprocess.STDOUT,env=env,
                                 start_new_session=(os.name=='posix'))
        try:
            while process.poll() is None:
                time.sleep(1)
        except KeyboardInterrupt:
            if os.name=='posix':os.killpg(process.pid,signal.SIGTERM)
            else:process.terminate()
            try:process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                if os.name=='posix':os.killpg(process.pid,signal.SIGKILL)
                else:process.kill()
                process.wait()
            raise
    elapsed=time.perf_counter()-started
    write_json(output.with_name(output.name+'_launcher.json'),{
        'method':method,'command':command,'returncode':process.returncode,
        'wall_seconds_including_interpreter':elapsed,'log_path':str(log),
        'cpu_threads_requested':threads,'python_executable':str(python)})
    if process.returncode:
        tail='\n'.join(log.read_text(errors='replace').splitlines()[-30:])
        raise RuntimeError(f'{method} failed with exit {process.returncode}. See {log}\n{tail}')
    print(f'Completed {method} in {elapsed:.1f}s (including startup).',flush=True)
    return output


def _worker(method,input_dir,output_dir,config_path):
    config=json.loads(Path(config_path).read_text())
    nthreads=int(config.get('threads',16))
    # Native Bin2cell can request all CPUs. Restrict the process affinity so the
    # advertised CPU budget applies consistently to its subprocess and libraries.
    if hasattr(os,'sched_getaffinity') and hasattr(os,'sched_setaffinity'):
        allowed=sorted(os.sched_getaffinity(0))
        os.sched_setaffinity(0,set(allowed[:min(len(allowed),nthreads)]))
    else:
        print('CPU affinity is unavailable; thread environment variables are set, but all-core calls may exceed them.',flush=True)
    from .methods import run_bin2cell,run_smurf,run_proseg
    return {'bin2cell':run_bin2cell,'smurf':run_smurf,'proseg':run_proseg}[method](input_dir,output_dir,config)


if __name__=='__main__':
    if len(sys.argv)!=6 or sys.argv[1]!='--worker':
        raise SystemExit('Internal worker: --worker METHOD INPUT_DIR OUTPUT_DIR CONFIG_JSON')
    _worker(*sys.argv[2:])
