"""Read-only inventory and explicit coordinate/identity validation.

No expression matrix is materialized here. ``global`` is a name, not a unit.
The benchmark's physical frame is original Xenium morphology pixels multiplied
by the experiment's documented pixel size. Existing H&E matrices use that same
original pixel frame, which can differ from a cropped image's local frame.
"""
from __future__ import annotations

from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any, Mapping
import json

import numpy as np
import pandas as pd


def _affine(value: Any, name: str = "affine") -> np.ndarray:
    a = np.asarray(value, dtype=float)
    if a.shape != (3, 3) or not np.isfinite(a).all():
        raise ValueError(f"{name} must be a finite 3x3 x,y affine.")
    if not np.allclose(a[2], [0, 0, 1], atol=1e-10, rtol=0):
        raise ValueError(f"{name} must have last row [0,0,1].")
    if abs(np.linalg.det(a[:2, :2])) < 1e-14:
        raise ValueError(f"{name} is singular.")
    return a


def apply_affine(xy: Any, matrix: Any) -> np.ndarray:
    xy = np.asarray(xy, dtype=float)
    if xy.ndim != 2 or xy.shape[1] != 2:
        raise ValueError("Coordinates must have shape (N,2), ordered x,y.")
    a = _affine(matrix)
    return xy @ a[:2, :2].T + a[:2, 2]


def text_ids(values: Any) -> pd.Series:
    """Decode bytes without stripping or altering valid barcode suffixes."""
    series = pd.Series(values, copy=False)
    return series.map(lambda x: x.decode("utf-8") if isinstance(x, bytes) else x).astype("string")


@dataclass(frozen=True)
class CoordinateSpec:
    morphology_pixel_size_um: float
    global_to_native_pixel_xy: Any
    coordinate_system: str = "global"
    verified: bool = False
    evidence: str = ""

    def validate(self) -> "CoordinateSpec":
        try:
            mpp = float(self.morphology_pixel_size_um)
        except (TypeError, ValueError) as exc:
            raise ValueError("Set morphology_pixel_size_um from experiment.xenium or verified metadata.") from exc
        if not np.isfinite(mpp) or mpp <= 0:
            raise ValueError("Set morphology_pixel_size_um from experiment.xenium or verified metadata.")
        _affine(self.global_to_native_pixel_xy, "global_to_native_pixel_xy")
        if self.verified is not True or not str(self.evidence).strip():
            raise ValueError("CoordinateSpec needs verified=True and a written evidence/source note before extracting physical-size cores.")
        return self

    @property
    def global_to_um(self) -> np.ndarray:
        self.validate()
        return np.diag([self.morphology_pixel_size_um, self.morphology_pixel_size_um, 1.0]) @ _affine(self.global_to_native_pixel_xy)

    def as_dict(self) -> dict:
        return {"morphology_pixel_size_um": float(self.morphology_pixel_size_um),
                "global_to_native_pixel_xy": _affine(self.global_to_native_pixel_xy).tolist(),
                "coordinate_system": self.coordinate_system, "verified": self.verified,
                "evidence": str(self.evidence)}

    @classmethod
    def from_dict(cls, data: Mapping) -> "CoordinateSpec":
        return cls(morphology_pixel_size_um=data.get("morphology_pixel_size_um"),
                   global_to_native_pixel_xy=data.get("global_to_native_pixel_xy", np.eye(3)),
                   coordinate_system=data.get("coordinate_system", "global"),
                   verified=data.get("verified", False), evidence=data.get("evidence", ""))


def element_transforms(element: Any) -> dict[str, list]:
    from spatialdata.transformations import get_transformation
    result = {}
    for key, transform in get_transformation(element, get_all=True).items():
        try:
            matrix = transform.to_affine_matrix(input_axes=("x", "y"), output_axes=("x", "y"))
        except (ValueError, TypeError, KeyError, AssertionError) as xy_error:
            # Some stored 3D point transformations insist on all XYZ axes.
            # Projection is valid only if output XY does not depend on Z.
            try:
                xyz = np.asarray(transform.to_affine_matrix(input_axes=("x", "y", "z"), output_axes=("x", "y", "z")), dtype=float)
            except Exception as xyz_error:
                raise ValueError(f"Cannot obtain an XY transform for {key!r}: {xy_error}; XYZ fallback: {xyz_error}") from xyz_error
            if xyz.shape != (4,4) or not np.isfinite(xyz).all() or not np.allclose(xyz[[0,1],2],0,atol=1e-12,rtol=0):
                raise ValueError(f"Transform {key!r} couples XY to Z or is not a finite 3D affine; a declared 2D projection is required.")
            matrix = xyz[np.ix_([0,1,3],[0,1,3])]
        result[str(key)] = _affine(matrix, f"transform {key}").tolist()
    return result


def element_to_um(element: Any, spec: CoordinateSpec) -> np.ndarray:
    matrices = element_transforms(element)
    if spec.coordinate_system not in matrices:
        raise ValueError(f"Element lacks coordinate system {spec.coordinate_system!r}; available={list(matrices)}.")
    return spec.global_to_um @ _affine(matrices[spec.coordinate_system])


def open_sample(path: str | Path, selection=("images", "points", "shapes", "tables", "labels")) -> Any:
    import spatialdata as sd
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Original SpatialData store is not accessible: {path}")
    return sd.read_zarr(path, selection=selection)


def _scalar_metadata(obj: Any, prefix: str = "", depth: int = 0) -> list[dict]:
    """Find explicit pixel-size fields in small metadata mappings, not arrays."""
    if depth > 7 or not isinstance(obj, Mapping):
        return []
    result = []
    for key, value in obj.items():
        key = str(key); path = f"{prefix}.{key}".strip(".")
        if key.lower() in {"pixel_size", "microns_per_pixel", "morphology_pixel_size_um"}:
            if np.isscalar(value) and not isinstance(value, (str, bytes, bool)):
                try:
                    if np.isfinite(float(value)) and float(value) > 0:
                        result.append({"source": path, "value": float(value), "needs_verification": True})
                except (TypeError, ValueError):
                    pass
        elif isinstance(value, Mapping):
            result.extend(_scalar_metadata(value, path, depth+1))
    return result


def inspect_sample(sdata_or_path: Any, *, experiment_path: str | Path | None = None) -> dict:
    """Inventory metadata and short point-head examples; never full point compute."""
    sdata = open_sample(sdata_or_path) if isinstance(sdata_or_path, (str, Path)) else sdata_or_path
    from .vendor.spatial_helpers import image_levels
    result = {"images": {}, "labels": {}, "points": {}, "shapes": {}, "tables": {}, "pixel_size_candidates": []}
    for category in ("images", "labels"):
        for name, element in getattr(sdata, category, {}).items():
            levels = image_levels(element)
            base = levels[0][1]
            result[category][name] = {"levels": [{"name": n, "sizes": {str(k): int(v) for k,v in a.sizes.items()}, "dtype": str(a.dtype)} for n,a in levels],
                                      "transforms_xy": element_transforms(element),
                                      "channels": [str(x) for x in base.coords["c"].values] if "c" in base.coords else []}
    for name, points in getattr(sdata, "points", {}).items():
        columns = list(map(str, points.columns))
        # Dask head reads at most one partition by default; do not use len(points).
        head = points.head(5)
        if hasattr(head, "compute"):
            head = head.compute()
        result["points"][name] = {"columns": columns,
                                     "dtypes": {str(k): str(v) for k,v in points.dtypes.items()},
                                     "npartitions": int(getattr(points, "npartitions", 1)),
                                     "transforms_xy": element_transforms(points),
                                     "head": json.loads(head.to_json(orient="records")),
                                     "warning": "A head sample cannot establish whether unassigned or low-QV molecules were previously removed."}
    for name, shapes in getattr(sdata, "shapes", {}).items():
        result["shapes"][name] = {"n_shapes": len(shapes), "columns": list(map(str,shapes.columns)),
                                    "index_examples": text_ids(shapes.index[:5]).tolist(),
                                    "transforms_xy": element_transforms(shapes)}
    for name, table in getattr(sdata, "tables", {}).items():
        result["tables"][name] = {"n_cells": int(table.n_obs), "n_genes": int(table.n_vars),
                                    "obs_columns": list(map(str,table.obs.columns)),
                                    "var_columns": list(map(str,table.var.columns)),
                                    "obs_index_examples": text_ids(table.obs_names[:5]).tolist(),
                                    "spatialdata_attrs": dict(table.uns.get("spatialdata_attrs", {})),
                                    "obsm_shapes": {str(k): list(v.shape) for k,v in table.obsm.items()}}
        result["pixel_size_candidates"].extend(_scalar_metadata(table.uns, f"tables.{name}.uns"))
    result["pixel_size_candidates"].extend(_scalar_metadata(getattr(sdata,"attrs",{}), "sdata.attrs"))
    if experiment_path:
        path = Path(experiment_path)
        with path.open() as f:
            metadata = json.load(f)
        result["experiment_metadata"] = {k: metadata[k] for k in ("pixel_size", "analysis_sw_version", "xenium_ranger", "instrument_sn", "run_name") if k in metadata}
        result["pixel_size_candidates"].extend(_scalar_metadata(metadata, str(path)))
    result["package_versions"] = {}
    for package in ("spatialdata", "spatialdata-io", "anndata", "dask", "zarr", "tifffile", "numpy", "pandas"):
        try: result["package_versions"][package] = version(package)
        except PackageNotFoundError: result["package_versions"][package] = "not installed"
    return result


def table_reference_ids(table: Any, *, cell_id_column: str | None = None) -> pd.DataFrame:
    column = cell_id_column or ("cell_id" if "cell_id" in table.obs else None)
    values = table.obs[column] if column else table.obs_names
    ids = text_ids(np.asarray(values)).reset_index(drop=True)
    if ids.isna().any() or ids.eq("").any() or ids.duplicated().any():
        raise ValueError("Original reference cell IDs must be nonempty and unique. Set cell_id_column explicitly and inspect duplicates.")
    result = table.obs.reset_index(drop=True).copy()
    result["reference_cell_id"] = ids
    result["original_obs_name"] = text_ids(np.asarray(table.obs_names)).to_numpy()
    return result


def load_reference_ids_only(sdata: Any, sample_config: Mapping | str, *, sample_id: str | None = None) -> pd.DataFrame:
    """Barcode/annotation audit before units are verified; no geometry needed.

    ``sample_config`` accepts table_name/cell_id_column and sample_id. A string
    is treated as sample_id with the standard table name. This never consults
    integrated expression values or assumes table.obsm['spatial'] units.
    """
    config = {"sample_id": sample_config} if isinstance(sample_config, str) else dict(sample_config)
    sid = sample_id if sample_id is not None else config.get("sample_id")
    if sid is None:
        raise ValueError("Provide sample_id for a globally unique annotation audit key.")
    table_name = config.get("table_name", "table")
    if table_name not in sdata.tables:
        raise KeyError(f"Table {table_name!r} is absent; available={list(sdata.tables)}")
    result = table_reference_ids(sdata.tables[table_name], cell_id_column=config.get("cell_id_column"))
    if "sample_id" in result:
        result = result.rename(columns={"sample_id": "original_sample_id"})
    result.insert(0, "sample_id", str(sid))
    return result


def panel_genes(table: Any, *, feature_type_column: str | None = None, gene_column: str | None = None) -> list[str]:
    """Fixed gene universe from the original table, never integrated .X."""
    column = feature_type_column or next((c for c in ("feature_types", "feature_type") if c in table.var), None)
    names = text_ids(np.asarray(table.var[gene_column] if gene_column else table.var_names))
    keep = np.ones(len(names), dtype=bool)
    if column:
        keep = table.var[column].astype(str).to_numpy() == "Gene Expression"
    genes = names[keep].tolist()
    if not genes or len(set(genes)) != len(genes) or any(x is pd.NA or not x for x in genes):
        raise ValueError("Panel genes must be nonempty and unique. Resolve duplicated gene names or select a stable gene column.")
    return genes


def reference_geometry(sdata: Any, spec: CoordinateSpec, *, shape_name: str, reference_ids: Any, shape_id_column: str | None=None, audit_dir=None, sample_id=None) -> Any:
    """Return audited, repaired evaluator polygons with unchanged original IDs.

    Repairs operate on derived geometry only. Missing or unusable polygons
    stop loading after their audit has been saved; source cells are not dropped.
    Nuclei may repeat a cell ID, and all polygonal parts remain with that ID.
    """
    from .geometry_repair import audit_and_repair_geometries
    if shape_name not in sdata.shapes:
        raise KeyError(f'Shape element {shape_name!r} is absent; available={list(sdata.shapes)}')
    shapes = sdata.shapes[shape_name]
    column = shape_id_column or ('cell_id' if 'cell_id' in shapes else None)
    ids = text_ids(np.asarray(shapes[column] if column else shapes.index)).reset_index(drop=True)
    allowed = set(text_ids(reference_ids).dropna().tolist())
    unresolved = ids[~ids.isin(allowed)]
    if len(unresolved):
        raise ValueError(f'{shape_name}: {len(unresolved)} geometry IDs do not exactly match original table IDs; examples={unresolved.head(8).tolist()}. Supply shape_id_column or an explicit documented mapping; row-order matching is prohibited.')
    repair_result = audit_and_repair_geometries(shapes.geometry.to_numpy(), ids.tolist(), element_to_um(shapes, spec), sample_id=str(sample_id or 'unknown'), shape_name=shape_name, source_indices=list(shapes.index), audit_dir=audit_dir, strict=True, progress=True)
    if len(repair_result.geometries) != len(shapes):
        raise RuntimeError('Geometry repair changed the number of source rows.')
    geometry_column = shapes.geometry.name
    result = shapes[[geometry_column]].copy().reset_index(drop=True)
    if geometry_column != 'geometry':
        result = result.rename_geometry('geometry')
    result['reference_cell_id'] = ids.to_numpy()
    result = result.set_geometry(repair_result.geometries)
    result.attrs = {'frame': 'original Xenium morphology µm', 'coordinate_spec': spec.as_dict(), 'source_element': shape_name, 'geometry_audit_summary': repair_result.summary}
    return result


def load_reference_cells(sdata: Any, sample_id: str, spec: CoordinateSpec, *, table_name='table', cell_shape_name='cell_boundaries', nucleus_shape_name='nucleus_boundaries', cell_id_column=None, cell_shape_id_column=None, nucleus_shape_id_column=None, return_geometries=False, geometry_audit_dir=None):
    table = sdata.tables[table_name]
    cells = table_reference_ids(table, cell_id_column=cell_id_column)
    if 'sample_id' in cells:
        cells = cells.rename(columns={'sample_id': 'original_sample_id'})
    cells.insert(0, 'sample_id', str(sample_id))
    cell_geometry = reference_geometry(sdata, spec, shape_name=cell_shape_name, reference_ids=cells.reference_cell_id, shape_id_column=cell_shape_id_column, audit_dir=Path(geometry_audit_dir) / str(sample_id) if geometry_audit_dir is not None else None, sample_id=sample_id)
    if cell_geometry.reference_cell_id.duplicated().any():
        raise ValueError('Cell geometry has multiple rows per cell. Supply a reviewed union of parts; do not silently drop rows.')
    centroids = cell_geometry.geometry.centroid
    spatial = pd.DataFrame({'reference_cell_id': cell_geometry.reference_cell_id, 'x_um': centroids.x, 'y_um': centroids.y})
    for col, values in zip(('cell_min_x_um', 'cell_min_y_um', 'cell_max_x_um', 'cell_max_y_um'), cell_geometry.geometry.bounds.to_numpy().T):
        spatial[col] = values
    cells = cells.merge(spatial, on='reference_cell_id', how='left', validate='one_to_one')
    if cells[['x_um', 'y_um']].isna().any(axis=None):
        raise ValueError('Some original cells have no usable geometry. Audit before selecting cores; no implicit dropping is done.')
    nucleus_geometry = None
    if nucleus_shape_name and nucleus_shape_name in sdata.shapes:
        nucleus_geometry = reference_geometry(sdata, spec, shape_name=nucleus_shape_name, reference_ids=cells.reference_cell_id, shape_id_column=nucleus_shape_id_column, audit_dir=Path(geometry_audit_dir) / str(sample_id) if geometry_audit_dir is not None else None, sample_id=sample_id)
        weights = nucleus_geometry.geometry.area.to_numpy(dtype=float)
        centers = nucleus_geometry.geometry.centroid
        pieces = pd.DataFrame({"reference_cell_id":nucleus_geometry.reference_cell_id.to_numpy(),
             "weight":weights,"wx":weights*centers.x.to_numpy(),"wy":weights*centers.y.to_numpy()})
        grouped = pieces.groupby("reference_cell_id",sort=False)
        agg = grouped[["weight","wx","wy"]].sum()
        if (agg.weight<=0).any(): raise ValueError("Reference nuclear geometry has zero total area")
        agg["nucleus_x_um"]=agg.wx/agg.weight
        agg["nucleus_y_um"]=agg.wy/agg.weight
        agg["reference_nucleus_count"]=grouped.size()
        cells=cells.merge(agg[["nucleus_x_um","nucleus_y_um","reference_nucleus_count"]].reset_index(),
                          on="reference_cell_id",how="left",validate="one_to_one")
        if "nucleus_count" in cells:
            observed=pd.to_numeric(cells["nucleus_count"],errors="raise")
            cells["reference_nucleus_geometry_rows"]=cells["reference_nucleus_count"]
            cells["reference_nucleus_count"]=pd.concat([observed,cells["reference_nucleus_count"]],axis=1).max(axis=1)
    else:
        cells['nucleus_x_um'] = np.nan
        cells['nucleus_y_um'] = np.nan
        cells['reference_nucleus_count'] = pd.NA
    if return_geometries:
        return (cells, cell_geometry, nucleus_geometry)
    return cells

# p06212_geometry_repair_v1
