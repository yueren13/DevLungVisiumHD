"""Reference-agreement scoring for a fixed, shared-nucleus assignment benchmark.

All reference counts and annotations are evaluator-only. Neither cell rematching
after perturbation nor method-specific QC is performed here. Missing output
cells are zeros in the frozen baseline evaluation population.

Gene-count overlap measures agreement of cell-by-gene totals. It cannot identify
which same-gene molecules were allocated correctly inside a mixed 2 um bin.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping, Optional
import json

import numpy as np
import pandas as pd
from scipy import sparse


def _ids(values: Iterable, label: str) -> list[str]:
    result = []
    for value in values:
        if pd.isna(value):
            raise ValueError(f"{label} contains missing identifiers.")
        text = value.decode() if isinstance(value, bytes) else str(value)
        if not text:
            raise ValueError(f"{label} contains an empty identifier.")
        result.append(text)
    if len(set(result)) != len(result):
        raise ValueError(f"{label} must be unique.")
    return result


def _bool_column(values: pd.Series, name: str) -> np.ndarray:
    if values.isna().any():
        raise ValueError(f"{name} contains missing flags.")
    if pd.api.types.is_bool_dtype(values):
        return values.to_numpy(dtype=bool)
    parsed = values.map({True: True, False: False, "True": True, "False": False,
                         "true": True, "false": False, 1: True, 0: False})
    if parsed.isna().any():
        raise ValueError(f"{name} must contain explicit boolean flags.")
    return parsed.to_numpy(dtype=bool)


def _counts(matrix, rows: int, columns: int, name: str, integer: bool = True):
    result = sparse.csr_matrix(matrix, dtype=np.float64)
    result.sum_duplicates()
    result.eliminate_zeros()
    if result.shape != (rows, columns):
        raise ValueError(f"{name}.shape={result.shape}; expected {(rows, columns)}")
    if not np.isfinite(result.data).all() or (result.data < 0).any():
        raise ValueError(f"{name} must contain finite nonnegative counts.")
    if integer and result.data.size and not np.allclose(result.data, np.rint(result.data), atol=1e-6, rtol=0):
        raise ValueError(f"{name} contains non-integer values; use untouched counts, not normalized/integrated X.")
    return result


def _reindex_rows(matrix, source_ids: list[str], target_ids: list[str]):
    index = {value: i for i, value in enumerate(source_ids)}
    target_rows = []
    source_rows = []
    for row, value in enumerate(target_ids):
        if value in index:
            target_rows.append(row)
            source_rows.append(index[value])
    selector = sparse.csr_matrix(
        (np.ones(len(target_rows)), (target_rows, source_rows)),
        shape=(len(target_ids), len(source_ids)),
    )
    return selector @ matrix


def _reindex_genes(matrix, source_genes: list[str], target_genes: list[str]):
    lookup = {value: i for i, value in enumerate(target_genes)}
    source_columns, target_columns = [], []
    for column, value in enumerate(source_genes):
        if value in lookup:
            source_columns.append(column)
            target_columns.append(lookup[value])
    selector = sparse.csr_matrix(
        (np.ones(len(source_columns)), (source_columns, target_columns)),
        shape=(len(source_genes), len(target_genes)),
    )
    return matrix @ selector


def _row_sum(matrix) -> np.ndarray:
    return np.asarray(matrix.sum(axis=1)).reshape(-1)


def _safe_divide(numerator, denominator, zero=np.nan):
    numerator, denominator = np.broadcast_arrays(
        np.asarray(numerator, dtype=float), np.asarray(denominator, dtype=float)
    )
    output = np.full(numerator.shape, zero, dtype=float)
    np.divide(numerator, denominator, out=output, where=denominator != 0)
    return output


@dataclass
class EvaluationResult:
    cell_metrics: pd.DataFrame
    core_metrics: pd.DataFrame
    celltype_metrics: pd.DataFrame
    reference_coverage: pd.DataFrame
    audit: dict

    def save(self, directory: str | Path):
        path = Path(directory)
        path.mkdir(parents=True, exist_ok=True)
        self.cell_metrics.to_csv(path / "cell_reference_agreement.csv", index=False)
        self.core_metrics.to_csv(path / "core_reference_agreement.csv", index=False)
        self.celltype_metrics.to_csv(path / "celltype_reference_agreement.csv", index=False)
        self.reference_coverage.to_csv(path / "reference_seed_coverage.csv", index=False)
        (path / "evaluation_audit.json").write_text(json.dumps(self.audit, indent=2, allow_nan=False))


def summarize_cell_metrics(cells: pd.DataFrame, group_columns: Iterable[str]) -> pd.DataFrame:
    """Summaries preserve cells lost by a method; groups can include cell type."""
    group_columns = [name for name in group_columns if name in cells]
    rows = []
    if cells.empty:
        return pd.DataFrame(columns=group_columns + ["n_scored_cells"])
    grouper = group_columns[0] if len(group_columns) == 1 else group_columns
    groups = cells.groupby(grouper, dropna=False, observed=True, sort=False) if group_columns else [((), cells)]
    for key, group in groups:
        keys = key if isinstance(key, tuple) else (key,)
        row = dict(zip(group_columns, keys))
        true_total = float(group["reference_counts"].sum())
        pred_total = float(group["predicted_counts"].sum())
        overlap = float(group["gene_count_overlap"].sum())
        l1 = float(group["l1_gene_count_error"].sum())
        row.update({
            "n_scored_cells": len(group),
            "n_output_cells_present": int(group["output_cell_present"].sum()),
            "n_output_cells_nonzero": int(group["output_cell_nonzero"].sum()),
            "output_seed_retention_fraction": float(group["output_cell_present"].mean()),
            "nonzero_output_fraction": float(group["output_cell_nonzero"].mean()),
            "n_zero_reference_cells": int(group["reference_counts"].eq(0).sum()),
            "reference_counts": true_total,
            "predicted_counts": pred_total,
            "count_bias_fraction": (pred_total - true_total) / true_total if true_total else np.nan,
            "normalized_l1_gene_count_error": l1 / true_total if true_total else np.nan,
            "gene_count_recovery": overlap / true_total if true_total else np.nan,
            "gene_count_precision": overlap / pred_total if pred_total else (0.0 if true_total else np.nan),
            "gene_count_dice": 2 * overlap / (true_total + pred_total) if true_total + pred_total else np.nan,
            "mean_per_cell_normalized_l1": float(group["normalized_l1_gene_count_error"].mean()),
            "median_per_cell_normalized_l1": float(group["normalized_l1_gene_count_error"].median()),
            "mean_profile_cosine": float(group["profile_cosine"].mean()),
            "median_profile_cosine": float(group["profile_cosine"].median()),
            "mean_absolute_count_error": float(group["absolute_count_error"].mean()),
        })
        rows.append(row)
    return pd.DataFrame(rows)


def reference_seed_coverage(
    reference_metadata: pd.DataFrame,
    reference_ids: Iterable,
    reference_totals: Iterable,
    seed_map: pd.DataFrame,
    *,
    accepted_match_statuses: Iterable[str] = ("matched",),
) -> pd.DataFrame:
    """Report reference cells without a baseline seed separately from refinement."""
    needed = {"reference_cell_id", "sample_id", "core_id", "scored"}
    if not needed.issubset(reference_metadata):
        raise ValueError(f"reference_metadata for coverage requires {sorted(needed)}")
    frame = reference_metadata.copy()
    frame["reference_cell_id"] = _ids(frame["reference_cell_id"], "reference_metadata reference_cell_id")
    ref_ids = list(reference_ids)
    totals = pd.Series(np.asarray(reference_totals, dtype=float), index=ref_ids)
    if set(frame["reference_cell_id"]) != set(totals.index):
        raise ValueError("reference_metadata must cover exactly the complete reference count matrix, including cells without seeds.")
    frame["reference_counts"] = frame["reference_cell_id"].map(totals)
    frame = frame.loc[_bool_column(frame["scored"], "reference_metadata.scored")].copy()
    valid = seed_map["match_status"].isin(accepted_match_statuses)
    matched = set(seed_map.loc[valid, "reference_cell_id"].dropna().astype(str))
    frame["has_baseline_seed"] = frame["reference_cell_id"].isin(matched)
    rows = []
    for (sample, core), group in frame.groupby(["sample_id", "core_id"], dropna=False, observed=True, sort=False):
        seeded = group["has_baseline_seed"]
        total = float(group["reference_counts"].sum())
        missed = float(group.loc[~seeded, "reference_counts"].sum())
        rows.append({
            "sample_id": sample, "core_id": core,
            "n_scored_reference_cells": len(group),
            "n_reference_cells_with_baseline_seed": int(seeded.sum()),
            "n_reference_cells_without_baseline_seed": int((~seeded).sum()),
            "baseline_reference_cell_coverage": float(seeded.mean()),
            "reference_counts": total,
            "counts_in_reference_cells_without_seed": missed,
            "fraction_reference_counts_without_seed": missed / total if total else np.nan,
        })
    return pd.DataFrame(rows)


def evaluate_assignment(
    predicted_counts,
    predicted_seed_ids: Iterable,
    predicted_genes: Iterable,
    reference_counts,
    reference_cell_ids: Iterable,
    reference_genes: Iterable,
    seed_map: pd.DataFrame,
    *,
    method: str,
    condition: str,
    replicate: int = 0,
    reference_metadata: Optional[pd.DataFrame] = None,
    accepted_match_statuses: Iterable[str] = ("matched",),
    predicted_count_kind: str = "observed_integer",
) -> EvaluationResult:
    """Compare fixed matched cells using a fixed complete reference gene universe.

    ``seed_map`` requires seed_id, reference_cell_id, sample_id, core_id, scored,
    match_status; it may include component_id, alignment_group, and
    Leiden_celltype. The composite reference IDs must be globally unique within
    this bundle. Seed IDs must be stable across conditions and methods.

    All scored baseline matches are retained even if the method loses the seed
    or all of its genes. Unmatched/ambiguous baseline seeds are excluded from
    conditional assignment metrics and enumerated in the audit. This function
    does not filter by annotation availability or by output quality.
    """
    pred_ids = _ids(predicted_seed_ids, "predicted seed IDs")
    pred_genes = _ids(predicted_genes, "predicted genes")
    ref_ids = _ids(reference_cell_ids, "reference cell IDs")
    ref_genes = _ids(reference_genes, "reference genes")
    if predicted_count_kind not in {"observed_integer", "expected_counts"}:
        raise ValueError("predicted_count_kind must be 'observed_integer' or 'expected_counts'.")
    pred = _counts(predicted_counts, len(pred_ids), len(pred_genes), "predicted_counts",
                   integer=predicted_count_kind == "observed_integer")
    truth = _counts(reference_counts, len(ref_ids), len(ref_genes), "reference_counts", integer=True)
    required = {"seed_id", "reference_cell_id", "sample_id", "core_id", "scored", "match_status"}
    if not required.issubset(seed_map):
        raise ValueError(f"seed_map requires {sorted(required)}")
    master = seed_map.copy()
    # ROI-selection tables use residual_median_um / residual_p90_um; expose one
    # canonical spelling in reports while accepting those source column names.
    for source, canonical in {"residual_median_um": "median_residual_um",
                              "residual_p90_um": "p90_residual_um"}.items():
        if source in master and canonical not in master:
            master[canonical] = master[source]
        elif source in master and canonical in master:
            left = pd.to_numeric(master[source], errors="raise").to_numpy(float)
            right = pd.to_numeric(master[canonical], errors="raise").to_numpy(float)
            if not np.allclose(left, right, equal_nan=True):
                raise ValueError(f"Conflicting residual columns: {source} and {canonical}.")
    master["seed_id"] = _ids(master["seed_id"], "seed_map seed_id")
    for name in ("sample_id", "core_id", "component_id", "bundle_id"):
        if name in master:
            if name in ("sample_id", "core_id") and master[name].isna().any():
                raise ValueError(f"seed_map.{name} contains missing identifiers.")
            master[name] = master[name].map(lambda value: str(value) if pd.notna(value) else None)
    master["scored"] = _bool_column(master["scored"], "seed_map.scored")
    valid_status = master["match_status"].isin(accepted_match_statuses)
    if master.loc[valid_status, "reference_cell_id"].isna().any():
        raise ValueError("A matched seed has no reference_cell_id.")
    master.loc[valid_status, "reference_cell_id"] = master.loc[valid_status, "reference_cell_id"].astype(str)
    if master.loc[valid_status, "reference_cell_id"].duplicated().any():
        raise ValueError("Baseline seed-to-reference matches must be one-to-one; resolve duplicate references.")
    matched_missing_reference = set(master.loc[valid_status, "reference_cell_id"]) - set(ref_ids)
    if matched_missing_reference:
        raise ValueError(f"Baseline matches absent from hidden reference matrix: {sorted(matched_missing_reference)[:8]}")
    evaluated = master.loc[valid_status & master["scored"]].copy().reset_index(drop=True)
    if evaluated.empty:
        raise ValueError("No scored baseline one-to-one seed/reference matches; inspect the frozen seed map.")
    scored_seed_ids = evaluated["seed_id"].tolist()
    scored_reference_ids = evaluated["reference_cell_id"].tolist()
    aligned_predictions = _reindex_rows(
        _reindex_genes(pred, pred_genes, ref_genes), pred_ids, scored_seed_ids
    ).tocsr()
    aligned_truth = _reindex_rows(truth, ref_ids, scored_reference_ids).tocsr()
    reference_totals = _row_sum(aligned_truth)
    predicted_totals = _row_sum(aligned_predictions)
    difference = aligned_predictions - aligned_truth
    difference.data = np.abs(difference.data)
    l1 = _row_sum(difference)
    overlap = (reference_totals + predicted_totals - l1) / 2
    overlap = np.maximum(overlap, 0)
    dot = _row_sum(aligned_predictions.multiply(aligned_truth))
    norms = np.sqrt(_row_sum(aligned_predictions.multiply(aligned_predictions)) *
                    _row_sum(aligned_truth.multiply(aligned_truth)))
    cosine = _safe_divide(dot, norms)
    cosine[(reference_totals > 0) & (predicted_totals == 0)] = 0.0
    evaluated["method"] = str(method)
    evaluated["condition"] = str(condition)
    evaluated["replicate"] = int(replicate)
    evaluated["output_cell_present"] = evaluated["seed_id"].isin(set(pred_ids))
    evaluated["output_cell_nonzero"] = predicted_totals > 0
    evaluated["reference_counts"] = reference_totals
    evaluated["predicted_counts"] = predicted_totals
    evaluated["signed_count_error"] = predicted_totals - reference_totals
    evaluated["absolute_count_error"] = np.abs(predicted_totals - reference_totals)
    evaluated["count_bias_fraction"] = _safe_divide(predicted_totals - reference_totals, reference_totals)
    evaluated["l1_gene_count_error"] = l1
    evaluated["normalized_l1_gene_count_error"] = _safe_divide(l1, reference_totals)
    evaluated["gene_count_overlap"] = overlap
    evaluated["gene_count_recovery"] = _safe_divide(overlap, reference_totals)
    precision = _safe_divide(overlap, predicted_totals)
    precision[(predicted_totals == 0) & (reference_totals > 0)] = 0
    evaluated["gene_count_precision"] = precision
    evaluated["gene_count_dice"] = _safe_divide(2 * overlap, reference_totals + predicted_totals)
    evaluated["profile_cosine"] = cosine
    group_columns = ["method", "condition", "replicate", "sample_id", "core_id"]
    group_columns += [name for name in ("component_id", "alignment_group") if name in evaluated]
    core_metrics = summarize_cell_metrics(evaluated, group_columns)
    celltype_metrics = summarize_cell_metrics(evaluated, group_columns + ["Leiden_celltype"]) if "Leiden_celltype" in evaluated else pd.DataFrame()
    # These describe an extracted core/condition, not a per-cell phenotype.
    # Preserve them in compact summaries without silently averaging inconsistent
    # metadata (which could hide a joined manifest or coordinate error).
    for name in ("median_residual_um", "p90_residual_um", "added_offset_um",
                 "dx_um", "dy_um", "bundle_id"):
        if name not in evaluated:
            continue
        annotations = []
        for (sample, core), frame in evaluated.groupby(["sample_id", "core_id"], dropna=False, observed=True, sort=False):
            values = frame[name].dropna().unique()
            if len(values) > 1:
                raise ValueError(f"Core metadata '{name}' varies within sample={sample}, core={core}; fix the manifest join.")
            annotations.append({"sample_id": sample, "core_id": core,
                                name: values[0] if len(values) else np.nan})
        metadata = pd.DataFrame(annotations)
        core_metrics = core_metrics.merge(metadata, on=["sample_id", "core_id"], how="left", validate="many_to_one")
        if len(celltype_metrics):
            celltype_metrics = celltype_metrics.merge(metadata, on=["sample_id", "core_id"], how="left", validate="many_to_one")
    missing_genes = sorted(set(ref_genes) - set(pred_genes))
    extra_genes = sorted(set(pred_genes) - set(ref_genes))
    extra_gene_set = set(extra_genes)
    master_seed_set = set(master["seed_id"])
    extra_columns = [i for i, gene in enumerate(pred_genes) if gene in extra_gene_set]
    unknown_seed_rows = [i for i, seed in enumerate(pred_ids) if seed not in master_seed_set]
    audit = {
        "method": str(method), "condition": str(condition), "replicate": int(replicate),
        "predicted_count_kind": predicted_count_kind,
        "n_master_seeds": len(master),
        "n_scored_baseline_matched_cells": len(evaluated),
        "n_scored_output_cells_present": int(evaluated["output_cell_present"].sum()),
        "n_scored_output_cells_missing": int((~evaluated["output_cell_present"]).sum()),
        "n_baseline_seeds_unmatched_or_ambiguous": int((~valid_status).sum()),
        "baseline_match_status_counts": {str(k): int(v) for k, v in master["match_status"].value_counts(dropna=False).items()},
        "n_prediction_rows": len(pred_ids),
        "n_prediction_seed_ids_absent_from_master": len(unknown_seed_rows),
        "prediction_seed_ids_absent_from_master": [pred_ids[i] for i in unknown_seed_rows],
        "counts_in_unknown_output_seed_ids": float(pred[unknown_seed_rows].sum()) if unknown_seed_rows else 0.0,
        "n_reference_genes": len(ref_genes),
        "n_missing_prediction_genes_zero_filled": len(missing_genes),
        "missing_prediction_genes": missing_genes,
        "extra_prediction_genes_excluded": extra_genes,
        "counts_in_extra_prediction_genes": float(pred[:, extra_columns].sum()) if extra_columns else 0.0,
        "all_prediction_counts_including_halo_and_unknown_seeds": float(pred.sum()),
        "all_reference_counts_including_halo": float(truth.sum()),
        "reference_coverage_available": reference_metadata is not None,
        "interpretation": "Gene-count agreement conditional on frozen baseline matched nuclei; not molecular-identity accuracy.",
    }
    coverage = reference_seed_coverage(reference_metadata, ref_ids, _row_sum(truth), master,
                                       accepted_match_statuses=accepted_match_statuses) if reference_metadata is not None else pd.DataFrame()
    return EvaluationResult(evaluated, core_metrics, celltype_metrics, coverage, audit)


def evaluate_h5ad(
    prediction_path: str | Path,
    reference_path: str | Path,
    seed_map: pd.DataFrame | str | Path,
    *,
    method: str,
    condition: str,
    replicate: int = 0,
    prediction_layer: Optional[str] = None,
    reference_layer: Optional[str] = None,
    **kwargs,
) -> EvaluationResult:
    """AnnData convenience loader; count matrices must already be standardized."""
    import anndata as ad
    predicted = ad.read_h5ad(prediction_path)
    reference = ad.read_h5ad(reference_path)
    mapping = pd.read_csv(seed_map, dtype={"reference_cell_id": str, "sample_id": str, "core_id": str,
                                           "component_id": str, "bundle_id": str}) if not isinstance(seed_map, pd.DataFrame) else seed_map
    if "seed_id" not in predicted.obs or "reference_cell_id" not in reference.obs:
        raise ValueError("Standardized prediction obs.seed_id and hidden reference obs.reference_cell_id are required.")
    pred_matrix = predicted.layers[prediction_layer] if prediction_layer else predicted.X
    ref_matrix = reference.layers[reference_layer] if reference_layer else reference.X
    return evaluate_assignment(
        pred_matrix, predicted.obs["seed_id"], predicted.var_names,
        ref_matrix, reference.obs["reference_cell_id"], reference.var_names, mapping,
        method=method, condition=condition, replicate=replicate,
        reference_metadata=reference.obs.copy(), **kwargs,
    )


def paired_core_bootstrap(
    core_metrics: pd.DataFrame,
    *,
    metric: str,
    method_a: str,
    method_b: str,
    condition: Optional[str] = None,
    n_bootstrap: int = 2000,
    seed: int = 0,
    strata: Iterable[str] = ("sample_id",),
) -> dict:
    """Descriptive paired core bootstrap, averaging technical repeats first.

    Conditions must be selected one at a time. Sampling is within strata;
    neither individual cells nor perturbation replicates are treated as
    independent biological observations. Cores from a single slide still do
    not provide independent-slide inference.
    """
    required = {"method", "condition", "sample_id", "core_id", metric}
    if not required.issubset(core_metrics):
        raise ValueError(f"core_metrics lacks columns {sorted(required - set(core_metrics))}")
    if n_bootstrap < 1:
        raise ValueError("n_bootstrap must be positive.")
    data = core_metrics.loc[core_metrics["method"].isin([method_a, method_b])].copy()
    if condition is not None:
        data = data.loc[data["condition"].eq(condition)]
    if data["condition"].nunique() != 1:
        raise ValueError("Select exactly one condition for a paired comparison.")
    strata = list(strata)
    if any(column not in data for column in strata):
        raise ValueError("A requested bootstrap stratum is absent.")
    identifiers = list(dict.fromkeys(["sample_id", "core_id"] + strata))
    averaged = data.groupby(identifiers + ["method"], dropna=False, observed=True)[metric].mean().reset_index()
    paired = averaged.pivot(index=identifiers, columns="method", values=metric).reset_index()
    if method_a not in paired or method_b not in paired:
        raise ValueError("Both methods must have results in this condition.")
    missing = ~np.isfinite(paired[method_a]) | ~np.isfinite(paired[method_b])
    if missing.any():
        raise ValueError(f"{int(missing.sum())} cores lack a finite paired result; resolve missing runs before bootstrapping.")
    paired["difference"] = paired[method_a] - paired[method_b]
    if paired.empty:
        raise ValueError("No paired cores.")
    if strata:
        grouper = strata[0] if len(strata) == 1 else strata
        blocks = [group["difference"].to_numpy(float) for _, group in paired.groupby(grouper, dropna=False, observed=True)]
    else:
        blocks = [paired["difference"].to_numpy(float)]
    rng = np.random.default_rng(seed)
    bootstrap = np.empty(n_bootstrap)
    for i in range(n_bootstrap):
        bootstrap[i] = np.concatenate([rng.choice(block, size=len(block), replace=True) for block in blocks]).mean()
    lower, upper = np.quantile(bootstrap, [0.025, 0.975])
    return {
        "metric": metric, "method_a": method_a, "method_b": method_b,
        "difference_direction": "method_a - method_b", "condition": str(data["condition"].iloc[0]),
        "n_paired_cores": len(paired), "mean_paired_difference": float(paired["difference"].mean()),
        "bootstrap_95pct_low": float(lower), "bootstrap_95pct_high": float(upper),
        "n_bootstrap": int(n_bootstrap), "seed": int(seed), "strata": strata,
        "interpretation": "Descriptive uncertainty across sampled cores; not independent-slide population inference.",
    }
