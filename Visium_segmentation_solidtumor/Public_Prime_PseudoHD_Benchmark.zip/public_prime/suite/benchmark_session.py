"""Select one public specimen in each notebook/kernel, independently of the original study."""
from pathlib import Path
import os
from p06212_benchmark.common import load_config, output_root

def start(config_path=None):
    suite = Path(__file__).resolve().parent
    pointer = suite / "ACTIVE_CONFIG_PATH.txt"
    value = config_path or os.getenv("PSEUDOHD_CONFIG")
    if not value and pointer.is_file():
        value = pointer.read_text().strip()
    if not value:
        raise FileNotFoundError("Run preparation/activation for ONE specimen or set PSEUDOHD_CONFIG to its absolute config.json path before starting this notebook.")
    p = Path(value).expanduser()
    if not p.is_absolute() or not p.is_file():
        raise FileNotFoundError(f"Selected config must be an existing absolute file: {p}")
    cfg = load_config(p)
    if len(cfg.get("samples",{})) != 1:
        raise ValueError("Use one specimen/panel/H&E per public run configuration.")
    if not cfg.get("output_root") or not Path(cfg["output_root"]).expanduser().is_absolute():
        raise ValueError("Specify an absolute, specimen-specific output_root.")
    root = output_root(cfg)
    print("ACTIVE SPECIMEN:", next(iter(cfg["samples"])), "\nConfiguration:", p, "\nRun directory:", root)
    return p, cfg, root
