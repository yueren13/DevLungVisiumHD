"""Read-only native Xenium inventory for the public Prime pseudo-HD benchmark.

CPython 3.9+, h5py and pyarrow. Only transcript and boundary Parquet metadata,
the original cell ID column, HDF5 feature metadata and the annotation CSVs are
read. No full transcript/expression matrix or images are loaded.
"""
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path


def _string(x):
    if isinstance(x, bytes):
        return x.decode("utf-8")
    return x if isinstance(x, str) else (None if x is None else str(x))


def _column(names, aliases, explicit=None):
    if explicit is not None:
        if explicit not in names:
            raise ValueError(f"Column override {explicit!r} absent from {list(names)!r}.")
        return explicit
    norm = lambda s: "".join(c for c in s.lower() if c.isalnum())
    accepted = set(map(norm, aliases))
    matches = [c for c in names if norm(c) in accepted]
    if len(matches) != 1:
        raise ValueError(f"Cannot choose one column from {matches!r} (all columns: {list(names)!r}). Set an explicit override.")
    return matches[0]


def _annotations(path, ref, label_id=None, label_col=None):
    # IDs are compared literally (UTF-8 bytes decoded); no stripping of sample
    # suffixes, numeric coercion, row-order correspondence or nearest-cell joins.
    first_labels, seen_ids, conflicts = {}, set(), set()
    repeated, nrows, missing_id, missing_label = 0, 0, 0, 0
    counts = Counter()
    with Path(path).open(encoding="utf-8-sig", newline="") as f:
        rd = csv.DictReader(f)
        names = rd.fieldnames or []
        if len(names) != len(set(names)):
            raise ValueError(f"CSV has duplicate column names: {names!r}")
        idcol = _column(names, ["cell_id", "cell_barcode", "barcode"], label_id)
        valcol = _column(names, ["group", "cell_type", "celltype", "cell_group", "annotation",
                                 "cell_type_label", "label", "cluster", "Leiden_celltype"], label_col)
        if idcol == valcol:
            raise ValueError("Cell ID and annotation label must be different columns.")
        for row in rd:
            if None in row:
                raise ValueError(f"CSV row {rd.line_num} has too many fields for the header.")
            nrows += 1
            cid, val = row.get(idcol), row.get(valcol)
            if cid is None or not cid.strip():
                missing_id += 1
                continue
            repeated += cid in seen_ids
            seen_ids.add(cid)
            if val is None or not val.strip():
                missing_label += 1
                continue
            counts[val] += 1
            if cid in first_labels and first_labels[cid] != val:
                conflicts.add(cid)
            else:
                first_labels[cid] = val
    result = dict(id_column=idcol, label_column=valcol, columns=names, rows=nrows,
                  unique_nonempty_ids=len(seen_ids), blank_id_rows=missing_id,
                  blank_label_rows_with_id=missing_label, repeated_id_rows=repeated,
                  conflicting_label_ids=len(conflicts), conflict_examples=sorted(conflicts)[:5],
                  label_row_counts=dict(sorted(counts.items())), label_count=len(counts))
    issues = []
    if not nrows or not first_labels:
        issues.append("No nonblank labeled cell IDs.")
    if missing_id:
        issues.append("One or more annotation rows have a blank ID.")
    if repeated:
        issues.append("Repeated annotation IDs: review duplicates or multiple memberships; do not join arbitrarily.")
    if ref is None:
        issues.append("Original reference cell IDs were unavailable; cannot establish exact joins.")
    else:
        extra = seen_ids - ref
        usable = (first_labels.keys() & ref) - conflicts
        result.update(exact_id_matches=len(seen_ids & ref), source_ids_absent_from_reference=len(extra),
                      source_id_mismatch_examples=sorted(extra)[:5],
                      unique_reference_cells_with_unambiguous_nonblank_label=len(usable),
                      reference_cells_without_unambiguous_nonblank_label=len(ref) - len(usable),
                      reference_label_coverage=len(usable) / len(ref) if ref else None)
        if extra:
            issues.append("Some annotation IDs are absent from this original reference; verify dataset/version and ID namespace.")
        if not usable:
            issues.append("No unambiguous nonblank labels match original reference cells.")
    return result, issues


def _panel_from_features(names, kinds, ids, report):
    names = list(map(_string, names)); kinds = list(map(_string, kinds)); ids = list(map(_string, ids))
    if len(names) != len(kinds) or len(names) != len(ids):
        raise ValueError("HDF5 feature name, ID and feature_type vectors differ in length.")
    if any(v is None or not v.strip() for v in kinds):
        raise ValueError("Blank feature_type in HDF5: inspect before declaring a measured panel.")
    genes = [(g,i) for g,t,i in zip(names,kinds,ids) if t == "Gene Expression"]
    gnames = [g for g,i in genes]
    if not gnames or any(g is None or not g.strip() for g in gnames):
        raise ValueError("No Gene Expression features or a blank gene name.")
    duplicates = sorted(k for k,n in Counter(gnames).items() if n > 1)
    gnames = sorted(set(gnames))
    suspicious = [g for g in gnames if g.lower().startswith(("negcontrol", "genomiccontrol",
                                                           "unassignedcodeword", "deprecatedcodeword"))]
    # Include sorted names, sufficient to audit the actual intersection on disk.
    report.update(all_features=len(names), feature_type_counts=dict(Counter(kinds)),
                  gene_expression_names=gnames, n_gene_expression=len(gnames),
                  duplicate_gene_expression_names=duplicates, suspicious_gene_expression_names=suspicious,
                  gene_expression_names_sha256=hashlib.sha256(json.dumps(
                      gnames, ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest())
    if duplicates or suspicious:
        raise ValueError("Measured gene names repeat or include apparent controls; review feature identity before building bins.")


def _parquet_info(pf, required, numeric=()):
    import pyarrow as pa
    schema = pf.schema_arrow
    info = dict(columns=schema.names, n_rows=pf.metadata.num_rows,
                n_row_groups=pf.metadata.num_row_groups,
                column_types={f.name:str(f.type) for f in schema})
    if pf.metadata.num_rows == 0:
        raise ValueError("No rows.")
    missing = set(required) - set(schema.names)
    if missing:
        raise ValueError(f"Missing required columns {sorted(missing)}; present columns: {schema.names}")
    for name in numeric:
        t = schema.field(name).type
        if not (pa.types.is_integer(t) or pa.types.is_floating(t) or pa.types.is_decimal(t)):
            raise ValueError(f"Expected numeric values for {name}, found {t}.")
    return info


def audit_tables(outs_dir, annotation_csv, gene_groups_csv=None, *, label_id=None, label_col=None):
    """Inspect raw input metadata and exact ID matches; return a JSON-ready dict.

    raw_tables_ok validates this limited read only. It does NOT validate alignment,
    labels' biological provenance, geometry or every transcript. annotation_join_ok
    is independent; unannotated original cells are retained. Explicit CSV column
    overrides are exact literal header names.
    """
    root = Path(outs_dir)
    result = {"raw_tables_ok":False, "annotation_join_ok":False, "blockers":[],
              "annotation_issues":[], "warnings":[], "transcripts":{}, "cells":{},
              "panel":{}, "boundaries":{}, "annotations":{}, "gene_groups":{}}
    blockers = result["blockers"]
    ref = None
    try:
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(root / "transcripts.parquet")
        tx = _parquet_info(pf, ["x_location","y_location","feature_name","cell_id","qv"],
                           ["x_location","y_location","qv"])
        tx["optional_feature_flags"] = [k for k in ("is_gene","codeword_category","codeword_index")
                                        if k in tx["columns"]]
        tx["has_transcript_id"] = "transcript_id" in tx["columns"]
        tx["value_audit"] = "Footer only. During extraction require finite coordinates, panel gene and qv >= 20; retain eligible unassigned gene calls in input."
        result["transcripts"] = tx
    except Exception as e:
        blockers.append(f"transcripts.parquet: {type(e).__name__}: {e}")
    try:
        import pyarrow.parquet as pq
        pf = pq.ParquetFile(root / "cells.parquet")
        info = _parquet_info(pf, ["cell_id"])
        ids = set()
        duplicates = nulls = 0
        for batch in pf.iter_batches(batch_size=65536, columns=["cell_id"]):
            for x in batch.column(0).to_pylist():
                s = _string(x)
                if s is None or not s.strip():
                    nulls += 1
                else:
                    duplicates += s in ids
                    ids.add(s)
        info.update(unique_ids=len(ids), duplicate_rows=duplicates, null_or_empty_ids=nulls)
        result["cells"] = info
        if duplicates or nulls:
            raise ValueError("Raw cell ID column does not uniquely identify every row.")
        ref = ids
    except Exception as e:
        blockers.append(f"cells.parquet: {type(e).__name__}: {e}")
    for name in ("cell_boundaries", "nucleus_boundaries"):
        try:
            import pyarrow.parquet as pq
            pf = pq.ParquetFile(root / (name+".parquet"))
            result["boundaries"][name] = _parquet_info(pf, ["cell_id","vertex_x","vertex_y"], ["vertex_x","vertex_y"])
        except Exception as e:
            blockers.append(f"{name}.parquet: {type(e).__name__}: {e}")
    try:
        import h5py
        with h5py.File(root / "cell_feature_matrix.h5", "r") as f:
            feat = f["matrix/features"]
            _panel_from_features(feat["name"][:], feat["feature_type"][:], feat["id"][:], result["panel"])
    except Exception as e:
        blockers.append(f"cell_feature_matrix.h5: {type(e).__name__}: {e}")
    if annotation_csv:
        try:
            result["annotations"], issues = _annotations(annotation_csv, ref, label_id, label_col)
            result["annotation_issues"].extend(issues)
            if result["annotations"].get("reference_cells_without_unambiguous_nonblank_label"):
                result["warnings"].append("Not all reference cells have an unambiguous label; retain them in overall evaluation and report annotation coverage.")
        except Exception as e:
            result["annotation_issues"].append(f"annotation CSV: {type(e).__name__}: {e}")
    else:
        result["annotation_issues"].append("No annotation CSV supplied; omit lineage stratification until available.")
    if gene_groups_csv:
        try:
            with Path(gene_groups_csv).open(encoding="utf-8-sig",newline="") as f:
                d = csv.DictReader(f)
                result["gene_groups"] = dict(columns=d.fieldnames, n_rows=sum(1 for _ in d),
                                             role="Descriptive marker groups, not the measured panel or cell labels.")
        except Exception as e:
            result["warnings"].append(f"Optional gene-group CSV: {type(e).__name__}: {e}")
    result["raw_tables_ok"] = not blockers
    result["annotation_join_ok"] = not result["annotation_issues"]
    return result
