"""Import public Prime v3 output for the existing pseudo-HD benchmark.

Public API: build_spatial_store(outs, destination), audit_spatial_store(outs, store_path),
write_import_report(report, path). Neither import nor audit touches the source files.
The audit is specific to *unmodified original* Xenium pixel and micron frames; it
does not fit a transform, approve H&E registration, choose ROIs, or approve labels.
"""
from contextlib import contextmanager
import inspect
import json
from importlib.metadata import version, PackageNotFoundError
from pathlib import Path
from uuid import uuid4

import numpy as np
import pandas as pd


def _versions():
    out = {}
    for pkg in ('spatialdata', 'spatialdata-io', 'dask', 'shapely', 'pyarrow', 'tifffile', 'zarr'):
        try:
            out[pkg] = version(pkg)
        except PackageNotFoundError:
            pass
    return out


def _strings(values):
    def one(v):
        if pd.isna(v):
            raise ValueError("Missing cell or feature ID")
        s = v.decode('utf-8') if isinstance(v, (bytes, np.bytes_)) else str(v)
        if not s:
            raise ValueError("Empty cell or feature ID")
        return s
    return pd.Index([one(v) for v in values], dtype='object')


def _xy_transform(element):
    from spatialdata.transformations import get_transformation
    a = np.asarray(get_transformation(element, to_coordinate_system='global').to_affine_matrix(
        input_axes=('x', 'y'), output_axes=('x', 'y')), dtype=float)
    if a.shape != (3, 3) or not np.isfinite(a).all() or not np.allclose(a[2], [0, 0, 1]) or abs(np.linalg.det(a[:2, :2])) < 1e-12:
        raise ValueError("Expected nonsingular 2D affine in global frame")
    return a


def _level0(image):
    if hasattr(image, 'data') and hasattr(image, 'dims'):
        return image
    for key in ('scale0', 's0'):
        if key in image:
            node = image[key]
            ds = node.to_dataset() if hasattr(node, 'to_dataset') else node.ds
            if len(ds.data_vars) == 1:
                return ds[next(iter(ds.data_vars))]
    raise ValueError("Cannot unambiguously identify DAPI level 0")


def _raw_paths(outs):
    src = Path(outs).expanduser().resolve()
    required = ['experiment.xenium', 'cells.parquet', 'cell_boundaries.parquet',
                'nucleus_boundaries.parquet', 'cell_feature_matrix.h5', 'cells.zarr.zip',
                'transcripts.parquet', 'morphology_focus/morphology_focus_0000.ome.tif']
    missing = [name for name in required if not (src / name).is_file()]
    if missing:
        raise FileNotFoundError(f"{src} is not an extracted public Xenium output bundle; missing {missing}")
    return src


@contextmanager
def _raw_dapi(outs):
    """Read one standalone v3 focus channel, retaining tiled access (never TIFF.asarray)."""
    import tifffile
    import zarr
    with tifffile.TiffFile(outs / 'morphology_focus/morphology_focus_0000.ome.tif') as tif:
        page = tif.pages[0]  # physical DAPI TIFF, level 0; avoid multi-file OME channel assembly
        if page.tags.get('Orientation') is not None and int(page.tags['Orientation'].value) != 1:
            raise ValueError('DAPI TIFF has non-native stored orientation; inspect frame before import')
        if page.axes != 'YX' or not page.is_tiled:
            raise ValueError(f"DAPI TIFF requires a tiled grayscale level 0, found {page.axes}, tiled={page.is_tiled}")
        store = page.aszarr()
        try:
            arr = zarr.open_array(store=store, mode='r')
            if tuple(arr.shape) != tuple(page.shape):
                raise ValueError("Unexpected Zarr view of the DAPI TIFF; refusing a pyramid/series guess")
            yield store, arr
        finally:
            store.close()


def _run_offsets(ids):
    """Offsets for a contiguous, positive label sequence; refuse disjoint repeated labels."""
    ids=np.asarray(ids)
    if ids.ndim!=1 or not len(ids) or ids.dtype.kind not in 'iu' or np.any(ids<=0):
        raise ValueError("Missing, zero, negative, non-integral or empty native polygon labels")
    starts=np.r_[0,np.flatnonzero(ids[1:]!=ids[:-1])+1]
    if len(np.unique(ids[starts]))!=len(starts):
        raise ValueError("Native polygon label occurs in disjoint vertex groups; inspect order")
    return np.r_[starts,len(ids)]


def _polygons(flat, offsets):
    from shapely import GeometryType, from_ragged_array
    if not np.isfinite(flat).all() or np.min(np.diff(offsets))<3:
        raise ValueError("Nonfinite vertices or a native polygon with fewer than three vertices needs review")
    return from_ragged_array(GeometryType.POLYGON, flat,
                             (offsets,np.arange(len(offsets),dtype=np.int64)))


def _native_nuclei(outs, owners, mpp):
    """Use label_id, never a merged polygon per unique owner. Covers v3 preview and XRrun."""
    import geopandas as gp
    import pyarrow as pa
    import pyarrow.compute as pc
    import pyarrow.parquet as pq
    from spatialdata.models import ShapesModel
    from spatialdata.transformations import Scale
    src=outs/'nucleus_boundaries.parquet'
    if 'label_id' in pq.read_schema(src).names:
        table=pq.read_table(src,columns=['label_id','cell_id','vertex_x','vertex_y'])
        if any(c.null_count for c in table.columns):
            raise ValueError("Missing ID or coordinate in original nucleus boundaries")
        labels=table['label_id'].to_numpy()
        offsets=_run_offsets(labels)
        cid=table['cell_id'].combine_chunks()
        if pa.types.is_dictionary(cid.type):
            cid=pc.dictionary_decode(cid)
        # A change of owner within one label is inconsistent, irrespective of row order.
        changes=pc.not_equal(cid.slice(0,len(cid)-1),cid.slice(1)).to_numpy(zero_copy_only=False)
        if np.any(changes & (labels[:-1]==labels[1:])):
            raise ValueError("A native nucleus label has more than one parent cell")
        ids=_strings(pc.take(cid,pa.array(offsets[:-1])).to_pylist())
        labelids=labels[offsets[:-1]].astype(np.int64)
        coords=np.column_stack([table[k].to_numpy() for k in ('vertex_x','vertex_y')])
        geoms=_polygons(coords,offsets)
        how='Parquet label_id groups and explicit cell_id owners'
    else:
        # A preview bundle may lack label_id. Use the published v3 native zarr
        # polygon-to-cell relation, not the order of the cell table. Empty polygons
        # mean the original record has no polygon; they must not become scored nuclei.
        import zarr
        with zarr.storage.ZipStore(outs/'cells.zarr.zip',mode='r') as store:
            group=zarr.open_group(store=store,mode='r')
            native=group['polygon_sets/0']
            cells=np.asarray(group['cell_id'][:])
            if cells.ndim!=2 or cells.shape[1]!=2 or cells.dtype.kind!='u':
                raise ValueError("Unexpected native cell ID encoding")
            trans=str.maketrans('0123456789abcdef','abcdefghijklmnop')
            owner_codes=np.array([f'{int(pref):08x}'.translate(trans)+'-'+str(int(suf)) for pref,suf in cells],dtype=object)
            this_owner=np.asarray(native['cell_index'][:]).ravel()
            nv=np.asarray(native['num_vertices'][:]).ravel()
            vertices=native['vertices']
            if (len(this_owner)!=len(nv) or this_owner.dtype.kind not in 'iu' or len(nv)==0
                or np.any(this_owner<0) or np.max(this_owner)>=len(cells) or np.any(nv<0)
                or vertices.shape[0]!=len(nv) or not (vertices.ndim==2 and vertices.shape[1]%2==0
                or vertices.ndim==3 and vertices.shape[2]==2)):
                raise ValueError("Unsupported native nuclear polygon array layout; inspect source geometry")
            gs=[]
            for first in range(0,len(nv),8192):
                n=nv[first:first+8192]
                vv=np.asarray(vertices[first:first+len(n)]).reshape(len(n),-1,2)
                if np.any(n>vv.shape[1]):
                    raise ValueError("Native ring exceeds padded vertex count")
                valid=n>0
                if valid.any():
                    coords=vv[np.arange(vv.shape[1])[None,:]<n[:,None]]
                    gs.extend(_polygons(coords,np.r_[0,np.cumsum(n[valid],dtype=np.int64)]))
            present=nv>0
            labelids=np.flatnonzero(present)+1
            ids=_strings(owner_codes[this_owner[present]])
            geoms=gs
        how='cells.zarr.zip polygon_sets/0 cell_index joined to its native cell_id array (zero-vertex entries absent)'
    unknown=ids.difference(owners)
    if len(unknown):
        raise ValueError(f"Original nuclear polygon owners absent from input table: {unknown[:5].tolist()}")
    gdf=gp.GeoDataFrame({'cell_id':ids.to_numpy(),'geometry':geoms},index=pd.Index(labelids,name='label_id'))
    return ShapesModel.parse(gdf,transformations={'global':Scale([1./mpp,1./mpp],axes=('x','y'))}),how


def build_spatial_store(outs, destination):
    """Create a working store once. Requires spatialdata-io, tifffile (+imagecodecs), zarr and dask.

    Loads the cell matrix and boundaries; the large transcript table is never imported/copied.
    Reference table annotates cell_circles (center + area only). Actual scoring uses cell_boundaries
    and nucleus_boundaries, never those circles. Keep raw exports incl original segmentation masks.
    A failed write leaves a uniquely named sibling marked '.partial-*' for inspection.
    """
    import dask
    import dask.array as da
    from spatialdata.models import Image2DModel
    from spatialdata.transformations import Identity
    from spatialdata_io import xenium

    src = _raw_paths(outs)
    dest = Path(destination).expanduser().resolve()
    if dest.suffix != '.zarr' or src == dest or src in dest.parents:
        raise ValueError("Use a NEW .zarr path outside the source output bundle")
    if dest.exists():
        raise FileExistsError(f"Refusing overwrite: {dest}; audit_spatial_store() can inspect an existing store")
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.parent / (dest.stem + '.partial-' + uuid4().hex[:10] + '.zarr')
    kwargs = dict(cells_as_circles=True, cells_labels=False, nucleus_labels=False,
                  cells_boundaries=True, nucleus_boundaries=False, morphology_focus=False,
                  morphology_mip=False, aligned_images=False, transcripts=False, cells_table=True)
    params = inspect.signature(xenium).parameters
    for current, older in [('cells_as_circles', 'cells_as_shapes'), ('cells_boundaries', 'cell_boundaries'),
                           ('cells_labels', 'cell_labels')]:
        if current not in params and older in params:
            kwargs[older] = kwargs.pop(current)
    missing = sorted(set(kwargs) - set(params))
    if missing:
        raise RuntimeError(f"Installed spatialdata_io.xenium signature lacks {missing}; do not fall back to reading everything.")
    if 'gex_only' in params:
        kwargs['gex_only'] = True
    if 'n_jobs' in params and params['n_jobs'].default not in (None, inspect.Parameter.empty):
        kwargs['n_jobs'] = 2  # legacy parallel polygon extraction; newer readers leave this deprecated kwarg unset
    with _raw_dapi(src) as (_, raw), dask.config.set(scheduler='threads', num_workers=2):
        sdata = xenium(src, **kwargs)
        # Explicit chunks align with source tiles where possible and avoid reading all focus channels.
        orig=sdata.tables['table']
        parent_ids=_strings(orig.obs['cell_id'] if 'cell_id' in orig.obs else orig.obs_names)
        pixel_size=float(json.loads((src/'experiment.xenium').read_text())['pixel_size'])
        if not np.isfinite(pixel_size) or pixel_size<=0:
            raise ValueError("experiment.xenium pixel_size is missing or nonpositive")
        if 'cell_boundaries' not in sdata.shapes:
            raise ValueError(f"Reader did not return expected cell polygons: {list(sdata.shapes)}")
        nuc,how=_native_nuclei(src,parent_ids,pixel_size)
        sdata.shapes['nucleus_boundaries']=nuc
        if hasattr(sdata,'attrs'):
            sdata.attrs['prime_nucleus_polygon_source']=how
        tile = tuple(max(1, min(int(s), (1024 // max(int(c), 1) or 1) * int(c))) for c,s in zip(raw.chunks,raw.shape))
        arr = da.from_array(raw, chunks=tile, asarray=False, fancy=False, name='raw-dapi-'+uuid4().hex)
        sdata.images['morphology_focus'] = Image2DModel.parse(arr[None,:,:], dims=('c','y','x'),
                        c_coords=['DAPI'], transformations={'global': Identity()})
        sdata.write(tmp)
    if dest.exists():
        raise FileExistsError(f"Destination appeared while writing; preserved separate {tmp}")
    tmp.rename(dest)
    return str(dest)


def _raw_bounds(path, sample_ids):
    import pyarrow as pa
    import pyarrow.parquet as pq
    schema = pq.read_schema(path)
    field = schema.field('cell_id').type
    if pa.types.is_dictionary(field):
        field = field.value_type
    binary = pa.types.is_binary(field) or pa.types.is_large_binary(field) or pa.types.is_fixed_size_binary(field)
    vals = [s.encode() if binary else s for s in sample_ids]
    raw = pq.read_table(path, columns=['cell_id','vertex_x','vertex_y'], filters=[('cell_id','in',vals)]).to_pandas()
    raw['cell_id'] = _strings(raw.cell_id)
    return raw.groupby('cell_id').agg(x0=('vertex_x','min'), y0=('vertex_y','min'), x1=('vertex_x','max'), y1=('vertex_y','max'))


def _shape_audit(gdf, raw_parquet, raw_ids, global_to_native, mpp, sample_ids, require_all, expected_nuclei=None):
    from shapely import affinity
    col = 'cell_id' if 'cell_id' in gdf else None
    ids = _strings(gdf[col] if col else gdf.index)
    seen = ids.unique()
    unknown = seen.difference(raw_ids)
    if len(unknown):
        raise ValueError(f"{raw_parquet.name}: {len(unknown)} unknown polygon owner IDs incl {unknown[:5].tolist()}; do not match by row order")
    cell_duplicates = int(ids.duplicated().sum())
    # An old reader can collapse multiple nuclei under one cell barcode. Never silently
    # equate one row with one biological nucleus; resolve discordance from native masks.
    if not require_all and expected_nuclei is not None:
        observed = pd.Series(ids).value_counts().reindex(raw_ids, fill_value=0).to_numpy()
        n_discordant = int(np.sum(observed != np.asarray(expected_nuclei)))
    else:
        n_discordant = None
    missing = len(raw_ids.difference(seen))
    sample_ids = sample_ids[sample_ids.isin(seen)].tolist()
    if len(sample_ids)<min(4,len(raw_ids)):
        raise ValueError(f"Too few linked polygon owners available for {raw_parquet.name}")
    geom = gdf.geometry
    m = np.diag([mpp,mpp,1.0]) @ global_to_native @ _xy_transform(gdf)
    co = [m[0,0],m[0,1],m[1,0],m[1,1],m[0,2],m[1,2]]
    wanted = np.flatnonzero(ids.isin(sample_ids))
    sb = {}
    for i in wanted:
        g = geom.iloc[i]
        if g is None or g.is_empty:
            raise ValueError(f"Sampled {raw_parquet.name} has empty geometry for {ids[i]}")
        b = np.asarray(affinity.affine_transform(g,co).bounds,dtype=float)
        if ids[i] in sb:
            b = np.r_[np.minimum(sb[ids[i]][:2],b[:2]),np.maximum(sb[ids[i]][2:],b[2:])]
        sb[ids[i]] = b
    rb = _raw_bounds(raw_parquet,sample_ids)
    if set(rb.index)!=set(sample_ids):
        raise ValueError(f"Raw owner IDs unavailable for sampled {raw_parquet.name} rows")
    err=float(np.max(np.abs(np.stack([sb[s] for s in rb.index]) - rb.to_numpy())))
    if not np.isfinite(err) or err>0.002:
        raise ValueError(f"{raw_parquet.name}: geometry bounds differ from original vertex bounds by {err:.5g} µm; frame/ID or prior geometry edits need review")
    invalid = (~geom.is_valid) | geom.is_empty | geom.isna() | ~geom.geom_type.isin(['Polygon','MultiPolygon'])
    return {'id_column':col, 'n_rows':len(ids),'n_owner_ids':len(seen),'extra_rows_same_owner':cell_duplicates,
            'n_cells_without_geometry':missing,'n_invalid_empty_or_nonpolygon_geometries':int(invalid.sum()),
            'examples_invalid':ids[np.asarray(invalid)][:8].tolist(), 'n_nucleus_multiplicity_disagreements':n_discordant,'n_checked_owners':len(sample_ids),
            'max_sample_extent_error_um':err,'geometry_ready':bool(not invalid.any() and n_discordant in (None,0) and (not require_all or (not cell_duplicates and not missing)))}


def _palette_check(src, table):
    import h5py
    with h5py.File(src/'cell_feature_matrix.h5','r') as hf:
        features = hf['matrix/features']
        panel = _strings(features['name'][:])[_strings(features['feature_type'][:])=='Gene Expression']
    vk = next((k for k in ('feature_types','feature_type') if k in table.var), None)
    genes = _strings(table.var_names)
    if vk:
        genes = genes[_strings(table.var[vk])=='Gene Expression']
    if not panel.is_unique or not genes.is_unique or len(panel)!=len(genes) or set(panel)!=set(genes):
        raise ValueError("Table gene symbols do not match the native Gene Expression feature set exactly. Inspect duplicated names and reader renaming; do not call unmeasured genes zero.")
    return vk, len(genes)


def audit_spatial_store(outs, store_path, *, dapi_channel=0):
    """Read the existing store and raw evidence. Returns JSON-ready dict; no writes.

    'coordinate_spec.verified' addresses the *native RNA frame only*, never H&E registration.
    Geometry readiness and the human transcript-source provenance review are independent gates.
    Exceptions indicate unsupported schema, wrong source, transformed data or insufficient
    evidence; leave coordinate_spec.verified=False and inspect rather than overriding a check.
    """
    import spatialdata as sd
    import pyarrow.parquet as pq
    src = _raw_paths(outs)
    path = Path(store_path).expanduser().resolve()
    if not path.is_dir():
        raise FileNotFoundError(path)
    meta=json.loads((src/'experiment.xenium').read_text())
    mpp=float(meta['pixel_size'])
    if not np.isfinite(mpp) or mpp<=0:
        raise ValueError("experiment.xenium does not give a positive source pixel_size")
    sdata=sd.read_zarr(path,selection=('images','shapes','tables'))
    table=sdata.tables['table']
    obs_ids=_strings(table.obs['cell_id'] if 'cell_id' in table.obs else table.obs_names)
    cell_cols=['cell_id','x_centroid','y_centroid']
    if 'nucleus_count' in pq.read_schema(src/'cells.parquet').names:
        cell_cols.append('nucleus_count')
    raw_cells=pq.read_table(src/'cells.parquet',columns=cell_cols).to_pandas()
    raw_ids=_strings(raw_cells.cell_id)
    if not raw_ids.is_unique or not obs_ids.is_unique or len(obs_ids)!=len(raw_ids) or set(obs_ids)!=set(raw_ids):
        raise ValueError("Original/raw reference cell ID universes disagree; preserve all original cells and their unmodified barcodes")
    raw_cells.index=raw_ids
    sample=raw_ids.take(np.sort(np.random.default_rng(2026).choice(len(raw_ids), min(36,len(raw_ids)), replace=False)))
    if not len(sample):
        raise ValueError("Empty reference")
    xy=raw_cells.loc[sample,['x_centroid','y_centroid']].to_numpy(float)
    imported=np.asarray(table.obsm['spatial'])[obs_ids.get_indexer(sample),:2]
    cen_err=float(np.max(np.abs(imported-xy)))
    if not np.isfinite(cen_err) or cen_err>0.002:
        raise ValueError(f"Imported cells.obsm['spatial'] differs from same-ID raw cell centers by {cen_err} µm; inspect coordinate and ID mapping.")
    image=sdata.images['morphology_focus']
    im=_level0(image)
    if set(im.dims)!={'c','y','x'}:
        raise ValueError(f"DAPI layer must have c,y,x dimensions; found {im.dims}")
    for dim in ('x','y'):
        if dim in im.coords and not np.allclose(im.coords[dim].values, np.arange(im.sizes[dim])+.5, rtol=0,atol=1e-4):
            raise ValueError(f"Noncanonical scale-0 {dim}-axis offsets; inspect store crop/scale before inference")
    global_to_native=np.linalg.inv(_xy_transform(im))
    matched=0
    with _raw_dapi(src) as (_, raw):
        if tuple(raw.shape)!=(im.sizes['y'],im.sizes['x']):
            raise ValueError("Scale-0 DAPI shape does not match raw native focus TIFF")
        for x,y in np.rint(xy/mpp).astype(int):
            h,w=raw.shape
            if not(8<=x<=w-8 and 8<=y<=h-8):
                continue
            yx=np.s_[y-8:y+8,x-8:x+8]
            original=np.asarray(raw[yx])
            if np.ptp(original)==0:
                continue
            imported=np.asarray(im.isel(c=int(dapi_channel), y=yx[0],x=yx[1]).transpose('y','x').values)
            if not np.array_equal(imported,original):
                raise ValueError("Scale-0 pixel values differ from the raw DAPI focus plane; check channel, source and orientation")
            matched+=1
            if matched>=4:
                break
    if matched<min(2,len(sample)):
        raise ValueError("Insufficient nonuniform DAPI windows; raw/store pixel frame is not established")
    geom={}
    for label, required in [('cell_boundaries',True),('nucleus_boundaries',False)]:
        geom[label]=_shape_audit(sdata.shapes[label],src/(label+'.parquet'),raw_ids,
                                 global_to_native,mpp,sample,required,expected_nuclei=raw_cells.get('nucleus_count'))
    vk, n_genes = _palette_check(src,table)
    pqf=pq.ParquetFile(src/'transcripts.parquet')
    tc={'x':'x_location','y':'y_location','gene':'feature_name','cell_id':'cell_id','qv':'qv'}
    if set(tc.values()) - set(pqf.schema_arrow.names):
        raise ValueError("Raw transcript Parquet lacks one or more required XY/gene/cell_id/qv fields")
    spec={'morphology_pixel_size_um':mpp,'coordinate_system':'global',
          'global_to_native_pixel_xy':global_to_native.tolist(),'verified':True,
          'evidence':f"Native full-resolution focus_0000 TIFF and store agree in {matched} nonuniform pixel windows; pixel_size read from {src/'experiment.xenium'}; ID-linked centroids and transformed raw-vs-store boundary extent checks in import report."}
    report={'source':str(src),'store':str(path),'reader_versions':_versions(),'n_cells':len(raw_ids),'n_gene_expression_features':n_genes,
            'nucleus_polygon_source': str(getattr(sdata,'attrs',{}).get('prime_nucleus_polygon_source','preexisting store; checked against native extents and available multiplicity')),
            'geometry':geom,'n_checked_cell_centroids':len(sample),'largest_centroid_error_um':cen_err,'n_matched_dapi_windows':matched,
            'n_raw_transcript_rows':pqf.metadata.num_rows, 'geometry_ready':all(g['geometry_ready'] for g in geom.values()),
            'reference_table_relation':{k:(str(v) if not isinstance(v,(list,tuple,str)) else v)
                for k,v in table.uns.get('spatialdata_attrs',{}).items()},
            'settings_patch':{'zarr_path':str(path),'experiment_path':str(src/'experiment.xenium'),'image_name':'morphology_focus',
             'dapi_channel':int(dapi_channel),'table_name':'table','cell_id_column':'cell_id' if 'cell_id' in table.obs else None,
             'cell_shape_name':'cell_boundaries','nucleus_shape_name':'nucleus_boundaries','cell_shape_id_column':geom['cell_boundaries']['id_column'],
             'nucleus_shape_id_column':geom['nucleus_boundaries']['id_column'],'feature_type_column':vk,'gene_column':None,
             'coordinate_spec':spec,'transcripts_parquet_path':str(src/'transcripts.parquet'),
             'raw_transcript_to_morphology_um':np.eye(3).tolist(),'transcript_columns':tc,'transcript_source_verified':False,
             'transcript_source_note':''}}
    return report


def write_import_report(report,path):
    """Write to a new path on success; no silent replacement of evidence."""
    p=Path(path)
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as fh:
        json.dump(report,fh,indent=2,allow_nan=False)
        fh.write('\n')
    return str(p)
