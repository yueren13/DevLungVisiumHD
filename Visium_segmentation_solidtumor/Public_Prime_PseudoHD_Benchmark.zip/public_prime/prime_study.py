"""Study setup for two public 10x samples; all writes are derived files."""
from pathlib import Path
import json, os, re, hashlib, math, tempfile
from copy import deepcopy
import numpy as np

HERE = Path(__file__).resolve().parent
BASE = Path.home() / "reny28/Projects/ShortProject/Xenium_pseudo_VisiumHD01"
SPECS = {
    "ovarian": ("Xenium_Prime_Ovarian_Cancer_FFPE_XRrun", "cell_groups", "https://www.10xgenomics.com/datasets/xenium-prime-ffpe-human-ovarian-cancer"),
    "reactive_node": ("Xenium_Prime_Human_Lymph_Node_Reactive_FFPE", "cell_types", "https://www.10xgenomics.com/datasets/preview-data-xenium-prime-gene-expression"),
}

def paths(base, key):
    prefix, typ, url = SPECS[key]
    d = Path(base).expanduser().resolve()/prefix
    outs = d/(prefix+"_outs")
    im = d/"images"
    return dict(prefix=prefix, root=d, outs=outs, url=url, annotation=d/f"{prefix}_{typ}.csv",
                gene_groups=d/f"{prefix}_gene_groups.csv", he=im/f"{prefix}_he_image.ome.tif",
                alignment=im/f"{prefix}_he_imagealignment.csv", regions=im/f"{prefix}_annotation.geojson",
                focus=outs/"morphology_focus"/"morphology_focus_0000.ome.tif")
def work_safe(base, work):
    work = Path(work).expanduser().resolve()
    for k in SPECS:
        src = paths(base,k)["root"]
        if work==src or src in work.parents or work in src.parents:
            raise ValueError(f"Choose a dedicated work folder outside both source trees: {work}")
    return work
def fresh_json(path, data):
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    encoded=json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False)+"\n"
    with p.open("x", encoding="utf-8") as f: f.write(encoded)
    return p
def matrix_file(path):
    m = np.loadtxt(path, delimiter=",", dtype=float, encoding="utf-8-sig")
    if m.shape!=(3,3) or not np.isfinite(m).all() or not np.allclose(m[-1],[0,0,1]) or abs(np.linalg.det(m[:2,:2]))<1e-12:
        raise ValueError("Expected a nonsingular finite 3 x 3 Explorer pixel affine, not a keypoint table.")
    return m
def tif_info(path):
    import tifffile
    with tifffile.TiffFile(path) as tif:
        s=tif.series[0]
        return dict(shape=list(s.shape), axes=s.axes, dtype=str(s.dtype), levels=len(s.levels))
def region_info(path):
    from collections import Counter
    g=json.loads(path.read_text())
    features=g.get("features",[]) if isinstance(g,dict) else []
    return {"feature_count":len(features),"geometry_types":dict(Counter(str(f.get('geometry',{}).get('type')) for f in features)),
            "property_keys":sorted({k for f in features for k in (f.get("properties") or {})}),
            "use":"review only; verify native H&E frame, units, and overlay before region joins"}
def inspect_raw(base, key, label_id=None, label_col=None):
    from prime_tables import audit_tables
    ps=paths(base,key); issues=[]; optic={}
    for name in ["he","alignment","focus","regions","annotation","gene_groups"]:
        p=ps[name]; optic[name]={"path":str(p),"exists":p.is_file()}
    try:
        m=matrix_file(ps["alignment"])
        optic['alignment'].update(matrix=m.tolist(),sha256=hashlib.sha256(ps["alignment"].read_bytes()).hexdigest())
    except Exception as e: issues.append(f"alignment: {e}")
    for n in ("he","focus"):
        try: optic[n].update(tif_info(ps[n]))
        except Exception as e: issues.append(f"{n}: {e}")
    if ps["regions"].is_file():
        try: optic["regions"].update(region_info(ps["regions"]))
        except Exception as e: optic["regions"]["warning"]=str(e)
    try:
        t=audit_tables(ps["outs"],ps["annotation"],ps["gene_groups"],label_id=label_id,label_col=label_col)
    except Exception as e:
        t={"raw_tables_ok":False,"annotation_join_ok":False,"blockers":[f"{type(e).__name__}: {e}"],
           "annotation_issues":[],"warnings":[]}
    for f in ["experiment.xenium","cell_boundaries.parquet","nucleus_boundaries.parquet","gene_panel.json","cells.zarr.zip"]:
        if not (ps["outs"]/f).is_file(): issues.append(f"Missing {f}")
    if (ps['outs']/'experiment.xenium').is_file():
        try:
            raw=json.loads((ps['outs']/'experiment.xenium').read_text())
            optic['experiment']={k:raw[k] for k in ('pixel_size','analysis_sw_version','run_name','preservation_method') if k in raw}
        except (ValueError,OSError,TypeError) as e: issues.append(f"experiment.xenium: {e}")
    return {"sample_id":key,"public_source":ps["url"],"outs":str(ps["outs"]),"files":optic,"file_issues":issues,"tables":t,
            "can_prepare_store":bool(t["raw_tables_ok"] and not issues),
            "alignment_status":"not visually reviewed; valid matrix format is not proof of registration"}
def configure(base, work, key, run_name, settings_patch, raw, *, label_id=None,label_col=None,
              use_labels=False,proseg_executable=None,coordinate_note="",source_note="",
              good=2,poor=2,bundle_size=4):
    """Write an isolated native-panel config once; refuse absent review and old run directories."""
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*",run_name): raise ValueError("Unsafe run name.")
    if not coordinate_note.strip() or not source_note.strip():
        raise ValueError("Record coordinate and molecule-source evidence first.")
    if raw['sample_id']!=key or not raw['can_prepare_store']: raise ValueError("Resolve specimen preflight before writing config.")
    if any(type(x) is not int or x<0 for x in (good,poor)) or good+poor<1 or type(bundle_size) is not int or bundle_size<1:
        raise ValueError("Review pilot quotas and positive bundle size.")
    p=paths(base,key); w=work_safe(base,work); rundir=w/key/run_name
    if rundir.exists(): raise FileExistsError(f"{rundir} exists. Use the existing config, or a new run name for changed inputs.")
    defaults=json.loads((HERE/'suite'/'defaults.json').read_text()); d=deepcopy(defaults); samp=d['samples'].get('SAMPLE',{})
    samp.update(deepcopy(settings_patch))
    if not (samp.get('coordinate_spec') or {}).get('verified'): raise ValueError("The store audit must verify the global coordinate frame first.")
    samp['coordinate_spec']['evidence']=samp['coordinate_spec'].get('evidence','')+"; reviewer: "+coordinate_note.strip()
    samp.update(component_id=key,alignment_csv=str(p["alignment"]),experiment_path=str(p['outs']/"experiment.xenium"),
                transcripts_parquet_path=str(p['outs']/"transcripts.parquet"),transcript_source_verified=True,
                transcript_source_note=source_note.strip(),raw_transcript_to_morphology_um=np.eye(3).tolist())
    d.update(project_id="Public_Prime_"+key,output_root=str(rundir/'results_root'),samples={key:samp},annotation_sources=[],celltype_column="Leiden_celltype",
             he_path=str(p["he"]),he_series_index=0,conditions=[dict(condition_id="baseline",dx_um=0.0,dy_um=0.0)],
             public_source=p["url"], panel_policy="native panel; one specimen per run")
    if use_labels:
        t=raw['tables']
        if not t.get("annotation_join_ok") or not (label_id and label_col):
            raise ValueError("Choose unambiguous exact ID and group columns from a passing annotation audit.")
        if (str(label_id),str(label_col))!=(str(t.get("annotations",{}).get("id_column")),str(t.get("annotations",{}).get("label_column"))):
            raise ValueError("Chosen label columns differ from the audited pair. Repeat the raw audit with explicit columns.")
        d['annotation_sources']=[dict(sample_id=key,component_id=key,path=str(p['annotation']),barcode_column=label_id,label_column=label_col,format='csv')]
    d['design'].update(target_counts={key:dict(good=good,poor=poor)},cores_per_bundle=bundle_size,bundle_columns=min(2,bundle_size))
    d['methods']['proseg']['executable']=str(Path(proseg_executable).expanduser()) if proseg_executable else ''
    if proseg_executable and not Path(d['methods']['proseg']['executable']).is_absolute(): raise ValueError("Proseg requires an absolute executable path.")
    d['stardist'].update(parameters_frozen=False,calibration_note="")
    return fresh_json(rundir/'config.json',d)
def activate(config_path):
    p=Path(config_path).expanduser().resolve()
    d=json.loads(p.read_text()); pointer=HERE/"suite"/"ACTIVE_CONFIG_PATH.txt"
    if len(d['samples'])!=1 or not set(d['samples'])<=set(SPECS): raise ValueError("Not a single public Prime study config.")
    if os.environ.get('PSEUDOHD_CONFIG') and Path(os.environ['PSEUDOHD_CONFIG']).expanduser().resolve()!=p:
        raise ValueError('PSEUDOHD_CONFIG points at another config. Clear it or use an isolated kernel.')
    with tempfile.NamedTemporaryFile(mode='w', dir=pointer.parent,delete=False) as f:
        f.write(str(p)+'\n'); tmp=f.name
    os.replace(tmp,pointer)
    print('Active study:',next(iter(d['samples'])),'| config:',p,'| output:',d['output_root'])

def inspect_views(base, key, patch, centers=None, side_um=128):
    """Three bounded HE/DAPI overlay examples in the native micron axes, no global fit."""
    import pandas as pd
    import matplotlib.pyplot as plt
    from p06212_benchmark.inventory import CoordinateSpec, open_sample
    from p06212_benchmark.workflow import _dapi_source
    from p06212_benchmark.patches import extract_image_patch
    from p06212_benchmark.vendor.tiff_helpers import HEReader
    from p06212_benchmark.vendor.qc_helpers import display_dapi,overlay_dapi
    ps=paths(base,key); m=matrix_file(ps['alignment']); spec=CoordinateSpec.from_dict(patch['coordinate_spec']).validate()
    if not (20<=side_um<=256 and float(side_um).is_integer()): raise ValueError("Choose an integer field width between 20 and 256 µm.")
    if centers is None:
        raw=pd.read_parquet(ps['outs']/'cells.parquet',columns=['x_centroid','y_centroid']).dropna()
        xy=raw.to_numpy(float); centers=[]
        candidates=[(.25,.25),(.5,.5),(.75,.75)]
        for q in candidates:
            target=np.array([np.quantile(xy[:,j],q[j]) for j in range(2)])
            centers.append(xy[np.argmin(np.sum((xy-target)**2,axis=1))].tolist())
    sdata=open_sample(patch['zarr_path'],selection=('images',)); source=_dapi_source(sdata,patch)
    with HEReader(ps['he'],series_index=0,max_read_mib=192) as reader:
        fig,axes=plt.subplots(len(centers),3,figsize=(12,4*len(centers)),squeeze=False,constrained_layout=True)
        for (x,y),ax in zip(centers,axes):
            bounds=[x-side_um/2,y-side_um/2,x+side_um/2,y+side_um/2]
            img=extract_image_patch(reader,source,m,bounds,spec,image_mpp=0.5)
            dapi,_=display_dapi(img['dapi'],img['dapi_valid'])
            rgb=img['he']/255.
            valid=np.mean(img['he_valid'] & img['dapi_valid'])
            for a,title,data in zip(ax,['Clean H&E','DAPI','Overlay'],[rgb,dapi,overlay_dapi(rgb,dapi,img['dapi_valid'])]):
                a.imshow(data,extent=[bounds[0],bounds[2],bounds[3],bounds[1]],cmap='gray')
                a.set_title(f'{title} · x={x:.0f}, y={y:.0f} µm'); a.set_xlabel('Xenium x (µm)'); a.set_ylabel('y (µm)')
            ax[-1].set_xlabel(f'coverage in both images: {valid:.1%}')
        return fig
